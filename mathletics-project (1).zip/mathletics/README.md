# MATHLETICS — coaching website

React + TypeScript + Vite + Tailwind CSS v4 + Framer Motion on the front end.
Supabase (Postgres, Auth, Edge Functions) + Resend for the back end.

> **Read this first — verification status**
> This project was written in an environment where the npm registry was blocked, so
> **`npm install`, the type-check, the build, the dev server and every runtime test were NOT run.**
> The code was only checked for syntax errors with a global TypeScript compiler (none found); everything else
> is untested. Expect to fix a few small type or styling errors on first run. The QA checklist at the bottom is
> the list of things you still need to verify yourself.

---

## 1. Run the website locally

```bash
npm install
cp .env.example .env        # then fill in VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
npm run dev                 # http://localhost:5173
npm run typecheck           # run this first and fix anything it reports
npm run build
```

Without Supabase variables the site still renders, but the admission form shows an honest
"not configured" message and **does not pretend to submit**. `/admin` shows a setup notice.

## 2. Set up Supabase (required for real submissions)

1. Create a project at <https://supabase.com>.
2. **Database:** open *SQL Editor* and run `supabase/migrations/20261103000000_init.sql`
   (or `supabase db push` with the CLI). This creates the `enquiries` and `admins` tables, the
   `MATH-YYMM-00001` enquiry-ID generator and all Row Level Security policies.
3. **Create the coaching head's login:** *Authentication → Users → Add user* (email + password).
   Then in the SQL editor make them an administrator:
   ```sql
   insert into public.admins (user_id)
   select id from auth.users where email = 'coaching-head@example.com';
   ```
   A signed-in user who is *not* in `public.admins` can see nothing — RLS enforces this on the server.
4. **Front-end variables** (`.env`, also add them in your hosting provider's settings):
   `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` (Project Settings → API).
   The anon/publishable key is designed to be public. **Never** put the service-role key in a `VITE_` variable.

## 3. Set up email (Resend)

1. Create an account at <https://resend.com> and an API key.
2. **Verify a sending domain** and use an address on it as `RESEND_FROM_EMAIL`.
   Until you do, Resend's test sender (`onboarding@resend.dev`) can only deliver to *your own* Resend
   account email — it will not reach parents.
3. Set the secrets for the Edge Functions:
   ```bash
   supabase secrets set \
     RESEND_API_KEY=re_xxx \
     COACHING_NOTIFICATION_EMAIL=coaching-head@example.com \
     RESEND_FROM_EMAIL="MATHLETICS <admissions@your-domain.com>" \
     IP_HASH_SALT="a-long-random-string" \
     ALLOWED_ORIGIN="https://your-site.example"
   ```
   (`SUPABASE_URL`, `SUPABASE_ANON_KEY` and `SUPABASE_SERVICE_ROLE_KEY` are injected automatically inside Edge Functions.)
4. Deploy the functions:
   ```bash
   supabase functions deploy submit-enquiry
   supabase functions deploy admin-email
   ```

**If email is not configured**, enquiries are still saved. The row is marked `NOT_CONFIGURED`
(or `FAILED` with the provider's error), the dashboard shows a warning, and the coaching head can press
**Retry notification** once email is set up. Nothing pretends an email was sent.

## 4. How it works

| Step | What happens |
| --- | --- |
| Visitor fills 4-step form | Client-side validation (Indian mobile `[6-9]\d{9}`, email, names) for instant feedback |
| Submit | Browser calls the `submit-enquiry` Edge Function with a per-form idempotency key |
| Server | Re-validates everything, checks honeypot + minimum fill time, rate-limits (5/hour per hashed IP, 3/hour per mobile), de-duplicates, saves with service role, generates `MATH-YYMM-NNNNN` |
| Email | Sends **"NEW ADMISSION ENQUIRY — MATHLETICS"** to `COACHING_NOTIFICATION_EMAIL`; outcome stored on the row |
| Visitor | Sees a confirmation with the enquiry ID that says it is an enquiry, **not** an admission |
| `/admin` | Sign in → stats, search/filter, details, Approve / Reject / Mark pending, internal notes, retry email, optional decision email to the family |

Statuses are `PENDING`, `APPROVED`, `REJECTED`. New enquiries are always `PENDING`; only an administrator can change that.

**Security notes:** no secrets in front-end code; admins can update only `status` and `admin_notes`
(column-level grants); no insert/delete policies for browsers; raw IP addresses are never stored;
user text is escaped in emails and rendered as plain text in the dashboard.
`submit-enquiry` returns a neutral success (and stores nothing) when the honeypot is filled or the form is
completed in under 2.5 seconds — that is deliberate bot handling.

## 5. Editing content

Everything the institution may change is in **`src/content/siteContent.ts`**:
contact details, social links, programmes (add/remove freely), results, testimonials, FAQs and the
admission form's class / subject / learning-mode options.

Items marked `placeholder: true` display a visible "Sample" / "Placeholder" tag. **Nothing in the
repo is a real result, testimonial, programme, phone number, email or address** — replace them with
verified information and delete the `placeholder` flag. Contact details left empty are hidden and the footer
says they are coming soon.

## 6. Before launch

- [ ] Replace placeholder programmes, results, testimonials; add real contact details.
- [ ] Review `Privacy Policy` / `Terms` text (in `src/pages/LegalPage.tsx`) — it is a draft.
- [ ] Review the wording of the approval / rejection email in `supabase/functions/_shared/email.ts`.
- [ ] Add a 1200×630 `og:image` and absolute `og:url` / canonical URL in `index.html`.
- [ ] Set `ALLOWED_ORIGIN` to your real domain.
- [ ] Host as a single-page app (`vercel.json` and `public/_redirects` are included for Vercel / Netlify).

## 7. QA checklist — NOT yet verified

None of these were run. Tick them off after setup.

- [ ] `npm install && npm run typecheck && npm run build` succeed
- [ ] Site loads with no console errors; intro appears once and can be skipped
- [ ] All nav links, CTA buttons, "Learn More" / "Enquire Now" work; mobile menu opens/closes
- [ ] Layout at 360px, 390px, 768px, 1280px+ (no horizontal scroll)
- [ ] Form validates each step; invalid Indian numbers are rejected; consent is required
- [ ] Valid submission creates a row, shows an enquiry ID, and double-clicking creates only one row
- [ ] Coaching head receives the notification email (after Resend is configured)
- [ ] Forcing an email failure (bad API key) keeps the enquiry and shows a failure + working retry
- [ ] Admin login works; a non-admin account is refused; `/admin` shows nothing when signed out
- [ ] Approve / Reject / Pending update status and dates; decision email works when ticked
- [ ] Unknown URL shows the 404 page
- [ ] Rate limit returns the "too many enquiries" message after repeated submissions

## Project structure

```
src/
  components/        Intro, Navbar, Hero, About, Programmes, WhyChoose, Journey, Results,
                     Testimonials, FAQ, FinalCTA, Footer, Logo (geometric M), ui/, admission/
  content/           siteContent.ts  ← all editable content
  lib/               supabase client, validation, routing helpers
  pages/             HomePage, LegalPage, NotFound, admin/
supabase/
  migrations/        schema + RLS
  functions/         submit-enquiry, admin-email, _shared/
```
