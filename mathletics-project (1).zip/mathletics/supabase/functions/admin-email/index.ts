// POST /functions/v1/admin-email   (administrators only)
//   { action: "retry_notification", enquiryId }  → re-send the coaching-head notification
//   { action: "decision",           enquiryId }  → email the family the APPROVED / REJECTED outcome
// The caller's Supabase session token is verified and must belong to a row in public.admins.

import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders, json } from "../_shared/cors.ts";
import { decisionEmail, getEmailConfig, notificationEmail, sendEmail, type EnquiryRow } from "../_shared/email.ts";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed." }, 405);

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !serviceKey) return json({ error: "Server is not configured." }, 500);
  const db = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false } });

  // ── authenticate + authorise ────────────────────────────────────
  const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
  if (!token) return json({ error: "Not signed in." }, 401);
  const { data: userData, error: userError } = await db.auth.getUser(token);
  if (userError || !userData.user) return json({ error: "Invalid or expired session." }, 401);
  const { data: adminRow } = await db.from("admins").select("user_id").eq("user_id", userData.user.id).maybeSingle();
  if (!adminRow) return json({ error: "Not authorised." }, 403);

  // ── input ───────────────────────────────────────────────────────
  let body: { action?: string; enquiryId?: string };
  try {
    body = await req.json();
  } catch {
    return json({ error: "Invalid request." }, 400);
  }
  if (!body.enquiryId || !UUID_RE.test(body.enquiryId)) return json({ error: "Invalid enquiry." }, 400);

  const { data: row } = await db.from("enquiries").select("*").eq("id", body.enquiryId).maybeSingle();
  if (!row) return json({ error: "Enquiry not found." }, 404);

  const cfg = getEmailConfig();

  // ── retry coaching-head notification ────────────────────────────
  if (body.action === "retry_notification") {
    if (!cfg) {
      await db.from("enquiries").update({ notify_status: "NOT_CONFIGURED", notify_error: "RESEND_API_KEY or COACHING_NOTIFICATION_EMAIL is not set." }).eq("id", row.id);
      return json({ error: "Email is not configured yet (RESEND_API_KEY / COACHING_NOTIFICATION_EMAIL)." }, 409);
    }
    const mail = notificationEmail(row as EnquiryRow);
    const sent = await sendEmail(cfg, { to: cfg.to, ...mail, replyTo: row.email });
    if (!sent.ok) {
      await db.from("enquiries").update({ notify_status: "FAILED", notify_error: sent.error }).eq("id", row.id);
      return json({ error: `Email failed: ${sent.error}` }, 502);
    }
    await db.from("enquiries").update({ notify_status: "SENT", notify_error: null, notify_sent_at: new Date().toISOString() }).eq("id", row.id);
    return json({ ok: true });
  }

  // ── decision email to the family ────────────────────────────────
  if (body.action === "decision") {
    if (row.status !== "APPROVED" && row.status !== "REJECTED") {
      return json({ error: "Only approved or rejected enquiries can receive a decision email." }, 409);
    }
    if (!cfg) {
      await db.from("enquiries").update({ decision_email_status: "NOT_CONFIGURED", decision_email_error: "RESEND_API_KEY or COACHING_NOTIFICATION_EMAIL is not set." }).eq("id", row.id);
      return json({ error: "Email is not configured yet (RESEND_API_KEY / COACHING_NOTIFICATION_EMAIL)." }, 409);
    }
    const mail = decisionEmail(row as EnquiryRow, row.status);
    const sent = await sendEmail(cfg, { to: row.email, ...mail, replyTo: cfg.to });
    if (!sent.ok) {
      await db.from("enquiries").update({ decision_email_status: "FAILED", decision_email_error: sent.error }).eq("id", row.id);
      return json({ error: `Email failed: ${sent.error}` }, 502);
    }
    await db.from("enquiries").update({ decision_email_status: "SENT", decision_email_error: null, decision_email_sent_at: new Date().toISOString() }).eq("id", row.id);
    return json({ ok: true });
  }

  return json({ error: "Unknown action." }, 400);
});
