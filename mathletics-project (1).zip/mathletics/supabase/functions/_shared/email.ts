// Transactional email via Resend. All credentials come from environment variables.

export interface EmailConfig {
  apiKey: string;
  to: string; // coaching head
  from: string;
}

/** Returns null when email is not configured — callers must record that honestly. */
export function getEmailConfig(): EmailConfig | null {
  const apiKey = Deno.env.get("RESEND_API_KEY");
  const to = Deno.env.get("COACHING_NOTIFICATION_EMAIL");
  if (!apiKey || !to) return null;
  return {
    apiKey,
    to,
    from: Deno.env.get("RESEND_FROM_EMAIL") || "MATHLETICS <onboarding@resend.dev>",
  };
}

export function esc(v: unknown): string {
  return String(v ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export function formatIST(iso: string): string {
  return new Intl.DateTimeFormat("en-IN", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "Asia/Kolkata",
  }).format(new Date(iso)) + " IST";
}

export async function sendEmail(
  cfg: EmailConfig,
  msg: { to: string; subject: string; html: string; text: string; replyTo?: string },
): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${cfg.apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: cfg.from,
        to: [msg.to],
        subject: msg.subject,
        html: msg.html,
        text: msg.text,
        ...(msg.replyTo ? { reply_to: msg.replyTo } : {}),
      }),
    });
    if (!res.ok) {
      const body = await res.text();
      return { ok: false, error: `Resend ${res.status}: ${body.slice(0, 300)}` };
    }
    return { ok: true };
  } catch (err) {
    return { ok: false, error: `Network error: ${err instanceof Error ? err.message : String(err)}` };
  }
}

export interface EnquiryRow {
  id: string;
  enquiry_code: string;
  student_name: string;
  parent_name: string;
  mobile: string;
  email: string;
  current_class: string;
  subjects: string[];
  learning_mode: string | null;
  message: string | null;
  status: string;
  created_at: string;
}

export function notificationEmail(r: EnquiryRow) {
  const rows: [string, string][] = [
    ["Enquiry ID", r.enquiry_code],
    ["Student name", r.student_name],
    ["Parent / guardian", r.parent_name],
    ["Contact number", `+91 ${r.mobile}`],
    ["Email", r.email],
    ["Class", r.current_class],
    ["Interested subjects", r.subjects.join(", ")],
    ["Learning mode", r.learning_mode ?? "No preference"],
    ["Additional message", r.message ?? "—"],
    ["Submitted", formatIST(r.created_at)],
  ];

  const html = `<!doctype html><html><body style="margin:0;background:#FFFDF6;font-family:Arial,Helvetica,sans-serif;color:#101A35">
  <div style="max-width:560px;margin:0 auto;padding:24px">
    <div style="background:#315FE8;color:#FFFDF6;padding:22px 24px;border-radius:16px 16px 0 0">
      <div style="font-size:12px;letter-spacing:3px;color:#FF8057;font-weight:bold">MATHLETICS</div>
      <div style="font-size:22px;font-weight:bold;margin-top:6px">New admission enquiry</div>
    </div>
    <table style="width:100%;border-collapse:collapse;background:#ffffff;border:1px solid #E9E5FF">
      ${rows
        .map(
          ([k, v]) =>
            `<tr><td style="padding:12px 16px;border-bottom:1px solid #E9E5FF;font-size:13px;color:#555;width:38%;vertical-align:top">${esc(k)}</td><td style="padding:12px 16px;border-bottom:1px solid #E9E5FF;font-size:14px;font-weight:bold;white-space:pre-wrap">${esc(v)}</td></tr>`,
        )
        .join("")}
    </table>
    <p style="font-size:13px;color:#555;line-height:1.5">Status: <b>PENDING</b>. Open the admin dashboard to approve or reject this enquiry. Nothing has been promised to the family.</p>
  </div></body></html>`;

  const text = `NEW ADMISSION ENQUIRY — MATHLETICS\n\n${rows.map(([k, v]) => `${k}: ${v}`).join("\n")}\n\nStatus: PENDING. Review it in the admin dashboard.`;

  return { subject: "NEW ADMISSION ENQUIRY — MATHLETICS", html, text };
}

export function decisionEmail(r: EnquiryRow, decision: "APPROVED" | "REJECTED") {
  const approved = decision === "APPROVED";
  const subject = approved
    ? `Your MATHLETICS admission enquiry (${r.enquiry_code}) has been approved`
    : `Update on your MATHLETICS admission enquiry (${r.enquiry_code})`;

  const body = approved
    ? `Thank you for your interest in MATHLETICS. After review, the coaching head has approved the admission enquiry for ${r.student_name}. The coaching team will be in touch regarding the next steps.`
    : `Thank you for your interest in MATHLETICS. After careful review, we are unable to take the admission enquiry for ${r.student_name} forward at this time. We appreciate you considering us and wish ${r.student_name} every success.`;

  const html = `<!doctype html><html><body style="margin:0;background:#FFFDF6;font-family:Arial,Helvetica,sans-serif;color:#101A35">
  <div style="max-width:560px;margin:0 auto;padding:24px">
    <div style="font-size:12px;letter-spacing:3px;color:#315FE8;font-weight:bold">MATHLETICS</div>
    <p style="font-size:16px;line-height:1.6">Dear ${esc(r.parent_name)},</p>
    <p style="font-size:16px;line-height:1.6">${esc(body)}</p>
    <p style="font-size:13px;color:#555">Enquiry ID: <b>${esc(r.enquiry_code)}</b></p>
    <p style="font-size:16px;line-height:1.6">Warm regards,<br/>The MATHLETICS team</p>
  </div></body></html>`;

  const text = `Dear ${r.parent_name},\n\n${body}\n\nEnquiry ID: ${r.enquiry_code}\n\nWarm regards,\nThe MATHLETICS team`;
  return { subject, html, text };
}
