// Server-side validation. This is the source of truth; the browser repeats the same
// rules (src/lib/validation.ts) only to give instant feedback.

export interface CleanEnquiry {
  studentName: string;
  parentName: string;
  mobile: string;
  email: string;
  currentClass: string;
  subjects: string[];
  learningMode: string | null;
  message: string | null;
  consent: true;
}

const NAME_RE = /^[\p{L}\p{M}][\p{L}\p{M}\s.'’-]{1,79}$/u;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const MOBILE_RE = /^[6-9]\d{9}$/;
// deno-lint-ignore no-control-regex
const CONTROL_RE = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

export function normalizeMobile(raw: string): string {
  const d = raw.replace(/[\s\-().]/g, "");
  if (/^\+91\d{10}$/.test(d)) return d.slice(3);
  if (/^0091\d{10}$/.test(d)) return d.slice(4);
  if (/^91\d{10}$/.test(d)) return d.slice(2);
  if (/^0\d{10}$/.test(d)) return d.slice(1);
  return d;
}

/** Trim, collapse whitespace, strip control characters. */
function clean(v: unknown, max: number, multiline = false): string {
  if (typeof v !== "string") return "";
  let s = v.replace(CONTROL_RE, "").normalize("NFC");
  s = multiline ? s.replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n") : s.replace(/\s+/g, " ");
  return s.trim().slice(0, max + 1); // +1 so over-length input is detected, not silently cut
}

export function validateEnquiry(
  input: Record<string, unknown>,
): { ok: true; data: CleanEnquiry } | { ok: false; fieldErrors: Record<string, string> } {
  const e: Record<string, string> = {};

  const studentName = clean(input.studentName, 80);
  const parentName = clean(input.parentName, 80);
  const currentClass = clean(input.currentClass, 40);
  const email = clean(input.email, 254).toLowerCase();
  const mobile = normalizeMobile(typeof input.mobile === "string" ? input.mobile : "");
  const learningModeRaw = clean(input.learningMode, 40);
  const messageRaw = clean(input.message, 1100, true);

  if (!NAME_RE.test(studentName)) e.studentName = "Please enter a valid student name (letters only, 2–80 characters).";
  if (!NAME_RE.test(parentName)) e.parentName = "Please enter a valid parent or guardian name (letters only, 2–80 characters).";
  if (!currentClass || currentClass.length > 40) e.currentClass = "Please select the student's current class.";
  if (!MOBILE_RE.test(mobile)) e.mobile = "Enter a valid 10-digit Indian mobile number (starts with 6–9).";
  if (!EMAIL_RE.test(email) || email.length > 254) e.email = "Enter a valid email address.";

  let subjects: string[] = [];
  if (Array.isArray(input.subjects)) {
    subjects = [...new Set(input.subjects.map((s) => clean(s, 40)).filter((s) => s && s.length <= 40))].slice(0, 10);
  }
  if (subjects.length === 0) e.subjects = "Select at least one subject of interest.";

  if (messageRaw.length > 1100) e.message = "Message is too long.";
  if (input.consent !== true) e.consent = "Consent is required to submit an enquiry.";

  if (Object.keys(e).length) return { ok: false, fieldErrors: e };

  return {
    ok: true,
    data: {
      studentName,
      parentName,
      mobile,
      email,
      currentClass,
      subjects,
      learningMode: learningModeRaw || null,
      message: messageRaw || null,
      consent: true,
    },
  };
}
