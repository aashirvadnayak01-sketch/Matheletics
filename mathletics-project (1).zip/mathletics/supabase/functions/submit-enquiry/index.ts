// POST /functions/v1/submit-enquiry
// Public endpoint used by the admission form.
//   1. validates on the server        4. emails the coaching head (if configured)
//   2. rate-limits + spam checks      5. records the email outcome on the row
//   3. saves the enquiry (service role)
// The enquiry is ALWAYS preserved in the database, even if email delivery fails.

import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders, json } from "../_shared/cors.ts";
import { validateEnquiry } from "../_shared/validation.ts";
import { getEmailConfig, notificationEmail, sendEmail, type EnquiryRow } from "../_shared/email.ts";

const HOUR_MS = 60 * 60 * 1000;
const MAX_PER_IP_PER_HOUR = 5;
const MAX_PER_MOBILE_PER_HOUR = 3;
const MIN_FILL_TIME_MS = 2500; // a human cannot complete four steps faster than this
const MAX_BODY_BYTES = 10_000;

async function sha256(input: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed." }, 405);

  const raw = await req.text();
  if (raw.length > MAX_BODY_BYTES) return json({ error: "Request too large." }, 413);

  let body: Record<string, unknown>;
  try {
    body = JSON.parse(raw);
    if (typeof body !== "object" || body === null || Array.isArray(body)) throw new Error("bad");
  } catch {
    return json({ error: "Invalid request." }, 400);
  }

  // ── spam protection ─────────────────────────────────────────────
  // Honeypot filled, or form completed impossibly fast → almost certainly a bot.
  // Respond with a neutral 200 so bots get no signal; nothing is stored or emailed.
  const elapsed = typeof body.elapsedMs === "number" ? body.elapsedMs : 0;
  if ((typeof body.website === "string" && body.website.trim() !== "") || elapsed < MIN_FILL_TIME_MS) {
    return json({ ok: true, enquiryCode: "MATH-RECEIVED" });
  }

  // ── validation (server is the source of truth) ──────────────────
  const result = validateEnquiry(body);
  if (!result.ok) {
    return json({ error: "Please correct the highlighted fields.", fieldErrors: result.fieldErrors }, 422);
  }
  const d = result.data;

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !serviceKey) {
    console.error("submit-enquiry: SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY missing");
    return json({ error: "The admissions service is not configured. Please try again later." }, 500);
  }
  const db = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false } });

  const idempotencyKey = typeof body.idempotencyKey === "string" && UUID_RE.test(body.idempotencyKey) ? body.idempotencyKey : null;

  // ── idempotency: same form instance submitted twice → return the original ──
  if (idempotencyKey) {
    const { data: existing } = await db.from("enquiries").select("enquiry_code").eq("idempotency_key", idempotencyKey).maybeSingle();
    if (existing) return json({ ok: true, enquiryCode: existing.enquiry_code });
  }

  // ── rate limiting (salted IP hash — raw IPs are never stored) ───
  const ip = (req.headers.get("x-forwarded-for") ?? "").split(",")[0].trim() || req.headers.get("cf-connecting-ip") || "unknown";
  const ipHash = await sha256(`${Deno.env.get("IP_HASH_SALT") ?? "mathletics"}:${ip}`);
  const since = new Date(Date.now() - HOUR_MS).toISOString();

  const [{ count: ipCount }, { count: mobileCount }] = await Promise.all([
    db.from("enquiries").select("id", { count: "exact", head: true }).eq("ip_hash", ipHash).gte("created_at", since),
    db.from("enquiries").select("id", { count: "exact", head: true }).eq("mobile", d.mobile).gte("created_at", since),
  ]);
  if ((ipCount ?? 0) >= MAX_PER_IP_PER_HOUR || (mobileCount ?? 0) >= MAX_PER_MOBILE_PER_HOUR) {
    return json({ error: "Too many enquiries were submitted recently. Please try again in about an hour." }, 429);
  }

  // ── duplicate content within 24h (same student + mobile) ────────
  const { data: dup } = await db
    .from("enquiries")
    .select("enquiry_code")
    .eq("mobile", d.mobile)
    .ilike("student_name", d.studentName)
    .gte("created_at", new Date(Date.now() - 24 * HOUR_MS).toISOString())
    .limit(1)
    .maybeSingle();
  if (dup) return json({ ok: true, enquiryCode: dup.enquiry_code });

  // ── save ────────────────────────────────────────────────────────
  const { data: row, error: insertError } = await db
    .from("enquiries")
    .insert({
      student_name: d.studentName,
      parent_name: d.parentName,
      mobile: d.mobile,
      email: d.email,
      current_class: d.currentClass,
      subjects: d.subjects,
      learning_mode: d.learningMode,
      message: d.message,
      consent: d.consent,
      idempotency_key: idempotencyKey,
      ip_hash: ipHash,
    })
    .select("*")
    .single();

  if (insertError || !row) {
    // Race on the idempotency key → return the row that won
    if (insertError?.code === "23505" && idempotencyKey) {
      const { data: existing } = await db.from("enquiries").select("enquiry_code").eq("idempotency_key", idempotencyKey).maybeSingle();
      if (existing) return json({ ok: true, enquiryCode: existing.enquiry_code });
    }
    console.error("submit-enquiry insert failed:", insertError?.message);
    return json({ error: "We could not save your enquiry. Please try again." }, 500);
  }

  // ── notify the coaching head (never blocks the visitor's success) ──
  const cfg = getEmailConfig();
  if (!cfg) {
    await db.from("enquiries").update({ notify_status: "NOT_CONFIGURED", notify_error: "RESEND_API_KEY or COACHING_NOTIFICATION_EMAIL is not set." }).eq("id", row.id);
  } else {
    const mail = notificationEmail(row as EnquiryRow);
    const sent = await sendEmail(cfg, { to: cfg.to, ...mail, replyTo: d.email });
    if (sent.ok) {
      await db.from("enquiries").update({ notify_status: "SENT", notify_error: null, notify_sent_at: new Date().toISOString() }).eq("id", row.id);
    } else {
      console.error("submit-enquiry email failed:", sent.error);
      await db.from("enquiries").update({ notify_status: "FAILED", notify_error: sent.error }).eq("id", row.id);
    }
  }

  return json({ ok: true, enquiryCode: row.enquiry_code });
});
