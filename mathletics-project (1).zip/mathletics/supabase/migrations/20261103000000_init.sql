-- MATHLETICS — initial schema
-- Run in the Supabase SQL editor, or with `supabase db push`.
--
-- Security model
--   * Visitors NEVER touch the database directly. Enquiries are inserted by the
--     `submit-enquiry` Edge Function (service role) after server-side validation.
--   * Only users listed in `public.admins` can read or update enquiries (RLS).
--   * Admins can change ONLY status and admin_notes (column-level grants).
--   * anon role has no access to any table.

create extension if not exists pgcrypto;

-- ─────────────────────────────────────────────── admins
create table if not exists public.admins (
  user_id    uuid primary key references auth.users (id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.admins enable row level security;

create or replace function public.is_admin()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

drop policy if exists "admins can read own row" on public.admins;
create policy "admins can read own row"
  on public.admins for select to authenticated
  using (user_id = auth.uid());

revoke all on public.admins from anon, authenticated;
grant select on public.admins to authenticated;

-- ─────────────────────────────────────────────── enquiries
create sequence if not exists public.enquiry_seq start 1;

create or replace function public.generate_enquiry_code()
returns text
language sql
volatile
as $$
  select 'MATH-' || to_char(now() at time zone 'Asia/Kolkata', 'YYMM') || '-' ||
         lpad(nextval('public.enquiry_seq')::text, 5, '0');
$$;

create table if not exists public.enquiries (
  id              uuid primary key default gen_random_uuid(),
  enquiry_code    text not null unique default public.generate_enquiry_code(),

  student_name    text not null check (char_length(student_name) between 2 and 80),
  parent_name     text not null check (char_length(parent_name)  between 2 and 80),
  mobile          text not null check (mobile ~ '^[6-9][0-9]{9}$'),
  email           text not null check (char_length(email) <= 254),
  current_class   text not null check (char_length(current_class) <= 40),
  subjects        text[] not null check (cardinality(subjects) between 1 and 10),
  learning_mode   text check (learning_mode is null or char_length(learning_mode) <= 40),
  message         text check (message is null or char_length(message) <= 1100),
  consent         boolean not null check (consent = true),

  status          text not null default 'PENDING' check (status in ('PENDING', 'APPROVED', 'REJECTED')),
  admin_notes     text check (admin_notes is null or char_length(admin_notes) <= 4000),
  decided_at      timestamptz,
  decided_by      uuid references auth.users (id),

  -- abuse protection (raw IPs are never stored — only a salted hash)
  idempotency_key uuid unique,
  ip_hash         text,

  -- coaching-head notification email tracking
  notify_status   text not null default 'PENDING'
                  check (notify_status in ('PENDING', 'SENT', 'FAILED', 'NOT_CONFIGURED')),
  notify_error    text,
  notify_sent_at  timestamptz,

  -- optional decision email to the family
  decision_email_status text not null default 'NOT_SENT'
                  check (decision_email_status in ('NOT_SENT', 'SENT', 'FAILED', 'NOT_CONFIGURED')),
  decision_email_error  text,
  decision_email_sent_at timestamptz,

  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create index if not exists enquiries_status_created_idx on public.enquiries (status, created_at desc);
create index if not exists enquiries_created_idx        on public.enquiries (created_at desc);
create index if not exists enquiries_ip_hash_idx        on public.enquiries (ip_hash, created_at desc);
create index if not exists enquiries_mobile_idx         on public.enquiries (mobile, created_at desc);

-- keep updated_at fresh and record who/when a decision was made
create or replace function public.enquiries_before_update()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  if new.status is distinct from old.status then
    if new.status = 'PENDING' then
      new.decided_at := null;
      new.decided_by := null;
    else
      new.decided_at := now();
      new.decided_by := auth.uid();
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists enquiries_before_update on public.enquiries;
create trigger enquiries_before_update
  before update on public.enquiries
  for each row execute function public.enquiries_before_update();

-- ─────────────────────────────────────────────── RLS for enquiries
alter table public.enquiries enable row level security;

drop policy if exists "admins read enquiries" on public.enquiries;
create policy "admins read enquiries"
  on public.enquiries for select to authenticated
  using (public.is_admin());

drop policy if exists "admins update enquiries" on public.enquiries;
create policy "admins update enquiries"
  on public.enquiries for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- No insert / delete policies: inserts happen only via the service role (Edge Function).
revoke all on public.enquiries from anon, authenticated;
grant select on public.enquiries to authenticated;
grant update (status, admin_notes) on public.enquiries to authenticated;

-- ─────────────────────────────────────────────── making someone an admin
-- 1. Create the user in Supabase Dashboard → Authentication → Users.
-- 2. Then run (replace the email):
--
--   insert into public.admins (user_id)
--   select id from auth.users where email = 'coaching-head@example.com';
