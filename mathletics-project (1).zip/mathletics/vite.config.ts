import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  // Only VITE_-prefixed variables are ever exposed to the browser.
  envPrefix: ["VITE_"],
  build: {
    sourcemap: false,
    chunkSizeWarningLimit: 700,
  },
});
