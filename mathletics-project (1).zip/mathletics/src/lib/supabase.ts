import { createClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

/** True only when both browser-safe variables are present. */
export const isSupabaseConfigured = Boolean(url && anonKey);

/**
 * Browser client. Uses ONLY the public anon key — all data access is limited by
 * Row Level Security. The service-role key never reaches the frontend.
 * `null` when the project has not been configured yet; callers must handle that
 * honestly instead of pretending a request succeeded.
 */
export const supabase = isSupabaseConfigured
  ? createClient(url as string, anonKey as string, {
      auth: { persistSession: true, autoRefreshToken: true },
    })
  : null;
