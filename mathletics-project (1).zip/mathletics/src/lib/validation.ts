// Client-side validation. The SAME rules are re-implemented on the server in
// supabase/functions/_shared/validation.ts — the server is the source of truth.

export interface EnquiryForm {
  studentName: string;
  parentName: string;
  currentClass: string;
  subjects: string[];
  learningMode: string;
  message: string;
  mobile: string;
  email: string;
  consent: boolean;
  /** Honeypot — real visitors never see or fill this. */
  website: string;
}

export type FormErrors = Partial<Record<keyof EnquiryForm, string>>;

export const LIMITS = { name: 80, message: 1000, email: 254 } as const;

const NAME_RE = /^[\p{L}\p{M}][\p{L}\p{M}\s.'’-]{1,79}$/u;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const INDIAN_MOBILE_RE = /^[6-9]\d{9}$/;

/** Strips spaces/dashes and an optional +91 / 91 / 0 prefix (only when 10 digits remain). */
export function normalizeMobile(raw: string): string {
  const d = raw.replace(/[\s\-().]/g, "");
  if (/^\+91\d{10}$/.test(d)) return d.slice(3);
  if (/^0091\d{10}$/.test(d)) return d.slice(4);
  if (/^91\d{10}$/.test(d)) return d.slice(2);
  if (/^0\d{10}$/.test(d)) return d.slice(1);
  return d;
}

export function isIndianMobile(raw: string): boolean {
  return INDIAN_MOBILE_RE.test(normalizeMobile(raw));
}

export const FIELD_STEP: Record<keyof EnquiryForm, number> = {
  studentName: 0,
  parentName: 0,
  currentClass: 0,
  subjects: 1,
  learningMode: 1,
  message: 1,
  mobile: 2,
  email: 2,
  consent: 3,
  website: 3,
};

export function validateStep(step: number, v: EnquiryForm): FormErrors {
  const e: FormErrors = {};
  if (step === 0) {
    if (!v.studentName.trim()) e.studentName = "Please enter the student's full name.";
    else if (!NAME_RE.test(v.studentName.trim()))
      e.studentName = "Use letters only (2–80 characters) for the name.";
    if (!v.parentName.trim()) e.parentName = "Please enter the parent or guardian's name.";
    else if (!NAME_RE.test(v.parentName.trim()))
      e.parentName = "Use letters only (2–80 characters) for the name.";
    if (!v.currentClass) e.currentClass = "Please select the student's current class.";
  }
  if (step === 1) {
    if (v.subjects.length === 0) e.subjects = "Select at least one subject of interest.";
    if (v.message.length > LIMITS.message)
      e.message = `Please keep your message under ${LIMITS.message} characters.`;
  }
  if (step === 2) {
    if (!v.mobile.trim()) e.mobile = "Please enter a mobile number.";
    else if (!isIndianMobile(v.mobile))
      e.mobile = "Enter a valid 10-digit Indian mobile number (starts with 6–9).";
    if (!v.email.trim()) e.email = "Please enter an email address.";
    else if (!EMAIL_RE.test(v.email.trim()) || v.email.length > LIMITS.email)
      e.email = "Enter a valid email address, e.g. name@example.com.";
  }
  if (step === 3) {
    if (!v.consent) e.consent = "Please tick the consent box to continue.";
  }
  return e;
}

export function validateAll(v: EnquiryForm): FormErrors {
  return { ...validateStep(0, v), ...validateStep(1, v), ...validateStep(2, v), ...validateStep(3, v) };
}
