import { useCallback } from "react";
import { useLocation, useNavigate } from "react-router-dom";

export function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return false;
  el.scrollIntoView({ behavior: "smooth", block: "start" });
  history.replaceState(null, "", `#${id}`);
  return true;
}

/** Smooth-scrolls on the home page; from any other page, navigates home then scrolls. */
export function useAnchorNav() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  return useCallback(
    (id: string) => {
      if (pathname === "/") scrollToId(id);
      else navigate({ pathname: "/", hash: `#${id}` });
    },
    [pathname, navigate],
  );
}
