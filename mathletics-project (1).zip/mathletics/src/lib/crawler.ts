/**
 * Search-engine crawlers (Googlebot, Google-InspectionTool, Bing…) render a page once, in one very tall
 * window, and never scroll or click. Anything that starts hidden and waits for a scroll trigger or a click
 * would stay invisible in their render (blank sections in Search Console's screenshot). For them we skip the
 * hidden starting states and expand collapsed content. Real visitors keep every animation.
 */
const BOT = /bot|crawl|spider|slurp|lighthouse|pagespeed|headless|google|bing|yandex|duckduck|baidu|facebookexternalhit|whatsapp|inspection/i;

export function isCrawler(): boolean {
  if (typeof navigator === "undefined") return false;
  return BOT.test(navigator.userAgent) || (typeof window !== "undefined" && window.innerHeight > 2400);
}
