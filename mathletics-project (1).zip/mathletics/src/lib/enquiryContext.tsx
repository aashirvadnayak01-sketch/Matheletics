import { createContext, useCallback, useContext, useState, type ReactNode } from "react";

export interface Prefill {
  /** Programme name the visitor clicked "Enquire Now" on. */
  programme?: string;
  /** Changes on every request so the form re-applies the prefill. */
  nonce: number;
}

interface Ctx {
  prefill: Prefill | null;
  requestEnquiry: (programme?: string) => void;
}

const EnquiryCtx = createContext<Ctx>({ prefill: null, requestEnquiry: () => {} });

export function EnquiryProvider({ children }: { children: ReactNode }) {
  const [prefill, setPrefill] = useState<Prefill | null>(null);
  const requestEnquiry = useCallback((programme?: string) => {
    setPrefill({ programme, nonce: Date.now() });
  }, []);
  return <EnquiryCtx.Provider value={{ prefill, requestEnquiry }}>{children}</EnquiryCtx.Provider>;
}

export const useEnquiry = () => useContext(EnquiryCtx);
