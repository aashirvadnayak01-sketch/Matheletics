export type EnquiryStatus = "PENDING" | "APPROVED" | "REJECTED";
export type NotifyStatus = "PENDING" | "SENT" | "FAILED" | "NOT_CONFIGURED";
export type DecisionEmailStatus = "NOT_SENT" | "SENT" | "FAILED" | "NOT_CONFIGURED";

export interface Enquiry {
  id: string;
  enquiry_code: string;
  student_name: string;
  parent_name: string;
  mobile: string;
  email: string;
  current_class: string;
  subjects: string[];
  learning_mode: string | null;
  message: string | null;
  consent: boolean;
  status: EnquiryStatus;
  admin_notes: string | null;
  decided_at: string | null;
  notify_status: NotifyStatus;
  notify_error: string | null;
  notify_sent_at: string | null;
  decision_email_status: DecisionEmailStatus;
  decision_email_error: string | null;
  decision_email_sent_at: string | null;
  created_at: string;
  updated_at: string;
}

export const formatDateTime = (iso: string) =>
  new Intl.DateTimeFormat("en-IN", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Kolkata" }).format(new Date(iso));
