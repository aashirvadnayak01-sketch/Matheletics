/**
 * ──────────────────────────────────────────────────────────────
 *  MATHLETICS — EDITABLE SITE CONTENT
 *  Everything the institution may want to change lives in this file.
 *  Nothing here is verified institutional fact unless you replace it:
 *  items with `placeholder: true` are shown on the site with a visible
 *  "Sample" tag so they are never mistaken for real results or offerings.
 *  Remove `placeholder: true` once you have replaced an item with real,
 *  verified information.
 * ──────────────────────────────────────────────────────────────
 */

interface SiteConfig {
  name: string;
  tagline: string;
  shortDescription: string;
  contact: { phone: string; email: string; address: string; hours: string };
  social: { instagram: string; facebook: string; youtube: string; whatsapp: string };
}

export const SITE: SiteConfig = {
  name: "MATHLETICS",
  tagline: "Where mathematical intelligence meets academic excellence.",
  shortDescription:
    "A coaching institution focused on conceptual understanding, problem-solving and steady academic progress.",
  /** Leave a value as "" until it is real. Empty values are hidden / shown as "coming soon". */
  contact: {
    phone: "+91 79910 52911|+91 70088 95759",
    email: "",
    address: "",
    hours: "",
  },
  /** Full URLs, e.g. "https://instagram.com/yourhandle". Empty = not shown. */
  social: {
    instagram: "",
    facebook: "",
    youtube: "",
    whatsapp: "",
  },
};

export interface Programme {
  id: string;
  name: string;
  classLabel: string;
  subjects: string[];
  description: string;
  details: string;
  placeholder?: boolean;
}

/** Add, remove or edit programmes freely — the section lays itself out. */
export const PROGRAMMES: Programme[] = [
  {
    id: "prog-math",
    name: "Mathematics",
    classLabel: "Classes 7 to 12",
    subjects: ["Mathematics"],
    description:
      "Concept-based mathematics coaching for students in Classes 7 to 12, with regular practice, doubt-clearing and assessment.",
    details:
      "Mathematics is taught for Classes 7 to 12. Lessons start from the underlying idea, then build skill through varied practice, doubt-clearing support and regular assessment. Both CBSE and ICSE students are taught, in group batches (weekdays or weekends) or one-on-one. A demo class is available. Timings and fees can be confirmed by the coaching team on enquiry.",
  },
  {
    id: "prog-phy",
    name: "Physics",
    classLabel: "Classes 7 to 10",
    subjects: ["Physics"],
    description:
      "Physics coaching for students in Classes 7 to 10, focused on understanding concepts and applying them to problems.",
    details:
      "Physics is taught for Classes 7 to 10. The emphasis is on understanding the concept first and then applying it to numerical and reasoning questions. Both CBSE and ICSE students are taught, in group batches (weekdays or weekends) or one-on-one. A demo class is available. Timings and fees can be confirmed by the coaching team on enquiry.",
  },
];

export const ABOUT_CARDS = [
  {
    n: "01",
    title: "Conceptual Clarity",
    text: "Understanding why a method works before practising how to apply it, so ideas stay with students beyond the exam.",
    icon: "clarity",
    tone: "cobalt",
  },
  {
    n: "02",
    title: "Personal Attention",
    text: "Learning that notices each student's pace, questions and gaps rather than treating a class as one single learner.",
    icon: "attention",
    tone: "tangerine",
  },
  {
    n: "03",
    title: "Consistent Progress",
    text: "Small, steady improvements built through regular practice and review, turning effort into lasting confidence.",
    icon: "progress",
    tone: "mint",
  },
] as const;

export const WHY_ITEMS = [
  {
    title: "Structured Learning",
    text: "A clear, step-by-step path through each topic so students always know where they are and what comes next.",
  },
  {
    title: "Individual Guidance",
    text: "Attention to each student's strengths and gaps, with guidance shaped around how they learn.",
  },
  {
    title: "Concept-Based Teaching",
    text: "Teaching that starts from ideas and reasoning, so formulas make sense instead of being memorised.",
  },
  {
    title: "Doubt-Clearing Support",
    text: "Space to ask questions and get them answered, so small confusions never grow into big gaps.",
  },
  {
    title: "Regular Academic Assessment",
    text: "Frequent check-ins that show what is working and what needs more practice.",
  },
  {
    title: "Student-Focused Environment",
    text: "A setting built around students' growth, where asking questions and making mistakes is part of learning.",
  },
];

export const JOURNEY = [
  { n: 1, title: "Understand", text: "Build the idea from the ground up until the concept feels clear and natural." },
  { n: 2, title: "Practise", text: "Apply the concept across varied problems so understanding becomes skill." },
  { n: 3, title: "Improve", text: "Review mistakes, fix gaps and sharpen accuracy with focused feedback." },
  { n: 4, title: "Master", text: "Handle unfamiliar problems with confidence, speed and clear reasoning." },
];

export interface ResultCard {
  id: string;
  kind: "Achievement" | "Improvement" | "Result" | "Milestone";
  headline: string;
  detail: string;
  placeholder?: boolean;
}

/** Replace with VERIFIED information only. Never publish unverified marks or statistics. */
export const RESULTS: ResultCard[] = [
  {
    id: "r1",
    kind: "Achievement",
    headline: "Student achievement",
    detail: "Add a verified student achievement here, with the student's / parent's permission.",
    placeholder: true,
  },
  {
    id: "r2",
    kind: "Improvement",
    headline: "Academic improvement",
    detail: "Add a verified example of academic improvement here.",
    placeholder: true,
  },
  {
    id: "r3",
    kind: "Result",
    headline: "Examination result",
    detail: "Add verified examination results here once available.",
    placeholder: true,
  },
  {
    id: "r4",
    kind: "Milestone",
    headline: "Institution milestone",
    detail: "Add a verified milestone for the institution here.",
    placeholder: true,
  },
];

export interface Testimonial {
  id: string;
  quote: string;
  author: string;
  role: string;
  placeholder?: boolean;
}

/** Placeholders are labelled on screen. Replace with real, consented testimonials. */
export const TESTIMONIALS: Testimonial[] = [
  {
    id: "t1",
    quote: "Placeholder testimonial. A real parent's words will appear here once they have been collected and approved.",
    author: "Parent name",
    role: "Parent · placeholder",
    placeholder: true,
  },
  {
    id: "t2",
    quote: "Placeholder testimonial. A real student's words will appear here once they have been collected and approved.",
    author: "Student name",
    role: "Student · placeholder",
    placeholder: true,
  },
  {
    id: "t3",
    quote: "Placeholder testimonial. Replace this with a genuine, consented testimonial before publishing.",
    author: "Parent name",
    role: "Parent · placeholder",
    placeholder: true,
  },
];

export const FAQS = [
  {
    q: "Which classes are available?",
    a: "Mathematics is taught for Classes 7 to 12 and Physics for Classes 7 to 10. If you are unsure which programme suits your child, submit an enquiry and mention it in the message.",
  },
  {
    q: "Which subjects and boards are taught?",
    a: "MATHLETICS teaches Mathematics and Physics only, for both CBSE and ICSE students. No other subjects are offered.",
  },
  {
    q: "What are the batch options?",
    a: "Group tuition batches are available on weekdays and on weekends. One-on-one private tuition is also available. Contact the coaching team or submit an enquiry to find the option that suits your child.",
  },
  {
    q: "Can my child attend a demo class?",
    a: "Yes, a demo class is available. Mention it in your admission enquiry or call the coaching team to arrange it.",
  },
  {
    q: "Where do the classes take place?",
    a: "Group classes are held in a spacious hall fitted with benches and air conditioning, so students can study comfortably.",
  },
  {
    q: "How can I enquire about admission?",
    a: "Use the admission form on this page. It takes a few minutes and is split into short steps: student details, academic details and contact details. You can also call the coaching team on the numbers shown in the footer.",
  },
  {
    q: "How does the admission process work?",
    a: "You submit the admission form, the coaching team reviews every enquiry, and the coaching head makes the final decision. Submitting the form is a request for admission — it does not guarantee a place.",
  },
  {
    q: "Can parents contact the coaching team?",
    a: "Yes. The phone numbers are shown in the footer. You can also submit an enquiry and the team will review it using the contact details you provide.",
  },
];

/** Options shown in the admission form. Edit to match what the institution really offers. */
export const ADMISSION_OPTIONS = {
  classes: ["Class 7", "Class 8", "Class 9", "Class 10", "Class 11", "Class 12"],
  subjects: ["Mathematics", "Physics"],
  learningModes: ["Group batch — weekdays", "Group batch — weekends", "One-on-one (private)", "Demo class first", "Not sure yet"],
};
