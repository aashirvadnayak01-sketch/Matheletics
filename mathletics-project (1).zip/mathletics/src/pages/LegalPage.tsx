import { useEffect, type ReactNode } from "react";
import { Link } from "react-router-dom";

function Page({ title, children }: { title: string; children: ReactNode }) {
  useEffect(() => {
    document.title = `${title} — MATHLETICS`;
    window.scrollTo(0, 0);
  }, [title]);
  return (
    <main className="wrap max-w-3xl pb-20 pt-32">
      <p className="eyebrow mb-3 text-tangerine">MATHLETICS</p>
      <h1 className="text-4xl font-bold text-royal sm:text-5xl">{title}</h1>
      <p className="mt-3 rounded-2xl bg-tangerine/20 p-4 text-sm font-semibold text-royal">
        Draft for review: this text describes how this website handles enquiry data. Have it reviewed and finalised by the
        institution (and a legal adviser if required) before launch.
      </p>
      <div className="mt-8 space-y-5 text-lg leading-relaxed text-midnight/80 [&_h2]:mt-8 [&_h2]:font-display [&_h2]:text-2xl [&_h2]:font-bold [&_h2]:text-royal [&_ul]:list-disc [&_ul]:space-y-1 [&_ul]:pl-6">
        {children}
      </div>
      <p className="mt-12"><Link to="/" className="font-bold text-cobalt underline">← Back to home</Link></p>
    </main>
  );
}

export function Privacy() {
  return (
    <Page title="Privacy Policy">
      <p>This policy explains what information is collected when you submit an admission enquiry on this website, and how it is used.</p>
      <h2>What we collect</h2>
      <ul>
        <li>Student full name, parent/guardian name, current class and subjects of interest.</li>
        <li>Mobile number and email address.</li>
        <li>Preferred learning mode and any message you choose to write (optional).</li>
        <li>The date and time of submission. For abuse prevention we also store a one-way hash of your network address — never the address itself.</li>
      </ul>
      <h2>Why we collect it</h2>
      <p>Only to review your admission enquiry, to contact you about it, and to prevent spam and misuse of the form. We do not sell your information.</p>
      <h2>Who can see it</h2>
      <p>Authorised members of the MATHLETICS coaching team can view enquiries through a protected administration area. Email notifications are sent through a transactional email provider and enquiry data is stored with our database provider.</p>
      <h2>Your choices</h2>
      <p>You may ask the coaching team to correct or delete the details you submitted. Contact details are published on this website once available.</p>
    </Page>
  );
}

export function Terms() {
  return (
    <Page title="Terms & Conditions">
      <p>By using this website you agree to the following.</p>
      <h2>Admission enquiries</h2>
      <p>Submitting the admission form is a request for consideration only. It does not guarantee a place. The coaching head reviews every enquiry and makes the final decision.</p>
      <h2>Accuracy of information</h2>
      <p>Please provide accurate details so that the coaching team can reach you.</p>
      <h2>Acceptable use</h2>
      <p>Do not submit false, abusive or automated enquiries. Submissions that appear to be spam may be discarded.</p>
      <h2>Website content</h2>
      <p>Programme details, results and testimonials are published by the institution and may change without notice.</p>
    </Page>
  );
}
