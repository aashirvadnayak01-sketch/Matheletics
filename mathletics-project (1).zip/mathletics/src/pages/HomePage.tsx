import { useEffect } from "react";
import { About } from "../components/About";
import { AdmissionForm } from "../components/admission/AdmissionForm";
import { FAQ } from "../components/FAQ";
import { FinalCTA } from "../components/FinalCTA";
import { Hero } from "../components/Hero";
import { Intro } from "../components/Intro";
import { Journey } from "../components/Journey";
import { Programmes } from "../components/Programmes";
import { Results } from "../components/Results";
import { Testimonials } from "../components/Testimonials";
import { WhyChoose } from "../components/WhyChoose";

export default function HomePage() {
  useEffect(() => {
    document.title = "MATHLETICS — Where mathematical intelligence meets academic excellence";
  }, []);

  return (
    <>
      <Intro />
      <Hero />
      <About />
      <Programmes />
      <WhyChoose />
      <Journey />
      <Results />
      <Testimonials />
      <AdmissionForm />
      <FAQ />
      <FinalCTA />
    </>
  );
}
