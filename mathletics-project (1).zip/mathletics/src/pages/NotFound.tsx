import { useEffect } from "react";
import { Link } from "react-router-dom";
import { MMark } from "../components/Logo";

export default function NotFound() {
  useEffect(() => {
    document.title = "Page not found — MATHLETICS";
  }, []);
  return (
    <main className="grid min-h-[80vh] place-items-center px-6 pb-16 pt-32 text-center">
      <div>
        <MMark size={72} className="mx-auto" />
        <p className="eyebrow mt-8 text-tangerine">Error 404</p>
        <h1 className="mt-3 text-5xl font-bold text-royal sm:text-7xl">
          This page doesn't <span className="font-serif font-normal italic text-cobalt">add up.</span>
        </h1>
        <p className="mx-auto mt-5 max-w-md text-lg text-midnight/70">
          The page you are looking for does not exist or has been moved.
        </p>
        <Link to="/" className="btn btn-cobalt mt-8">Back to home</Link>
      </div>
    </main>
  );
}
