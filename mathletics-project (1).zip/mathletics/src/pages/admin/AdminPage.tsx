import type { Session } from "@supabase/supabase-js";
import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { Link } from "react-router-dom";
import { LogoLockup } from "../../components/Logo";
import { isSupabaseConfigured, supabase } from "../../lib/supabase";
import { Dashboard } from "./Dashboard";

type Gate = "loading" | "signed-out" | "not-admin" | "admin";

/**
 * /admin — front-end gate. The REAL protection is server-side: Row Level Security only
 * returns enquiry rows to users listed in public.admins, so even a tampered browser sees nothing.
 */
export default function AdminPage() {
  const [session, setSession] = useState<Session | null>(null);
  const [gate, setGate] = useState<Gate>("loading");

  useEffect(() => {
    document.title = "Admin — MATHLETICS";
    const meta = document.createElement("meta");
    meta.name = "robots";
    meta.content = "noindex,nofollow";
    document.head.appendChild(meta);
    return () => {
      meta.remove();
    };
  }, []);

  useEffect(() => {
    if (!supabase) {
      setGate("signed-out");
      return;
    }
    let cancelled = false;

    const evaluate = async (s: Session | null) => {
      if (cancelled) return;
      setSession(s);
      if (!s) return setGate("signed-out");
      const { data, error } = await supabase!.from("admins").select("user_id").eq("user_id", s.user.id).maybeSingle();
      if (cancelled) return;
      setGate(!error && data ? "admin" : "not-admin");
    };

    supabase.auth.getSession().then(({ data }) => evaluate(data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      // defer to avoid calling supabase inside the auth callback synchronously
      setTimeout(() => evaluate(s), 0);
    });
    return () => {
      cancelled = true;
      sub.subscription.unsubscribe();
    };
  }, []);

  const logout = async () => {
    await supabase?.auth.signOut();
    setSession(null);
    setGate("signed-out");
  };

  if (gate === "loading") {
    return <div className="grid min-h-screen place-items-center bg-lavender/40 text-royal" role="status">Loading…</div>;
  }
  if (gate === "admin" && session) return <Dashboard session={session} onLogout={logout} />;
  if (gate === "not-admin") {
    return (
      <Shell>
        <h1 className="text-2xl font-bold text-royal">Not authorised</h1>
        <p className="mt-3 text-midnight/70">
          You are signed in as <b>{session?.user.email}</b>, but this account has not been set up as an administrator.
        </p>
        <button className="btn btn-cobalt mt-6" onClick={logout}>Sign out</button>
      </Shell>
    );
  }
  return <Login />;
}

function Shell({ children }: { children: ReactNode }) {
  return (
    <main className="grid min-h-screen place-items-center bg-lavender/40 px-4 py-10">
      <div className="w-full max-w-md rounded-[2rem] bg-ivory p-8 shadow-[0_40px_80px_-40px_rgba(23,43,103,0.55)] ring-1 ring-royal/10">
        <div className="mb-8"><LogoLockup /></div>
        {children}
        <p className="mt-8 text-sm"><Link to="/" className="font-bold text-cobalt underline">← Back to website</Link></p>
      </div>
    </main>
  );
}

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!supabase || busy) return;
    setBusy(true);
    setError("");
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (error) setError("Sign-in failed. Check your email and password.");
    setBusy(false);
  };

  return (
    <Shell>
      <h1 className="text-3xl font-bold text-royal">Administrator sign-in</h1>
      <p className="mt-2 text-midnight/65">For the MATHLETICS coaching head and authorised staff only.</p>

      {!isSupabaseConfigured && (
        <p role="alert" className="mt-5 rounded-2xl bg-tangerine/20 p-4 text-sm font-semibold text-royal">
          Setup needed: VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are not set, so sign-in is unavailable.
        </p>
      )}

      <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
        <div>
          <label htmlFor="admin-email" className="mb-1.5 block font-display text-sm font-bold text-royal">Email</label>
          <input id="admin-email" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)}
            className="block min-h-[3.25rem] w-full rounded-2xl border-2 border-royal/15 bg-ivory px-4 outline-none focus:border-cobalt focus:ring-4 focus:ring-cobalt/15" />
        </div>
        <div>
          <label htmlFor="admin-password" className="mb-1.5 block font-display text-sm font-bold text-royal">Password</label>
          <input id="admin-password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)}
            className="block min-h-[3.25rem] w-full rounded-2xl border-2 border-royal/15 bg-ivory px-4 outline-none focus:border-cobalt focus:ring-4 focus:ring-cobalt/15" />
        </div>
        {error && <p role="alert" className="text-sm font-semibold text-[#c2410c]">{error}</p>}
        <button type="submit" className="btn btn-cobalt w-full" disabled={busy || !isSupabaseConfigured || !email || !password}>
          {busy ? "Signing in…" : "Sign in"}
        </button>
      </form>
    </Shell>
  );
}
