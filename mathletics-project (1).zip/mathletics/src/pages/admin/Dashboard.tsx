import type { Session } from "@supabase/supabase-js";
import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { LogoLockup } from "../../components/Logo";
import { supabase } from "../../lib/supabase";
import { formatDateTime, type Enquiry, type EnquiryStatus } from "../../lib/types";
import { EnquiryDrawer } from "./EnquiryDrawer";
import { StatusBadge } from "./StatusBadge";

const PAGE_SIZE = 25;

interface Counts { total: number; PENDING: number; APPROVED: number; REJECTED: number }

export function Dashboard({ session, onLogout }: { session: Session; onLogout: () => void }) {
  const [rows, setRows] = useState<Enquiry[]>([]);
  const [total, setTotal] = useState(0);
  const [counts, setCounts] = useState<Counts | null>(null);
  const [status, setStatus] = useState<EnquiryStatus | "ALL">("ALL");
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selected, setSelected] = useState<Enquiry | null>(null);

  useEffect(() => {
    const t = setTimeout(() => { setDebounced(search); setPage(0); }, 300);
    return () => clearTimeout(t);
  }, [search]);

  const loadCounts = useCallback(async () => {
    if (!supabase) return;
    const head = (s?: EnquiryStatus) => {
      const q = supabase!.from("enquiries").select("id", { count: "exact", head: true });
      return s ? q.eq("status", s) : q;
    };
    const [t, p, a, r] = await Promise.all([head(), head("PENDING"), head("APPROVED"), head("REJECTED")]);
    if (t.error) return;
    setCounts({ total: t.count ?? 0, PENDING: p.count ?? 0, APPROVED: a.count ?? 0, REJECTED: r.count ?? 0 });
  }, []);

  const loadRows = useCallback(async () => {
    if (!supabase) return;
    setLoading(true);
    setError("");
    let q = supabase.from("enquiries").select("*", { count: "exact" }).order("created_at", { ascending: false });
    if (status !== "ALL") q = q.eq("status", status);
    // strip characters that have meaning in PostgREST filter syntax
    const term = debounced.replace(/[,()%*\\:]/g, " ").trim();
    if (term) {
      q = q.or(`student_name.ilike.%${term}%,parent_name.ilike.%${term}%,mobile.ilike.%${term}%,email.ilike.%${term}%,enquiry_code.ilike.%${term}%`);
    }
    const from = page * PAGE_SIZE;
    const { data, error, count } = await q.range(from, from + PAGE_SIZE - 1);
    if (error) setError("Could not load enquiries. " + error.message);
    else { setRows((data ?? []) as Enquiry[]); setTotal(count ?? 0); }
    setLoading(false);
  }, [status, debounced, page]);

  useEffect(() => { void loadCounts(); }, [loadCounts]);
  useEffect(() => { void loadRows(); }, [loadRows]);

  const onChanged = (updated: Enquiry) => {
    setSelected(updated);
    setRows((rs) => rs.map((r) => (r.id === updated.id ? updated : r)));
    void loadCounts();
  };

  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const stat = (label: string, value: number | undefined, tone: string, filter: EnquiryStatus | "ALL") => (
    <button
      type="button"
      onClick={() => { setStatus(filter); setPage(0); }}
      aria-pressed={status === filter}
      className={`rounded-3xl p-5 text-left transition hover:-translate-y-1 ${tone} ${status === filter ? "ring-4 ring-royal/30" : ""}`}
    >
      <p className="eyebrow !text-[0.65rem] opacity-80">{label}</p>
      <p className="mt-2 font-display text-4xl font-bold">{value ?? "–"}</p>
    </button>
  );

  return (
    <div className="min-h-screen bg-lavender/40">
      <header className="border-b border-royal/10 bg-ivory">
        <div className="wrap flex h-16 items-center justify-between">
          <div className="flex items-center gap-4">
            <LogoLockup size={32} />
            <span className="hidden rounded-full bg-royal px-3 py-1 text-[0.65rem] font-bold uppercase tracking-widest text-ivory sm:inline">Admin</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden max-w-[14rem] truncate text-sm text-midnight/60 md:inline">{session.user.email}</span>
            <Link to="/" className="hidden text-sm font-bold text-cobalt underline sm:inline">View site</Link>
            <button onClick={onLogout} className="btn btn-ghost !min-h-10 !px-4 !text-[0.68rem] text-royal">Log out</button>
          </div>
        </div>
      </header>

      <main className="wrap py-8">
        <h1 className="text-3xl font-bold text-royal sm:text-4xl">Admission enquiries</h1>

        <div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
          {stat("Total enquiries", counts?.total, "bg-ivory text-royal ring-1 ring-royal/10", "ALL")}
          {stat("Pending", counts?.PENDING, "bg-tangerine text-midnight", "PENDING")}
          {stat("Approved", counts?.APPROVED, "bg-mint text-royal", "APPROVED")}
          {stat("Rejected", counts?.REJECTED, "bg-royal text-ivory", "REJECTED")}
        </div>

        <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <label htmlFor="search" className="sr-only">Search enquiries</label>
            <input id="search" type="search" value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, mobile, email or enquiry ID…"
              className="block min-h-12 w-full rounded-full border-2 border-royal/15 bg-ivory px-5 outline-none focus:border-cobalt focus:ring-4 focus:ring-cobalt/15" />
          </div>
          <div>
            <label htmlFor="status" className="sr-only">Filter by status</label>
            <select id="status" value={status} onChange={(e) => { setStatus(e.target.value as EnquiryStatus | "ALL"); setPage(0); }}
              className="min-h-12 w-full rounded-full border-2 border-royal/15 bg-ivory px-5 font-semibold outline-none focus:border-cobalt sm:w-auto">
              <option value="ALL">All statuses</option>
              <option value="PENDING">Pending</option>
              <option value="APPROVED">Approved</option>
              <option value="REJECTED">Rejected</option>
            </select>
          </div>
          <button onClick={() => { void loadRows(); void loadCounts(); }} className="btn btn-ghost !min-h-12 text-royal">Refresh</button>
        </div>

        {error && <p role="alert" className="mt-6 rounded-2xl bg-[#c2410c]/10 p-4 font-semibold text-[#9a3412]">{error}</p>}

        <div className="mt-6 overflow-hidden rounded-3xl bg-ivory ring-1 ring-royal/10">
          <h2 className="border-b border-royal/10 px-5 py-4 font-display text-lg font-bold text-royal">
            {status === "ALL" && !debounced ? "Recent applications" : "Results"} <span className="text-midnight/45">({total})</span>
          </h2>

          {loading ? (
            <p className="p-10 text-center text-midnight/60" role="status">Loading enquiries…</p>
          ) : rows.length === 0 ? (
            <p className="p-10 text-center text-midnight/60">
              {total === 0 && status === "ALL" && !debounced ? "No enquiries yet. New submissions will appear here." : "No enquiries match your filters."}
            </p>
          ) : (
            <>
              {/* desktop table */}
              <table className="hidden w-full text-left text-sm md:table">
                <thead className="bg-lavender/50 text-xs uppercase tracking-wider text-midnight/55">
                  <tr>
                    <th className="px-5 py-3">Enquiry</th><th className="px-3 py-3">Student</th><th className="px-3 py-3">Class</th>
                    <th className="px-3 py-3">Submitted</th><th className="px-3 py-3">Email</th><th className="px-3 py-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.id} className="cursor-pointer border-t border-royal/10 hover:bg-lavender/40" onClick={() => setSelected(r)}>
                      <td className="px-5 py-3 font-display font-bold text-royal">
                        <button className="underline-offset-2 hover:underline" onClick={(e) => { e.stopPropagation(); setSelected(r); }}>{r.enquiry_code}</button>
                      </td>
                      <td className="px-3 py-3"><span className="font-bold">{r.student_name}</span><br /><span className="text-midnight/55">{r.parent_name}</span></td>
                      <td className="px-3 py-3">{r.current_class}</td>
                      <td className="px-3 py-3 whitespace-nowrap">{formatDateTime(r.created_at)}</td>
                      <td className="px-3 py-3">
                        {r.notify_status === "FAILED" && <span className="mr-1 text-xs font-bold text-[#c2410c]" title={r.notify_error ?? ""}>⚠ email failed</span>}
                        {r.notify_status === "NOT_CONFIGURED" && <span className="text-xs font-bold text-[#c2410c]">⚠ email not set up</span>}
                        {r.notify_status === "SENT" && <span className="text-xs text-midnight/45">notified</span>}
                      </td>
                      <td className="px-3 py-3"><StatusBadge status={r.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* mobile cards */}
              <ul className="divide-y divide-royal/10 md:hidden">
                {rows.map((r) => (
                  <li key={r.id}>
                    <button className="flex w-full items-start justify-between gap-3 p-5 text-left" onClick={() => setSelected(r)}>
                      <span>
                        <span className="block font-display text-sm font-bold text-cobalt">{r.enquiry_code}</span>
                        <span className="block font-bold text-royal">{r.student_name}</span>
                        <span className="block text-sm text-midnight/55">{r.current_class} · {formatDateTime(r.created_at)}</span>
                        {(r.notify_status === "FAILED" || r.notify_status === "NOT_CONFIGURED") && <span className="mt-1 block text-xs font-bold text-[#c2410c]">⚠ email not delivered</span>}
                      </span>
                      <StatusBadge status={r.status} />
                    </button>
                  </li>
                ))}
              </ul>

              {pages > 1 && (
                <div className="flex items-center justify-between border-t border-royal/10 px-5 py-4 text-sm">
                  <button className="btn btn-ghost !min-h-10 !px-4 text-royal" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Previous</button>
                  <span className="font-semibold text-midnight/60">Page {page + 1} of {pages}</span>
                  <button className="btn btn-ghost !min-h-10 !px-4 text-royal" disabled={page + 1 >= pages} onClick={() => setPage((p) => p + 1)}>Next</button>
                </div>
              )}
            </>
          )}
        </div>
      </main>

      {selected && <EnquiryDrawer enquiry={selected} onClose={() => setSelected(null)} onChanged={onChanged} />}
    </div>
  );
}
