import type { EnquiryStatus } from "../../lib/types";

const STATUS_STYLE: Record<EnquiryStatus, string> = {
  PENDING: "bg-tangerine/25 text-[#9a3412]",
  APPROVED: "bg-mint text-royal",
  REJECTED: "bg-[#c2410c]/15 text-[#9a3412]",
};

export function StatusBadge({ status }: { status: EnquiryStatus }) {
  return (
    <span className={`inline-block rounded-full px-3 py-1 text-[0.68rem] font-bold tracking-widest ${STATUS_STYLE[status]}`}>
      {status}
    </span>
  );
}
