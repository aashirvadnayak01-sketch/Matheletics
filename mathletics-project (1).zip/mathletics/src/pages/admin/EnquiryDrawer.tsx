import { FunctionsHttpError } from "@supabase/supabase-js";
import { useEffect, useState, type ReactNode } from "react";
import { supabase } from "../../lib/supabase";
import { formatDateTime, type Enquiry, type EnquiryStatus } from "../../lib/types";
import { StatusBadge } from "./StatusBadge";

interface Props {
  enquiry: Enquiry;
  onClose: () => void;
  onChanged: (e: Enquiry) => void;
}

async function callAdminEmail(action: "retry_notification" | "decision", enquiryId: string): Promise<string | null> {
  if (!supabase) return "Supabase is not configured.";
  const { error } = await supabase.functions.invoke("admin-email", { body: { action, enquiryId } });
  if (!error) return null;
  if (error instanceof FunctionsHttpError) {
    try {
      const b = await error.context.json();
      return b.error ?? "Email request failed.";
    } catch { /* fall through */ }
  }
  return "Could not reach the email service.";
}

export function EnquiryDrawer({ enquiry, onClose, onChanged }: Props) {
  const [notes, setNotes] = useState(enquiry.admin_notes ?? "");
  const [sendEmail, setSendEmail] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState<{ type: "ok" | "err"; text: string } | null>(null);

  useEffect(() => {
    setNotes(enquiry.admin_notes ?? "");
    setMessage(null);
  }, [enquiry.id]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = prev; };
  }, [onClose]);

  const refetch = async (): Promise<Enquiry | null> => {
    const { data } = await supabase!.from("enquiries").select("*").eq("id", enquiry.id).single();
    return (data as Enquiry) ?? null;
  };

  const saveNotes = async () => {
    if (!supabase) return;
    setBusy("notes"); setMessage(null);
    const { data, error } = await supabase.from("enquiries").update({ admin_notes: notes.trim() || null }).eq("id", enquiry.id).select("*").single();
    setBusy(null);
    if (error || !data) return setMessage({ type: "err", text: "Could not save notes. " + (error?.message ?? "") });
    onChanged(data as Enquiry);
    setMessage({ type: "ok", text: "Notes saved." });
  };

  const setStatus = async (next: EnquiryStatus) => {
    if (!supabase || next === enquiry.status) return;
    if (next !== "PENDING") {
      const word = next === "APPROVED" ? "approve" : "reject";
      if (!window.confirm(`Are you sure you want to ${word} this enquiry${sendEmail ? " and email the family" : ""}?`)) return;
    }
    setBusy(next); setMessage(null);
    const { data, error } = await supabase.from("enquiries").update({ status: next, admin_notes: notes.trim() || null }).eq("id", enquiry.id).select("*").single();
    if (error || !data) {
      setBusy(null);
      return setMessage({ type: "err", text: "Could not update the status. " + (error?.message ?? "") });
    }
    let updated = data as Enquiry;
    onChanged(updated);

    if (next !== "PENDING" && sendEmail) {
      const err = await callAdminEmail("decision", enquiry.id);
      const fresh = await refetch();
      if (fresh) { updated = fresh; onChanged(fresh); }
      setMessage(err ? { type: "err", text: `Status saved as ${next}, but the email to the family was not sent: ${err}` } : { type: "ok", text: `Status set to ${next} and the family was emailed.` });
    } else {
      setMessage({ type: "ok", text: `Status set to ${next}.` });
    }
    setBusy(null);
  };

  const retryNotify = async () => {
    setBusy("retry"); setMessage(null);
    const err = await callAdminEmail("retry_notification", enquiry.id);
    const fresh = await refetch();
    if (fresh) onChanged(fresh);
    setBusy(null);
    setMessage(err ? { type: "err", text: err } : { type: "ok", text: "Notification email sent." });
  };

  const row = (k: string, v: ReactNode) => (
    <div className="flex flex-col gap-0.5 py-3 sm:flex-row sm:justify-between sm:gap-6">
      <dt className="text-sm font-semibold text-midnight/55">{k}</dt>
      <dd className="break-words font-bold text-royal sm:text-right">{v}</dd>
    </div>
  );

  const e = enquiry;
  const emailProblem = e.notify_status === "FAILED" || e.notify_status === "NOT_CONFIGURED" || e.notify_status === "PENDING";

  return (
    <div className="fixed inset-0 z-50 flex justify-end" role="dialog" aria-modal="true" aria-label={`Enquiry ${e.enquiry_code}`}>
      <button className="absolute inset-0 bg-midnight/60" onClick={onClose} aria-label="Close details" tabIndex={-1} />
      <aside className="relative flex h-full w-full max-w-xl flex-col overflow-y-auto bg-ivory shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-royal/10 bg-ivory px-6 py-4">
          <div>
            <p className="font-display text-lg font-bold text-royal">{e.enquiry_code}</p>
            <p className="text-xs text-midnight/55">Submitted {formatDateTime(e.created_at)}</p>
          </div>
          <div className="flex items-center gap-3">
            <StatusBadge status={e.status} />
            <button onClick={onClose} className="grid size-10 place-items-center rounded-full bg-lavender text-xl font-bold text-royal" aria-label="Close">×</button>
          </div>
        </div>

        <div className="space-y-6 p-6">
          <dl className="divide-y divide-royal/10 rounded-2xl bg-lavender/40 px-5">
            {row("Student", e.student_name)}
            {row("Parent / guardian", e.parent_name)}
            {row("Mobile", <a className="text-cobalt underline" href={`tel:+91${e.mobile}`}>+91 {e.mobile}</a>)}
            {row("Email", <a className="text-cobalt underline" href={`mailto:${e.email}`}>{e.email}</a>)}
            {row("Class", e.current_class)}
            {row("Subjects", e.subjects.join(", "))}
            {row("Learning mode", e.learning_mode ?? "No preference")}
            {row("Submitted", formatDateTime(e.created_at))}
            {e.decided_at && row("Decision date", formatDateTime(e.decided_at))}
          </dl>

          <div>
            <h3 className="mb-2 font-display text-sm font-bold text-royal">Message from family</h3>
            {/* rendered as plain text — React escapes it, never as HTML */}
            <p className="whitespace-pre-wrap rounded-2xl bg-lavender/40 p-4 text-sm leading-relaxed">{e.message || "No message provided."}</p>
          </div>

          <div className={`rounded-2xl p-4 text-sm ${emailProblem ? "bg-[#c2410c]/10" : "bg-mint/50"}`}>
            <p className="font-bold text-royal">
              Coaching-head notification email:{" "}
              {e.notify_status === "SENT" ? `sent ${e.notify_sent_at ? formatDateTime(e.notify_sent_at) : ""}` : e.notify_status === "NOT_CONFIGURED" ? "not configured" : e.notify_status === "FAILED" ? "FAILED" : "pending"}
            </p>
            {e.notify_error && <p className="mt-1 break-words text-xs text-[#9a3412]">{e.notify_error}</p>}
            {e.notify_status !== "SENT" && (
              <button onClick={retryNotify} disabled={busy !== null} className="btn btn-cobalt mt-3 !min-h-10 !px-4 !text-[0.68rem]">
                {busy === "retry" ? "Sending…" : "Retry notification"}
              </button>
            )}
            {e.decision_email_status !== "NOT_SENT" && (
              <p className="mt-3 text-xs font-semibold text-midnight/70">
                Decision email to family: {e.decision_email_status === "SENT" ? "sent" : e.decision_email_status === "FAILED" ? `failed — ${e.decision_email_error ?? ""}` : "not configured"}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="notes" className="mb-2 block font-display text-sm font-bold text-royal">Internal notes <span className="font-normal text-midnight/50">(never shown to the family)</span></label>
            <textarea id="notes" rows={4} maxLength={4000} value={notes} onChange={(ev) => setNotes(ev.target.value)}
              className="block w-full rounded-2xl border-2 border-royal/15 bg-ivory p-4 text-sm outline-none focus:border-cobalt focus:ring-4 focus:ring-cobalt/15" />
            <button onClick={saveNotes} disabled={busy !== null || notes === (e.admin_notes ?? "")} className="btn btn-ghost mt-3 !min-h-10 !px-4 !text-[0.68rem] text-royal">
              {busy === "notes" ? "Saving…" : "Save notes"}
            </button>
          </div>

          <div className="rounded-2xl border-2 border-royal/10 p-5">
            <h3 className="font-display text-sm font-bold text-royal">Decision</h3>
            <p className="mt-1 text-xs text-midnight/60">Submitting the form never admits anyone. Only you decide.</p>
            <label className="mt-4 flex cursor-pointer items-start gap-3 text-sm">
              <input type="checkbox" className="mt-0.5 size-5 accent-[#315FE8]" checked={sendEmail} onChange={(ev) => setSendEmail(ev.target.checked)} />
              <span>Also email the parent/student about an approval or rejection</span>
            </label>
            <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-3">
              <button onClick={() => setStatus("APPROVED")} disabled={busy !== null || e.status === "APPROVED"} className="btn btn-cobalt !px-3">{busy === "APPROVED" ? "…" : "Approve"}</button>
              <button onClick={() => setStatus("REJECTED")} disabled={busy !== null || e.status === "REJECTED"} className="btn btn-ghost !px-3 text-[#9a3412]">{busy === "REJECTED" ? "…" : "Reject"}</button>
              <button onClick={() => setStatus("PENDING")} disabled={busy !== null || e.status === "PENDING"} className="btn btn-tangerine !px-3">{busy === "PENDING" ? "…" : "Mark pending"}</button>
            </div>
          </div>

          {message && (
            <p role={message.type === "err" ? "alert" : "status"} className={`rounded-2xl p-4 text-sm font-semibold ${message.type === "err" ? "bg-[#c2410c]/10 text-[#9a3412]" : "bg-mint/60 text-royal"}`}>
              {message.text}
            </p>
          )}
        </div>
      </aside>
    </div>
  );
}
