import { AnimatePresence, motion } from "framer-motion";
import { lazy, Suspense, useEffect } from "react";
import { Route, Routes, useLocation } from "react-router-dom";
import { Footer } from "./components/Footer";
import { Navbar } from "./components/Navbar";
import { EnquiryProvider } from "./lib/enquiryContext";
import { scrollToId } from "./lib/nav";
import HomePage from "./pages/HomePage";
import { Privacy, Terms } from "./pages/LegalPage";
import NotFound from "./pages/NotFound";
import { isCrawler } from "./lib/crawler";

// The admin area is code-split so public visitors never download it.
const AdminPage = lazy(() => import("./pages/admin/AdminPage"));

/** Scrolls to #hash after navigation (e.g. from /privacy back to /#faq), else to top. */
function ScrollManager() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) {
      const id = hash.slice(1);
      // wait a tick so the target section has mounted
      const t = window.setTimeout(() => scrollToId(id), 80);
      return () => window.clearTimeout(t);
    }
    if (pathname !== "/") window.scrollTo(0, 0);
  }, [pathname, hash]);
  return null;
}

function PublicLayout() {
  const location = useLocation();
  return (
    <>
      <Navbar />
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={location.pathname}
          initial={isCrawler() ? false : { opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
        >
          <Routes location={location}>
            <Route path="/" element={<HomePage />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </motion.div>
      </AnimatePresence>
      <Footer />
    </>
  );
}

export default function App() {
  const { pathname } = useLocation();
  const isAdmin = pathname === "/admin" || pathname.startsWith("/admin/");

  return (
    <EnquiryProvider>
      <ScrollManager />
      {isAdmin ? (
        <Suspense fallback={<div className="grid min-h-screen place-items-center text-royal" role="status">Loading…</div>}>
          <AdminPage />
        </Suspense>
      ) : (
        <PublicLayout />
      )}
    </EnquiryProvider>
  );
}
