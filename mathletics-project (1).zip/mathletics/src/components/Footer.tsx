import { Link } from "react-router-dom";
import { PROGRAMMES, SITE } from "../content/siteContent";
import { useAnchorNav } from "../lib/nav";
import { LogoLockup } from "./Logo";

const NAV = [
  { id: "about", label: "About" },
  { id: "programmes", label: "Programmes" },
  { id: "why", label: "Why Choose Us" },
  { id: "journey", label: "Learning Journey" },
  { id: "results", label: "Results" },
  { id: "faq", label: "FAQ" },
  { id: "admission", label: "Admission" },
];

export function Footer() {
  const go = useAnchorNav();
  const { contact, social } = SITE;
  const socials = (Object.entries(social) as [string, string][]).filter(([, url]) => url);
  const hasContact = Boolean(contact.phone || contact.email || contact.address || contact.hours);

  return (
    <footer id="contact" className="relative overflow-hidden bg-midnight text-ivory">
      <div className="dot-grid-light pointer-events-none absolute inset-0 opacity-30" aria-hidden="true" />
      <div className="wrap relative grid gap-12 py-16 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
        <div>
          <LogoLockup tone="light" size={44} />
          <p className="mt-5 max-w-xs leading-relaxed text-ivory/70">{SITE.shortDescription}</p>
          <p className="mt-4 font-serif text-xl italic text-tangerine">{SITE.tagline}</p>
        </div>

        <nav aria-label="Footer navigation">
          <h3 className="eyebrow mb-4 text-mint">Explore</h3>
          <ul className="space-y-1">
            {NAV.map((n) => (
              <li key={n.id}>
                <a
                  href={`/#${n.id}`}
                  onClick={(e) => {
                    e.preventDefault();
                    go(n.id);
                  }}
                  className="inline-flex min-h-10 items-center text-ivory/80 transition hover:text-tangerine"
                >
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h3 className="eyebrow mb-4 text-mint">Programmes</h3>
          <ul className="space-y-1">
            {PROGRAMMES.length === 0 && <li className="text-ivory/60">Coming soon</li>}
            {PROGRAMMES.map((p) => (
              <li key={p.id}>
                <a
                  href="/#programmes"
                  onClick={(e) => {
                    e.preventDefault();
                    go("programmes");
                  }}
                  className="inline-flex min-h-10 items-center text-ivory/80 transition hover:text-tangerine"
                >
                  {p.name}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="eyebrow mb-4 text-mint">Contact</h3>
          {hasContact ? (
            <ul className="space-y-3 text-ivory/80">
              {contact.phone &&
                contact.phone.split("|").map((ph) => (
                  <li key={ph}>
                    <a className="hover:text-tangerine" href={`tel:${ph.trim().replace(/\s/g, "")}`}>{ph.trim()}</a>
                  </li>
                ))}
              {contact.email && (
                <li>
                  <a className="break-all hover:text-tangerine" href={`mailto:${contact.email}`}>{contact.email}</a>
                </li>
              )}
              {contact.address && <li>{contact.address}</li>}
              {contact.hours && <li>{contact.hours}</li>}
            </ul>
          ) : (
            <p className="text-ivory/60">
              Contact details will be published here soon. Please use the admission form to reach the coaching team.
            </p>
          )}

          {socials.length > 0 && (
            <ul className="mt-5 flex flex-wrap gap-2">
              {socials.map(([name, url]) => (
                <li key={name}>
                  <a
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-10 items-center rounded-full border border-ivory/30 px-4 text-sm font-semibold capitalize transition hover:bg-ivory hover:text-midnight"
                  >
                    {name}
                  </a>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="relative border-t border-ivory/15">
        <div className="wrap flex flex-col items-start justify-between gap-3 py-6 text-sm text-ivory/60 sm:flex-row sm:items-center">
          <p>© {new Date().getFullYear()} MATHLETICS. All rights reserved.</p>
          <ul className="flex gap-5">
            <li><Link to="/privacy" className="hover:text-tangerine">Privacy Policy</Link></li>
            <li><Link to="/terms" className="hover:text-tangerine">Terms &amp; Conditions</Link></li>
          </ul>
        </div>
      </div>
    </footer>
  );
}
