import { isCrawler } from "../lib/crawler";
import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { PROGRAMMES } from "../content/siteContent";
import { useEnquiry } from "../lib/enquiryContext";
import { scrollToId } from "../lib/nav";
import { Reveal } from "./ui/Reveal";
import { ArrowRight } from "./ui/Icons";

const ACCENTS = ["bg-cobalt", "bg-tangerine", "bg-mint"];

export function Programmes() {
  const { requestEnquiry } = useEnquiry();
  const [openId, setOpenId] = useState<string | null>(null);

  return (
    <section id="programmes" className="relative overflow-hidden bg-lavender/60 py-20 sm:py-28">
      <div className="dot-grid pointer-events-none absolute inset-0 opacity-60" aria-hidden="true" />
      <div className="wrap relative">
        <Reveal>
          <p className="eyebrow mb-4 text-cobalt">Academic Programmes</p>
          <h2 className="max-w-3xl text-4xl font-bold leading-[1.05] text-royal sm:text-6xl">
            Find the programme that fits <span className="font-serif font-normal italic text-cobalt">your child.</span>
          </h2>
        </Reveal>

        {PROGRAMMES.length === 0 ? (
          <p className="mt-12 rounded-3xl border-2 border-dashed border-royal/20 p-10 text-center text-royal/70">
            Programmes will be published here soon. In the meantime, submit an admission enquiry below.
          </p>
        ) : (
          <div className="mt-12 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {PROGRAMMES.map((p, i) => {
              const open = openId === p.id || isCrawler();   // crawlers cannot click: show details
              return (
                <Reveal key={p.id} delay={(i % 3) * 0.1}>
                  <motion.article
                    whileHover={{ y: -6 }}
                    className="flex h-full flex-col overflow-hidden rounded-[2rem] bg-ivory shadow-[0_24px_50px_-30px_rgba(23,43,103,0.6)] ring-1 ring-royal/10"
                  >
                    <div className={`relative h-28 ${ACCENTS[i % ACCENTS.length]}`}>
                      <div className="dot-grid-light absolute inset-0 opacity-70" aria-hidden="true" />
                      <span className="absolute bottom-3 left-6 font-display text-6xl font-bold text-ivory/30" aria-hidden="true">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      {p.placeholder && (
                        <span className="absolute right-4 top-4 rounded-full bg-ivory px-3 py-1 text-[0.65rem] font-bold uppercase tracking-widest text-royal">
                          Sample — editable
                        </span>
                      )}
                    </div>

                    <div className="flex flex-1 flex-col p-6 sm:p-7">
                      <p className="eyebrow !text-[0.68rem] text-tangerine">{p.classLabel}</p>
                      <h3 className="mt-2 text-2xl font-bold text-royal">{p.name}</h3>
                      <ul className="mt-3 flex flex-wrap gap-2" aria-label="Subjects">
                        {p.subjects.map((s) => (
                          <li key={s} className="rounded-full bg-lavender px-3 py-1 text-xs font-bold text-royal">
                            {s}
                          </li>
                        ))}
                      </ul>
                      <p className="mt-4 leading-relaxed text-midnight/70">{p.description}</p>

                      <AnimatePresence initial={false}>
                        {open && (
                          <motion.div
                            id={`details-${p.id}`}
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.3 }}
                            className="overflow-hidden"
                          >
                            <p className="mt-4 rounded-2xl bg-lavender/70 p-4 text-sm leading-relaxed text-royal">{p.details}</p>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      <div className="mt-auto flex flex-col gap-3 pt-6 sm:flex-row">
                        <button
                          type="button"
                          className="btn btn-ghost !min-h-12 flex-1 !px-4 text-royal"
                          aria-expanded={open}
                          aria-controls={`details-${p.id}`}
                          onClick={() => setOpenId(open ? null : p.id)}
                        >
                          {open ? "Show Less" : "Learn More"}
                        </button>
                        <button
                          type="button"
                          className="btn btn-cobalt !min-h-12 flex-1 !px-4"
                          onClick={() => {
                            requestEnquiry(p.name);
                            scrollToId("admission");
                          }}
                        >
                          Enquire Now <ArrowRight size={16} />
                        </button>
                      </div>
                    </div>
                  </motion.article>
                </Reveal>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
