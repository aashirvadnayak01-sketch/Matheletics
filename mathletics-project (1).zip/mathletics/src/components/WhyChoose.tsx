import { WHY_ITEMS } from "../content/siteContent";
import { Reveal } from "./ui/Reveal";
import { GeoIllustration } from "./ui/Icons";

export function WhyChoose() {
  return (
    <section id="why" className="relative overflow-hidden py-20 sm:py-28">
      <div className="wrap">
        <Reveal>
          <p className="eyebrow mb-4 text-tangerine">Why Choose MATHLETICS?</p>
          <h2 className="max-w-3xl text-4xl font-bold leading-[1.05] text-royal sm:text-6xl">
            Six reasons families <span className="font-serif font-normal italic text-cobalt">feel confident.</span>
          </h2>
        </Reveal>

        <ol className="mt-14 space-y-8 sm:space-y-12">
          {WHY_ITEMS.map((item, i) => {
            const flip = i % 2 === 1;
            return (
              <li key={item.title}>
                <div
                  className={`grid items-center gap-6 sm:gap-10 md:grid-cols-[1.1fr_0.9fr] ${
                    flip ? "md:[&>*:first-child]:order-2" : ""
                  }`}
                >
                  <Reveal x={flip ? 40 : -40} y={0}>
                    <div className="relative">
                      <span
                        className={`pointer-events-none absolute -top-8 font-display text-[7rem] font-bold leading-none sm:text-[10rem] ${
                          flip ? "right-0 text-tangerine/25" : "left-0 text-cobalt/15"
                        }`}
                        aria-hidden="true"
                      >
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <div className={`relative pt-12 sm:pt-16 ${flip ? "md:text-right" : ""}`}>
                        <h3 className="text-3xl font-bold text-royal sm:text-4xl">{item.title}</h3>
                        <p className={`mt-3 max-w-lg text-lg leading-relaxed text-midnight/70 ${flip ? "md:ml-auto" : ""}`}>
                          {item.text}
                        </p>
                      </div>
                    </div>
                  </Reveal>
                  <Reveal x={flip ? -40 : 40} y={0} delay={0.1}>
                    <GeoIllustration variant={i} className="mx-auto w-full max-w-sm drop-shadow-[0_20px_30px_rgba(23,43,103,0.12)]" />
                  </Reveal>
                </div>
              </li>
            );
          })}
        </ol>
      </div>
    </section>
  );
}
