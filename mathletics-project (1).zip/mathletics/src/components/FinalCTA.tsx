import { motion, useReducedMotion } from "framer-motion";
import { MMark } from "./Logo";
import { useAnchorNav } from "../lib/nav";
import { useEnquiry } from "../lib/enquiryContext";

export function FinalCTA() {
  const go = useAnchorNav();
  const { requestEnquiry } = useEnquiry();
  const reduce = useReducedMotion();

  return (
    <section className="px-3 pb-16 sm:px-6 sm:pb-24" aria-labelledby="final-cta-title">
      <div className="relative mx-auto max-w-7xl overflow-hidden rounded-[2.2rem] bg-gradient-to-br from-cobalt via-[#3a52d6] to-royal px-6 py-20 text-center text-ivory sm:rounded-[3rem] sm:px-12 sm:py-28">
        <div className="dot-grid-light absolute inset-0 opacity-60" aria-hidden="true" />

        {/* animated geometry */}
        <motion.div
          aria-hidden="true"
          className="absolute -left-16 -top-16 size-64 rounded-full bg-tangerine"
          animate={reduce ? {} : { scale: [1, 1.08, 1], rotate: [0, 10, 0] }}
          transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          aria-hidden="true"
          className="absolute -bottom-12 -right-10 size-56 rotate-12 rounded-[2.5rem] bg-mint"
          animate={reduce ? {} : { rotate: [12, 32, 12] }}
          transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          aria-hidden="true"
          className="absolute right-[12%] top-10 hidden h-0 w-0 border-x-[3rem] border-b-[5.2rem] border-x-transparent border-b-lavender/80 sm:block"
          animate={reduce ? {} : { y: [0, -14, 0] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        />

        <div className="relative z-10 mx-auto max-w-3xl">
          <MMark size={64} tone="light" className="mx-auto mb-8" />
          <h2 id="final-cta-title" className="text-4xl font-bold leading-[1.05] sm:text-6xl">
            Your Potential Deserves the{" "}
            <span className="font-serif font-normal italic text-tangerine">Right Direction.</span>
          </h2>
          <p className="mx-auto mt-6 max-w-xl text-lg text-ivory/85 sm:text-xl">
            Take the first step towards learning with confidence.
          </p>
          <div className="mt-10 flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:items-center">
            <a
              href="/#admission"
              className="btn btn-tangerine"
              onClick={(e) => {
                e.preventDefault();
                requestEnquiry();
                go("admission");
              }}
            >
              Apply for Admission
            </a>
            <a
              href="/#contact"
              className="btn btn-ghost text-ivory"
              onClick={(e) => {
                e.preventDefault();
                go("contact");
              }}
            >
              Contact MATHLETICS
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
