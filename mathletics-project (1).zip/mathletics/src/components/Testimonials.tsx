import { AnimatePresence, motion, type PanInfo } from "framer-motion";
import { useState } from "react";
import { TESTIMONIALS } from "../content/siteContent";
import { Reveal } from "./ui/Reveal";
import { ChevronIcon } from "./ui/Icons";

export function Testimonials() {
  const [[index, dir], setPage] = useState<[number, number]>([0, 0]);
  const count = TESTIMONIALS.length;
  if (count === 0) return null;

  const paginate = (d: number) => setPage(([i]) => [(i + d + count) % count, d]);
  const goTo = (n: number) => setPage(([i]) => [n, n > i ? 1 : -1]);
  const t = TESTIMONIALS[index];

  const onDragEnd = (_: unknown, info: PanInfo) => {
    if (info.offset.x < -60) paginate(1);
    else if (info.offset.x > 60) paginate(-1);
  };

  return (
    <section id="testimonials" className="relative overflow-hidden bg-lavender/60 py-20 sm:py-28">
      <div className="wrap">
        <Reveal>
          <p className="eyebrow mb-4 text-cobalt">Parent &amp; Student Voices</p>
          <h2 className="max-w-3xl text-4xl font-bold leading-[1.05] text-royal sm:text-6xl">
            In their <span className="font-serif font-normal italic text-tangerine">own words.</span>
          </h2>
        </Reveal>

        <div className="mx-auto mt-12 max-w-3xl" role="region" aria-roledescription="carousel" aria-label="Testimonials">
          <div className="relative min-h-[22rem] sm:min-h-[19rem]">
            <AnimatePresence initial={false} custom={dir} mode="wait">
              <motion.figure
                key={t.id}
                custom={dir}
                variants={{
                  enter: (d: number) => ({ opacity: 0, x: d >= 0 ? 80 : -80 }),
                  center: { opacity: 1, x: 0 },
                  exit: (d: number) => ({ opacity: 0, x: d >= 0 ? -80 : 80 }),
                }}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.35, ease: "easeOut" }}
                drag="x"
                dragConstraints={{ left: 0, right: 0 }}
                dragElastic={0.25}
                onDragEnd={onDragEnd}
                style={{ touchAction: "pan-y" }}
                className="relative cursor-grab rounded-[2rem] bg-ivory p-8 shadow-[0_30px_60px_-34px_rgba(23,43,103,0.6)] ring-1 ring-royal/10 active:cursor-grabbing sm:p-12"
                aria-roledescription="slide"
                aria-label={`${index + 1} of ${count}`}
              >
                <span className="absolute -top-6 left-8 font-serif text-[7rem] leading-none text-tangerine" aria-hidden="true">“</span>
                {t.placeholder && (
                  <span className="mb-4 inline-block rounded-full bg-tangerine/20 px-3 py-1 text-[0.65rem] font-bold uppercase tracking-widest text-royal">
                    Placeholder — not a real testimonial
                  </span>
                )}
                <blockquote className="font-serif text-2xl leading-snug text-royal sm:text-3xl">{t.quote}</blockquote>
                <figcaption className="mt-6 flex items-center gap-3">
                  <span className="grid size-11 place-items-center rounded-full bg-cobalt font-display font-bold text-ivory" aria-hidden="true">
                    {t.author.charAt(0)}
                  </span>
                  <span>
                    <span className="block font-display font-bold text-royal">{t.author}</span>
                    <span className="text-sm text-midnight/60">{t.role}</span>
                  </span>
                </figcaption>
              </motion.figure>
            </AnimatePresence>
          </div>

          <div className="mt-8 flex items-center justify-between">
            <div className="flex gap-2" role="tablist" aria-label="Choose testimonial">
              {TESTIMONIALS.map((x, i) => (
                <button
                  key={x.id}
                  type="button"
                  role="tab"
                  aria-selected={i === index}
                  aria-label={`Show testimonial ${i + 1}`}
                  onClick={() => goTo(i)}
                  className="grid size-6 place-items-center"
                >
                  <span className={`block h-2.5 rounded-full transition-all ${i === index ? "w-8 bg-tangerine" : "w-2.5 bg-royal/30"}`} />
                </button>
              ))}
            </div>
            <div className="flex gap-3">
              <button type="button" onClick={() => paginate(-1)} aria-label="Previous testimonial" className="grid size-12 place-items-center rounded-full bg-royal text-ivory transition hover:bg-cobalt">
                <ChevronIcon dir="left" />
              </button>
              <button type="button" onClick={() => paginate(1)} aria-label="Next testimonial" className="grid size-12 place-items-center rounded-full bg-royal text-ivory transition hover:bg-cobalt">
                <ChevronIcon dir="right" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
