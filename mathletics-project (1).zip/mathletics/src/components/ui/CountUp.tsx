import { animate, useInView, useReducedMotion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { isCrawler } from "../../lib/crawler";

interface CountUpProps {
  to: number;
  pad?: number;
  duration?: number;
  className?: string;
}

/** Counts from 0 to `to` when scrolled into view, zero-padded (e.g. 01). */
export function CountUp({ to, pad = 2, duration = 1.1, className }: CountUpProps) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  const reduce = useReducedMotion() || isCrawler();
  const [value, setValue] = useState(reduce ? to : 0);

  useEffect(() => {
    if (!inView || reduce) {
      if (reduce) setValue(to);
      return;
    }
    const controls = animate(0, to, {
      duration,
      ease: "easeOut",
      onUpdate: (v) => setValue(Math.round(v)),
    });
    return () => controls.stop();
  }, [inView, reduce, to, duration]);

  return (
    <span ref={ref} className={className} aria-label={String(to).padStart(pad, "0")}>
      {String(value).padStart(pad, "0")}
    </span>
  );
}
