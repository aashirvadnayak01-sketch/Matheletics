// Custom geometric icons for the MATHLETICS brand (all built from circles, triangles and lines).

interface IconProps {
  size?: number;
  className?: string;
}

export function ClarityIcon({ size = 56, className }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 56 56" fill="none" className={className} aria-hidden="true">
      <circle cx="28" cy="28" r="22" stroke="currentColor" strokeWidth="3" />
      <polygon points="28,13 42,38 14,38" fill="currentColor" opacity="0.18" />
      <polygon points="28,13 42,38 14,38" stroke="currentColor" strokeWidth="3" strokeLinejoin="round" />
      <circle cx="28" cy="29" r="4" fill="#FF8057" />
    </svg>
  );
}

export function AttentionIcon({ size = 56, className }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 56 56" fill="none" className={className} aria-hidden="true">
      <circle cx="28" cy="28" r="23" stroke="currentColor" strokeWidth="3" />
      <circle cx="28" cy="28" r="14" stroke="currentColor" strokeWidth="3" />
      <circle cx="28" cy="28" r="5" fill="currentColor" />
      <path d="M28 2v10M28 44v10M2 28h10M44 28h10" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export function ProgressIcon({ size = 56, className }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 56 56" fill="none" className={className} aria-hidden="true">
      <rect x="6" y="36" width="10" height="14" rx="2" fill="currentColor" opacity="0.3" />
      <rect x="23" y="25" width="10" height="25" rx="2" fill="currentColor" opacity="0.55" />
      <rect x="40" y="12" width="10" height="38" rx="2" fill="currentColor" />
      <path d="M8 24 24 14l10 6 14-14" stroke="#FF8057" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function ArrowRight({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M5 12h14m-6-6 6 6-6 6" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function ChevronIcon({ size = 20, dir = "down" }: { size?: number; dir?: "down" | "left" | "right" }) {
  const rot = dir === "down" ? 0 : dir === "left" ? 90 : -90;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{ transform: `rotate(${rot}deg)` }} aria-hidden="true">
      <path d="m6 9 6 6 6-6" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function CheckIcon({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="m5 12.5 4.5 4.5L19 7.5" stroke="currentColor" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function MenuIcon({ open }: { open: boolean }) {
  return (
    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      {open ? (
        <path d="M6 6l12 12M18 6 6 18" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
      ) : (
        <path d="M4 7h16M4 12h16M4 17h10" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
      )}
    </svg>
  );
}

/** Small varied geometric compositions used as section illustrations. */
export function GeoIllustration({ variant, className }: { variant: number; className?: string }) {
  const v = variant % 6;
  return (
    <svg viewBox="0 0 200 160" className={className} fill="none" aria-hidden="true">
      <rect x="2" y="2" width="196" height="156" rx="22" fill={["#E9E5FF", "#B8E8D1", "#FFE3D9", "#DCE5FF", "#E9E5FF", "#B8E8D1"][v]} />
      {v === 0 && (
        <>
          <circle cx="70" cy="80" r="40" stroke="#315FE8" strokeWidth="3" />
          <polygon points="70,48 102,100 38,100" fill="#FF8057" opacity="0.9" />
          <path d="M120 40h50M120 60h36M120 80h44" stroke="#172B67" strokeWidth="4" strokeLinecap="round" />
        </>
      )}
      {v === 1 && (
        <>
          <circle cx="100" cy="80" r="48" stroke="#172B67" strokeWidth="3" strokeDasharray="6 8" />
          <circle cx="100" cy="80" r="26" fill="#315FE8" />
          <circle cx="100" cy="80" r="9" fill="#FF8057" />
          <circle cx="148" cy="80" r="6" fill="#172B67" />
        </>
      )}
      {v === 2 && (
        <>
          <path d="M30 120 80 50l40 40 50-60" stroke="#315FE8" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
          <circle cx="80" cy="50" r="8" fill="#FF8057" />
          <circle cx="120" cy="90" r="8" fill="#172B67" />
          <circle cx="170" cy="30" r="8" fill="#FF8057" />
        </>
      )}
      {v === 3 && (
        <>
          <rect x="40" y="40" width="60" height="60" rx="10" fill="#315FE8" />
          <circle cx="130" cy="95" r="34" fill="#FF8057" />
          <path d="M40 120h120" stroke="#172B67" strokeWidth="4" strokeLinecap="round" />
        </>
      )}
      {v === 4 && (
        <>
          <path d="M40 120a60 60 0 0 1 120 0" stroke="#315FE8" strokeWidth="5" strokeLinecap="round" />
          <path d="M70 120a30 30 0 0 1 60 0" stroke="#FF8057" strokeWidth="5" strokeLinecap="round" />
          <path d="M30 124h140" stroke="#172B67" strokeWidth="4" strokeLinecap="round" />
          <circle cx="100" cy="124" r="6" fill="#172B67" />
        </>
      )}
      {v === 5 && (
        <>
          <polygon points="100,28 160,124 40,124" stroke="#172B67" strokeWidth="4" strokeLinejoin="round" />
          <polygon points="100,62 130,112 70,112" fill="#315FE8" />
          <circle cx="100" cy="28" r="7" fill="#FF8057" />
        </>
      )}
    </svg>
  );
}
