import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState, type MouseEvent as ReactMouseEvent } from "react";
import { useLocation } from "react-router-dom";
import { LogoLockup } from "./Logo";
import { MenuIcon } from "./ui/Icons";
import { useAnchorNav } from "../lib/nav";

const LINKS = [
  { id: "about", label: "About" },
  { id: "programmes", label: "Programmes" },
  { id: "why", label: "Why Us" },
  { id: "journey", label: "Journey" },
  { id: "results", label: "Results" },
  { id: "faq", label: "FAQ" },
];

export function Navbar() {
  const go = useAnchorNav();
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState<string>("");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Active section indicator (home page only)
  useEffect(() => {
    if (pathname !== "/") {
      setActive("");
      return;
    }
    const ids = [...LINKS.map((l) => l.id), "admission"];
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(e.target.id);
        });
      },
      { rootMargin: "-40% 0px -55% 0px" },
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, [pathname]);

  // Close mobile menu on route change / Escape
  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open]);

  const click = (id: string) => (e: ReactMouseEvent) => {
    e.preventDefault();
    setOpen(false);
    // let the menu close before scrolling so layout is stable
    window.setTimeout(() => go(id), 60);
  };

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled || open ? "bg-ivory/90 shadow-[0_8px_30px_-18px_rgba(23,43,103,0.5)] backdrop-blur-md" : "bg-transparent"
      }`}
    >
      <nav className="wrap flex h-[4.25rem] items-center justify-between" aria-label="Main navigation">
        <a
          href="/"
          onClick={(e) => {
            e.preventDefault();
            if (pathname === "/") window.scrollTo({ top: 0, behavior: "smooth" });
            else go("top");
          }}
          aria-label="MATHLETICS home"
        >
          <LogoLockup />
        </a>

        <ul className="hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => (
            <li key={l.id}>
              <a
                href={`/#${l.id}`}
                onClick={click(l.id)}
                aria-current={active === l.id ? "true" : undefined}
                className={`relative rounded-full px-4 py-2 font-display text-sm font-semibold transition-colors ${
                  active === l.id ? "text-cobalt" : "text-midnight/70 hover:text-cobalt"
                }`}
              >
                {l.label}
                {active === l.id && (
                  <motion.span
                    layoutId="nav-active"
                    className="absolute inset-x-4 -bottom-0.5 h-[3px] rounded-full bg-tangerine"
                  />
                )}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <a href="/#admission" onClick={click("admission")} className="btn btn-tangerine !min-h-11 !px-5 !py-2.5 !text-[0.7rem]">
            Apply
          </a>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-full text-royal lg:hidden"
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((o) => !o)}
          >
            <MenuIcon open={open} />
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            className="fixed inset-x-0 top-[4.25rem] bottom-0 overflow-y-auto bg-ivory lg:hidden"
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
          >
            <ul className="wrap flex flex-col gap-1 py-6">
              {[...LINKS, { id: "admission", label: "Admission" }].map((l, i) => (
                <motion.li
                  key={l.id}
                  initial={{ opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 * i }}
                >
                  <a
                    href={`/#${l.id}`}
                    onClick={click(l.id)}
                    className={`flex min-h-14 items-center justify-between border-b border-royal/10 font-display text-2xl font-bold ${
                      active === l.id ? "text-cobalt" : "text-royal"
                    }`}
                  >
                    {l.label}
                    <span className="text-tangerine">→</span>
                  </a>
                </motion.li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
