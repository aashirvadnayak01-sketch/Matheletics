import { motion } from "framer-motion";
import { isCrawler } from "../lib/crawler";

interface MMarkProps {
  size?: number;
  /** "color" for ivory backgrounds, "light" for dark / cobalt backgrounds. */
  tone?: "color" | "light";
  animated?: boolean;
  className?: string;
}

/**
 * The MATHLETICS signature mark: an "M" constructed from pure geometry —
 * two pillars (rectangles with a rounded corner), an orange chevron (a folded
 * triangle) and a single point below the vertex.
 */
export function MMark({ size = 40, tone = "color", animated = false, className }: MMarkProps) {
  const pillar = tone === "color" ? "#315FE8" : "#FFFDF6";
  const dot = tone === "color" ? "#172B67" : "#FFFDF6";

  if (!animated) {
    return (
      <svg width={size} height={size} viewBox="0 0 64 64" className={className} role="img" aria-label="MATHLETICS M mark">
        <path d="M6 18a8 8 0 0 1 8-8h4v44H6z" fill={pillar} />
        <path d="M46 10h4a8 8 0 0 1 8 8v36H46z" fill={pillar} />
        <polygon points="18,10 32,32 46,10 46,26 32,48 18,26" fill="#FF8057" />
        <circle cx="32" cy="57" r="4" fill={dot} />
      </svg>
    );
  }

  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className={className} role="img" aria-label="MATHLETICS M mark">
      <motion.path
        d="M6 18a8 8 0 0 1 8-8h4v44H6z"
        fill={pillar}
        style={{ transformOrigin: "12px 54px" }}
        initial={isCrawler() ? false : { scaleY: 0 }}
        animate={{ scaleY: 1 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      />
      <motion.path
        d="M46 10h4a8 8 0 0 1 8 8v36H46z"
        fill={pillar}
        style={{ transformOrigin: "52px 54px" }}
        initial={isCrawler() ? false : { scaleY: 0 }}
        animate={{ scaleY: 1 }}
        transition={{ duration: 0.6, delay: 0.12, ease: [0.22, 1, 0.36, 1] }}
      />
      <motion.polygon
        points="18,10 32,32 46,10 46,26 32,48 18,26"
        fill="#FF8057"
        style={{ transformOrigin: "32px 10px" }}
        initial={isCrawler() ? false : { scaleY: 0, opacity: 0 }}
        animate={{ scaleY: 1, opacity: 1 }}
        transition={{ duration: 0.55, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
      />
      <motion.circle
        cx="32"
        cy="57"
        r="4"
        fill={dot}
        initial={isCrawler() ? false : { scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 400, damping: 14, delay: 0.85 }}
        style={{ transformOrigin: "32px 57px" }}
      />
    </svg>
  );
}

interface WordmarkProps {
  tone?: "color" | "light";
  className?: string;
}

/** MATHLETICS wordmark: "MATH" in royal blue, "LETICS" in cobalt, wide tracking. */
export function Wordmark({ tone = "color", className = "" }: WordmarkProps) {
  const a = tone === "color" ? "text-royal" : "text-ivory";
  const b = tone === "color" ? "text-cobalt" : "text-tangerine";
  return (
    <span className={`font-display font-bold tracking-[0.22em] ${className}`}>
      <span className={a}>MATH</span>
      <span className={b}>LETICS</span>
    </span>
  );
}

export function LogoLockup({ tone = "color", size = 36 }: { tone?: "color" | "light"; size?: number }) {
  return (
    <span className="inline-flex items-center gap-3">
      <MMark size={size} tone={tone} />
      <Wordmark tone={tone} className="text-base sm:text-lg" />
    </span>
  );
}
