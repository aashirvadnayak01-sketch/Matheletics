import { FunctionsHttpError } from "@supabase/supabase-js";
import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { ADMISSION_OPTIONS } from "../../content/siteContent";
import { useEnquiry } from "../../lib/enquiryContext";
import { isSupabaseConfigured, supabase } from "../../lib/supabase";
import {
  FIELD_STEP,
  LIMITS,
  normalizeMobile,
  validateAll,
  validateStep,
  type EnquiryForm,
  type FormErrors,
} from "../../lib/validation";
import { ArrowRight, CheckIcon } from "../ui/Icons";
import { Field, inputClass } from "./Field";

const STEPS = ["Student", "Academic", "Contact", "Submit"] as const;

const EMPTY: EnquiryForm = {
  studentName: "",
  parentName: "",
  currentClass: "",
  subjects: [],
  learningMode: "",
  message: "",
  mobile: "",
  email: "",
  consent: false,
  website: "",
};

type Status = "idle" | "submitting" | "success" | "error";

export function AdmissionForm() {
  const { prefill } = useEnquiry();
  const [step, setStep] = useState(0);
  const [dir, setDir] = useState(1);
  const [values, setValues] = useState<EnquiryForm>(EMPTY);
  const [errors, setErrors] = useState<FormErrors>({});
  const [status, setStatus] = useState<Status>("idle");
  const [serverError, setServerError] = useState("");
  const [enquiryCode, setEnquiryCode] = useState("");
  const [programme, setProgramme] = useState("");

  // Duplicate-submission protection: a lock + a per-form idempotency key the server also honours.
  const lock = useRef(false);
  const idempotencyKey = useRef<string>(crypto.randomUUID());
  const startedAt = useRef<number>(Date.now());
  const formRef = useRef<HTMLFormElement>(null);

  // "Enquire Now" on a programme card pre-fills the message context.
  useEffect(() => {
    if (prefill?.programme) setProgramme(prefill.programme);
  }, [prefill]);

  const set = <K extends keyof EnquiryForm>(key: K, value: EnquiryForm[K]) => {
    setValues((v) => ({ ...v, [key]: value }));
    if (errors[key]) setErrors((e) => ({ ...e, [key]: undefined }));
  };

  const focusFirstError = () => {
    window.requestAnimationFrame(() => {
      formRef.current?.querySelector<HTMLElement>('[aria-invalid="true"]')?.focus();
    });
  };

  const next = () => {
    const e = validateStep(step, values);
    setErrors(e);
    if (Object.keys(e).length) {
      focusFirstError();
      return;
    }
    setDir(1);
    setStep((s) => Math.min(s + 1, STEPS.length - 1));
  };

  const back = () => {
    setDir(-1);
    setStep((s) => Math.max(s - 1, 0));
  };

  const toggleSubject = (s: string) =>
    set("subjects", values.subjects.includes(s) ? values.subjects.filter((x) => x !== s) : [...values.subjects, s]);

  async function submit() {
    if (lock.current || status === "submitting") return; // duplicate-click protection
    const all = validateAll(values);
    if (Object.keys(all).length) {
      setErrors(all);
      const firstStep = Math.min(...Object.keys(all).map((k) => FIELD_STEP[k as keyof EnquiryForm]));
      setDir(firstStep < step ? -1 : 1);
      setStep(firstStep);
      focusFirstError();
      return;
    }

    lock.current = true;
    setStatus("submitting");
    setServerError("");

    try {
      if (!supabase) throw new Error("NOT_CONFIGURED");

      const message = [programme ? `[Programme: ${programme}]` : "", values.message.trim()].filter(Boolean).join("\n");

      const { data, error } = await supabase.functions.invoke("submit-enquiry", {
        body: {
          studentName: values.studentName.trim(),
          parentName: values.parentName.trim(),
          currentClass: values.currentClass,
          subjects: values.subjects,
          learningMode: values.learningMode,
          message,
          mobile: normalizeMobile(values.mobile),
          email: values.email.trim(),
          consent: values.consent,
          website: values.website,
          idempotencyKey: idempotencyKey.current,
          elapsedMs: Date.now() - startedAt.current,
        },
      });

      if (error) {
        if (error instanceof FunctionsHttpError) {
          let body: { error?: string; fieldErrors?: FormErrors } = {};
          try {
            body = await error.context.json();
          } catch {
            /* non-JSON error body */
          }
          if (body.fieldErrors && Object.keys(body.fieldErrors).length) {
            setErrors(body.fieldErrors);
            const firstStep = Math.min(...Object.keys(body.fieldErrors).map((k) => FIELD_STEP[k as keyof EnquiryForm] ?? 0));
            setDir(-1);
            setStep(firstStep);
          }
          throw new Error(body.error || "We could not submit your enquiry. Please check the details and try again.");
        }
        throw new Error("We could not reach the admissions service. Please check your connection and try again.");
      }

      if (!data?.ok || !data?.enquiryCode) throw new Error("Unexpected response from the server. Please try again.");

      setEnquiryCode(data.enquiryCode as string);
      setStatus("success");
      // keep the lock engaged: this form instance must not submit again
    } catch (err) {
      lock.current = false;
      setStatus("error");
      setServerError(
        err instanceof Error && err.message === "NOT_CONFIGURED"
          ? "Online admissions are not switched on yet (the server connection has not been configured). Your details were NOT sent. Please contact the institution directly."
          : err instanceof Error
            ? err.message
            : "Something went wrong. Please try again.",
      );
    }
  }

  const reset = () => {
    setValues(EMPTY);
    setErrors({});
    setStep(0);
    setStatus("idle");
    setEnquiryCode("");
    setProgramme("");
    lock.current = false;
    idempotencyKey.current = crypto.randomUUID();
    startedAt.current = Date.now();
  };

  const submitting = status === "submitting";

  return (
    <section id="admission" className="relative overflow-hidden bg-gradient-to-b from-ivory via-lavender/50 to-ivory py-20 sm:py-28">
      <div className="dot-grid pointer-events-none absolute inset-0 opacity-40" aria-hidden="true" />
      <div className="wrap relative grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
        <div className="lg:sticky lg:top-28 lg:self-start">
          <p className="eyebrow mb-4 text-tangerine">Admission Enquiry</p>
          <h2 className="text-4xl font-bold leading-[1.05] text-royal sm:text-6xl">
            Your Next Chapter <span className="font-serif font-normal italic text-cobalt">Starts Here.</span>
          </h2>
          <p className="mt-6 text-lg leading-relaxed text-midnight/75">
            Take the first step towards a stronger academic future. Submit your details and our coaching team will review
            your enquiry.
          </p>
          <ul className="mt-8 space-y-3 text-midnight/75">
            {["Four short steps, around two minutes", "Reviewed personally by the coaching team", "No admission is confirmed automatically"].map((t) => (
              <li key={t} className="flex items-start gap-3">
                <span className="mt-1 grid size-5 shrink-0 place-items-center rounded-full bg-mint text-royal"><CheckIcon size={12} /></span>
                {t}
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-[2rem] bg-ivory p-5 shadow-[0_40px_80px_-40px_rgba(23,43,103,0.55)] ring-1 ring-royal/10 sm:p-9">
          <AnimatePresence mode="wait">
            {status === "success" ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                className="py-6 text-center"
                role="status"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 260, damping: 14, delay: 0.1 }}
                  className="mx-auto mb-6 grid size-20 place-items-center rounded-full bg-mint text-royal"
                >
                  <CheckIcon size={38} />
                </motion.div>
                <h3 className="text-3xl font-bold text-royal sm:text-4xl">Enquiry received.</h3>
                <p className="mx-auto mt-4 max-w-md text-lg text-midnight/75">
                  Thank you. Our coaching team will review your request. This is an admission <em>enquiry</em> — it is not a
                  confirmation of admission.
                </p>
                <div className="mx-auto mt-7 max-w-sm rounded-2xl bg-lavender p-5">
                  <p className="eyebrow !text-[0.65rem] text-cobalt">Your enquiry ID</p>
                  <p className="mt-1 select-all font-display text-2xl font-bold tracking-wider text-royal">{enquiryCode}</p>
                  <p className="mt-1 text-xs text-midnight/60">Please keep this ID for reference.</p>
                </div>
                <button type="button" onClick={reset} className="btn btn-ghost mt-8 text-royal">
                  Submit another enquiry
                </button>
              </motion.div>
            ) : (
              <motion.form
                key="form"
                ref={formRef}
                noValidate
                aria-label="Admission enquiry form"
                onSubmit={(e) => {
                  e.preventDefault();
                  if (step < STEPS.length - 1) next();
                  else void submit();
                }}
              >
                {/* progress */}
                <ol className="mb-8 flex items-center" aria-label="Form progress">
                  {STEPS.map((label, i) => (
                    <li key={label} className="flex flex-1 items-center last:flex-none" aria-current={i === step ? "step" : undefined}>
                      <span className="flex flex-col items-center gap-1.5">
                        <span
                          className={`grid size-9 place-items-center rounded-full font-display text-sm font-bold transition-colors sm:size-10 ${
                            i < step ? "bg-mint text-royal" : i === step ? "bg-cobalt text-ivory" : "bg-lavender text-royal/50"
                          }`}
                        >
                          {i < step ? <CheckIcon size={16} /> : i + 1}
                        </span>
                        <span className={`text-[0.65rem] font-bold uppercase tracking-wider sm:text-xs ${i === step ? "text-cobalt" : "text-midnight/45"}`}>
                          {label}
                        </span>
                      </span>
                      {i < STEPS.length - 1 && (
                        <span className="relative mx-2 mb-5 h-[3px] flex-1 overflow-hidden rounded-full bg-lavender">
                          <motion.span
                            className="absolute inset-y-0 left-0 bg-tangerine"
                            animate={{ width: i < step ? "100%" : "0%" }}
                            transition={{ duration: 0.4 }}
                          />
                        </span>
                      )}
                    </li>
                  ))}
                </ol>

                {programme && (
                  <p className="mb-5 flex items-center justify-between gap-3 rounded-2xl bg-lavender px-4 py-3 text-sm font-semibold text-royal">
                    <span>Enquiring about: {programme}</span>
                    <button type="button" className="text-cobalt underline" onClick={() => setProgramme("")}>Clear</button>
                  </p>
                )}

                {/* honeypot — hidden from people and assistive tech */}
                <div aria-hidden="true" style={{ position: "absolute", left: "-9999px", height: 0, overflow: "hidden" }}>
                  <label>
                    Website
                    <input type="text" tabIndex={-1} autoComplete="off" value={values.website} onChange={(e) => set("website", e.target.value)} />
                  </label>
                </div>

                <AnimatePresence mode="wait" custom={dir}>
                  <motion.div
                    key={step}
                    custom={dir}
                    initial={{ opacity: 0, x: dir * 40 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: dir * -40 }}
                    transition={{ duration: 0.25 }}
                    className="space-y-5"
                  >
                    {step === 0 && (
                      <>
                        <h3 className="text-2xl font-bold text-royal">Student details</h3>
                        <Field id="studentName" label="Student full name" required error={errors.studentName}>
                          <input id="studentName" className={inputClass(errors.studentName)} type="text" autoComplete="off" maxLength={LIMITS.name} placeholder="e.g. Aarav Sharma" value={values.studentName} onChange={(e) => set("studentName", e.target.value)} aria-invalid={!!errors.studentName} aria-describedby={errors.studentName ? "studentName-error" : undefined} aria-required="true" />
                        </Field>
                        <Field id="parentName" label="Parent / guardian name" required error={errors.parentName}>
                          <input id="parentName" className={inputClass(errors.parentName)} type="text" autoComplete="name" maxLength={LIMITS.name} placeholder="e.g. Priya Sharma" value={values.parentName} onChange={(e) => set("parentName", e.target.value)} aria-invalid={!!errors.parentName} aria-describedby={errors.parentName ? "parentName-error" : undefined} aria-required="true" />
                        </Field>
                        <Field id="currentClass" label="Current class" required error={errors.currentClass}>
                          <select id="currentClass" className={inputClass(errors.currentClass)} value={values.currentClass} onChange={(e) => set("currentClass", e.target.value)} aria-invalid={!!errors.currentClass} aria-describedby={errors.currentClass ? "currentClass-error" : undefined} aria-required="true">
                            <option value="">Select class…</option>
                            {ADMISSION_OPTIONS.classes.map((c) => <option key={c} value={c}>{c}</option>)}
                          </select>
                        </Field>
                      </>
                    )}

                    {step === 1 && (
                      <>
                        <h3 className="text-2xl font-bold text-royal">Academic details</h3>
                        <fieldset>
                          <legend className="mb-2 flex items-center gap-2 font-display text-sm font-bold text-royal">
                            Subject(s) interested in <span className="text-tangerine" aria-hidden="true">*</span><span className="sr-only">(required)</span>
                          </legend>
                          <div className="flex flex-wrap gap-2" id="subjects" role="group" aria-invalid={!!errors.subjects} tabIndex={-1}>
                            {ADMISSION_OPTIONS.subjects.map((s) => {
                              const on = values.subjects.includes(s);
                              return (
                                <button
                                  key={s}
                                  type="button"
                                  role="checkbox"
                                  aria-checked={on}
                                  onClick={() => toggleSubject(s)}
                                  className={`min-h-12 rounded-full border-2 px-5 font-display text-sm font-bold transition ${
                                    on ? "border-cobalt bg-cobalt text-ivory" : "border-royal/20 bg-ivory text-royal hover:border-cobalt"
                                  }`}
                                >
                                  {on && <span className="mr-1.5 inline-block align-middle"><CheckIcon size={14} /></span>}
                                  {s}
                                </button>
                              );
                            })}
                          </div>
                          {errors.subjects && <p role="alert" className="mt-2 text-sm font-semibold text-[#c2410c]">{errors.subjects}</p>}
                        </fieldset>
                        <Field id="learningMode" label="Preferred learning mode" optionalHint>
                          <select id="learningMode" className={inputClass()} value={values.learningMode} onChange={(e) => set("learningMode", e.target.value)}>
                            <option value="">No preference</option>
                            {ADMISSION_OPTIONS.learningModes.map((m) => <option key={m} value={m}>{m}</option>)}
                          </select>
                        </Field>
                        <Field id="message" label="Message / additional information" optionalHint error={errors.message} hint={`${values.message.length}/${LIMITS.message}`}>
                          <textarea id="message" rows={4} className={`${inputClass(errors.message)} resize-y`} maxLength={LIMITS.message} placeholder="Anything the coaching team should know — goals, concerns, preferred timings…" value={values.message} onChange={(e) => set("message", e.target.value)} aria-invalid={!!errors.message} aria-describedby={errors.message ? "message-error" : "message-hint"} />
                        </Field>
                      </>
                    )}

                    {step === 2 && (
                      <>
                        <h3 className="text-2xl font-bold text-royal">Contact details</h3>
                        <Field id="mobile" label="Mobile number" required error={errors.mobile} hint="10-digit Indian mobile number. +91 is optional.">
                          <input id="mobile" className={inputClass(errors.mobile)} type="tel" inputMode="tel" autoComplete="tel" placeholder="e.g. 98765 43210" value={values.mobile} onChange={(e) => set("mobile", e.target.value)} aria-invalid={!!errors.mobile} aria-describedby={errors.mobile ? "mobile-error" : "mobile-hint"} aria-required="true" />
                        </Field>
                        <Field id="email" label="Email address" required error={errors.email}>
                          <input id="email" className={inputClass(errors.email)} type="email" inputMode="email" autoComplete="email" maxLength={LIMITS.email} placeholder="name@example.com" value={values.email} onChange={(e) => set("email", e.target.value)} aria-invalid={!!errors.email} aria-describedby={errors.email ? "email-error" : undefined} aria-required="true" />
                        </Field>
                      </>
                    )}

                    {step === 3 && (
                      <>
                        <h3 className="text-2xl font-bold text-royal">Review &amp; submit</h3>
                        <dl className="divide-y divide-royal/10 rounded-2xl bg-lavender/50 px-5 text-sm">
                          {([
                            ["Student", values.studentName],
                            ["Parent / guardian", values.parentName],
                            ["Class", values.currentClass],
                            ["Subjects", values.subjects.join(", ")],
                            ["Learning mode", values.learningMode || "No preference"],
                            ["Mobile", normalizeMobile(values.mobile)],
                            ["Email", values.email],
                          ] as const).map(([k, v]) => (
                            <div key={k} className="flex justify-between gap-4 py-3">
                              <dt className="font-semibold text-midnight/55">{k}</dt>
                              <dd className="break-all text-right font-bold text-royal">{v}</dd>
                            </div>
                          ))}
                        </dl>

                        <div>
                          <label htmlFor="consent" className="flex cursor-pointer items-start gap-3 rounded-2xl border-2 border-royal/15 p-4 text-sm leading-relaxed text-midnight/80">
                            <input id="consent" type="checkbox" className="mt-1 size-5 shrink-0 accent-[#315FE8]" checked={values.consent} onChange={(e) => set("consent", e.target.checked)} aria-invalid={!!errors.consent} aria-describedby={errors.consent ? "consent-error" : "privacy-note"} aria-required="true" />
                            <span>
                              I consent to MATHLETICS storing and using these details to review this admission enquiry and to
                              contact me about it. <span className="text-tangerine" aria-hidden="true">*</span>
                            </span>
                          </label>
                          <p id="privacy-note" className="mt-2 text-xs text-midnight/55">
                            We collect only what is needed to handle your enquiry. Read our <Link to="/privacy" className="font-bold text-cobalt underline" target="_blank">Privacy Policy</Link>.
                          </p>
                          {errors.consent && <p id="consent-error" role="alert" className="mt-2 text-sm font-semibold text-[#c2410c]">{errors.consent}</p>}
                        </div>

                        {!isSupabaseConfigured && (
                          <p role="alert" className="rounded-2xl bg-tangerine/20 p-4 text-sm font-semibold text-royal">
                            Setup needed: the admissions backend is not configured, so this form cannot send yet.
                          </p>
                        )}
                        {status === "error" && serverError && (
                          <p role="alert" className="rounded-2xl border-2 border-[#c2410c] bg-[#c2410c]/10 p-4 text-sm font-semibold text-[#9a3412]">
                            {serverError}
                          </p>
                        )}
                      </>
                    )}
                  </motion.div>
                </AnimatePresence>

                <div className="mt-8 flex items-center justify-between gap-3">
                  {step > 0 ? (
                    <button type="button" onClick={back} disabled={submitting} className="btn btn-ghost !px-6 text-royal">Back</button>
                  ) : <span />}

                  {step < STEPS.length - 1 ? (
                    <button type="submit" className="btn btn-cobalt">Continue <ArrowRight size={16} /></button>
                  ) : (
                    <motion.button
                      type="submit"
                      disabled={submitting}
                      className="btn btn-tangerine !px-5 sm:!px-8"
                      whileTap={{ scale: 0.96 }}
                      aria-busy={submitting}
                    >
                      {submitting ? (
                        <>
                          <motion.span
                            className="inline-block size-4 rounded-full border-2 border-midnight border-t-transparent"
                            animate={{ rotate: 360 }}
                            transition={{ repeat: Infinity, duration: 0.8, ease: "linear" }}
                          />
                          Submitting…
                        </>
                      ) : (
                        <>Submit admission request →</>
                      )}
                    </motion.button>
                  )}
                </div>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
