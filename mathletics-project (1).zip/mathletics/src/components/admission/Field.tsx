import { AnimatePresence, motion } from "framer-motion";
import type { ReactNode } from "react";

interface FieldProps {
  id: string;
  label: string;
  required?: boolean;
  optionalHint?: boolean;
  error?: string;
  hint?: string;
  children: ReactNode;
}

/** Label + control + animated error message. The shake replays whenever a new error appears. */
export function Field({ id, label, required, optionalHint, error, hint, children }: FieldProps) {
  return (
    <motion.div
      animate={error ? { x: [0, -7, 7, -4, 4, 0] } : { x: 0 }}
      transition={{ duration: 0.4 }}
    >
      <label htmlFor={id} className="mb-2 flex items-center gap-2 font-display text-sm font-bold text-royal">
        {label}
        {required && (
          <span className="text-tangerine" aria-hidden="true" title="Required">*</span>
        )}
        {required && <span className="sr-only">(required)</span>}
        {optionalHint && <span className="text-xs font-semibold text-midnight/50">(optional)</span>}
      </label>
      {children}
      {hint && !error && (
        <p id={`${id}-hint`} className="mt-1.5 text-xs text-midnight/55">{hint}</p>
      )}
      <AnimatePresence>
        {error && (
          <motion.p
            id={`${id}-error`}
            role="alert"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-1.5 text-sm font-semibold text-[#c2410c]"
          >
            {error}
          </motion.p>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export const inputClass = (error?: string) =>
  `block min-h-[3.25rem] w-full rounded-2xl border-2 bg-ivory px-4 py-3 text-base text-midnight outline-none transition placeholder:text-midnight/35 focus:border-cobalt focus:ring-4 focus:ring-cobalt/15 ${
    error ? "border-[#c2410c]" : "border-royal/15 hover:border-royal/30"
  }`;
