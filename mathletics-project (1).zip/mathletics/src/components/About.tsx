import { motion } from "framer-motion";
import { ABOUT_CARDS } from "../content/siteContent";
import { Reveal } from "./ui/Reveal";
import { AttentionIcon, ClarityIcon, ProgressIcon } from "./ui/Icons";

const ICONS = { clarity: ClarityIcon, attention: AttentionIcon, progress: ProgressIcon };
const TONES = {
  cobalt: "bg-cobalt text-ivory",
  tangerine: "bg-tangerine text-midnight",
  mint: "bg-mint text-royal",
} as const;

export function About() {
  return (
    <section id="about" className="relative py-20 sm:py-28">
      <div className="wrap">
        <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
          <Reveal>
            <p className="eyebrow mb-4 text-tangerine">About MATHLETICS</p>
            <h2 className="text-4xl font-bold leading-[1.05] text-royal sm:text-6xl">
              More Than Coaching.
              <span className="mt-1 block font-serif font-normal italic text-cobalt">A Foundation for Excellence.</span>
            </h2>
          </Reveal>
          <Reveal delay={0.15}>
            <p className="text-lg leading-relaxed text-midnight/75 sm:text-xl">
              MATHLETICS focuses on building real conceptual understanding, developing strong problem-solving skills and
              helping every student improve academically — with steady practice, honest feedback and personal attention
              along the way.
            </p>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {ABOUT_CARDS.map((c, i) => {
            const Icon = ICONS[c.icon];
            return (
              <Reveal key={c.n} delay={i * 0.12} className={i === 1 ? "md:translate-y-8" : ""}>
                <motion.article
                  whileHover={{ y: -8, rotate: i === 1 ? 0.6 : -0.6 }}
                  transition={{ type: "spring", stiffness: 260, damping: 18 }}
                  className={`group relative h-full overflow-hidden rounded-[2rem] p-7 sm:p-8 ${TONES[c.tone]}`}
                >
                  <div className="dot-grid-light absolute inset-0 opacity-40" aria-hidden="true" />
                  <span className="absolute -right-3 -top-6 font-display text-[8rem] font-bold leading-none opacity-[0.12]" aria-hidden="true">
                    {c.n}
                  </span>
                  <div className="relative">
                    <div className="mb-10 transition-transform duration-500 group-hover:rotate-[12deg] group-hover:scale-110">
                      <Icon />
                    </div>
                    <p className="eyebrow mb-2 opacity-80">{c.n}</p>
                    <h3 className="text-2xl font-bold sm:text-3xl">{c.title}</h3>
                    <p className="mt-3 leading-relaxed opacity-90">{c.text}</p>
                  </div>
                </motion.article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
