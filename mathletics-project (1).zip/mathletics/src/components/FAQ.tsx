import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { FAQS } from "../content/siteContent";
import { Reveal } from "./ui/Reveal";
import { isCrawler } from "../lib/crawler";

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-20 sm:py-28">
      <div className="wrap grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
        <Reveal>
          <p className="eyebrow mb-4 text-tangerine">Questions, Answered</p>
          <h2 className="text-4xl font-bold leading-[1.05] text-royal sm:text-6xl">
            Frequently asked <span className="font-serif font-normal italic text-cobalt">questions.</span>
          </h2>
        </Reveal>

        <div className="divide-y divide-royal/15 border-y border-royal/15">
          {FAQS.map((f, i) => {
            const isOpen = open === i || isCrawler();   // crawlers cannot click: show every answer
            return (
              <Reveal key={f.q} delay={i * 0.04} y={14}>
                <h3>
                  <button
                    type="button"
                    className="flex min-h-16 w-full items-center justify-between gap-4 py-5 text-left font-display text-lg font-bold text-royal sm:text-xl"
                    aria-expanded={isOpen}
                    aria-controls={`faq-panel-${i}`}
                    id={`faq-btn-${i}`}
                    onClick={() => setOpen(isOpen ? null : i)}
                  >
                    {f.q}
                    <motion.span
                      animate={{ rotate: isOpen ? 45 : 0, backgroundColor: isOpen ? "#FF8057" : "#E9E5FF" }}
                      className="grid size-9 shrink-0 place-items-center rounded-full text-xl font-bold text-royal"
                      aria-hidden="true"
                    >
                      +
                    </motion.span>
                  </button>
                </h3>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      id={`faq-panel-${i}`}
                      role="region"
                      aria-labelledby={`faq-btn-${i}`}
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: "easeInOut" }}
                      className="overflow-hidden"
                    >
                      <p className="pb-6 pr-12 text-lg leading-relaxed text-midnight/70">{f.a}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
