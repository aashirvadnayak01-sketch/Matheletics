import { RESULTS } from "../content/siteContent";
import { Reveal } from "./ui/Reveal";

// Bento layout: each entry = [wrapper span classes, card colour classes]
const LAYOUT: [string, string][] = [
  ["md:col-span-2 md:row-span-2", "bg-cobalt text-ivory"],
  ["", "bg-tangerine text-midnight"],
  ["", "bg-mint text-royal"],
  ["md:col-span-2", "bg-lavender text-royal"],
];

export function Results() {
  return (
    <section id="results" className="relative py-20 sm:py-28">
      <div className="wrap">
        <Reveal>
          <p className="eyebrow mb-4 text-cobalt">Student Success</p>
          <h2 className="max-w-3xl text-4xl font-bold leading-[1.05] text-royal sm:text-6xl">
            Progress Is the <span className="font-serif font-normal italic text-tangerine">Real Achievement.</span>
          </h2>
          <p className="mt-5 max-w-2xl text-lg text-midnight/70">
            Verified achievements, improvements and results will be shared here. Until then, the cards below are clearly
            marked placeholders.
          </p>
        </Reveal>

        <div className="mt-12 grid auto-rows-[minmax(13rem,auto)] gap-5 md:grid-cols-4">
          {RESULTS.map((r, i) => {
            const [span, colour] = LAYOUT[i % LAYOUT.length];
            return (
              <Reveal key={r.id} delay={i * 0.08} className={span}>
                <article className={`relative flex h-full min-h-[13rem] flex-col justify-between overflow-hidden rounded-[2rem] p-7 ${colour}`}>
                  <div className="dot-grid-light absolute inset-0 opacity-30" aria-hidden="true" />
                  <div className="relative flex items-start justify-between gap-3">
                    <span className="eyebrow !text-[0.68rem] opacity-80">{r.kind}</span>
                    {r.placeholder && (
                      <span className="rounded-full border border-current px-3 py-1 text-[0.62rem] font-bold uppercase tracking-widest opacity-80">
                        Placeholder
                      </span>
                    )}
                  </div>
                  <div className="relative mt-10">
                    <p className="font-display text-5xl font-bold opacity-40" aria-hidden="true">—</p>
                    <h3 className="mt-2 text-2xl font-bold">{r.headline}</h3>
                    <p className="mt-2 text-sm leading-relaxed opacity-85">{r.detail}</p>
                  </div>
                </article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
