import { motion, useReducedMotion } from "framer-motion";
import { MMark } from "./Logo";
import { ArrowRight } from "./ui/Icons";
import { useAnchorNav } from "../lib/nav";
import { useEnquiry } from "../lib/enquiryContext";
import { isCrawler } from "../lib/crawler";

const FORMULAS = [
  { t: "a² + b² = c²", cls: "left-[-2%] top-[10%] bg-ivory text-royal", d: 0 },
  { t: "∫ f(x) dx", cls: "right-[-2%] top-[22%] bg-mint text-royal", d: 0.6 },
  { t: "sin²θ + cos²θ = 1", cls: "left-[2%] bottom-[16%] bg-lavender text-royal", d: 1.2 },
  { t: "π r²", cls: "right-[4%] bottom-[8%] bg-tangerine text-midnight", d: 1.8 },
];

function HeroVisual() {
  const reduce = useReducedMotion() || isCrawler();
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[34rem]" aria-hidden="true">
      {/* backdrop */}
      <div className="dot-grid absolute inset-[6%] rounded-[2.5rem] bg-lavender/70" />
      <div className="absolute inset-[6%] rounded-[2.5rem] ring-1 ring-cobalt/20" />

      {/* unit circle + axes */}
      <svg viewBox="0 0 500 500" className="absolute inset-0 h-full w-full">
        <g stroke="#172B67" strokeOpacity="0.35" strokeWidth="1.5">
          <line x1="40" y1="250" x2="460" y2="250" />
          <line x1="250" y1="40" x2="250" y2="460" />
        </g>
        <g className="spin-slow" style={{ transformOrigin: "250px 250px" }}>
          <circle cx="250" cy="250" r="170" fill="none" stroke="#315FE8" strokeWidth="2.5" strokeDasharray="4 10" strokeLinecap="round" />
          <circle cx="250" cy="80" r="9" fill="#FF8057" />
        </g>
        <g className="spin-slower" style={{ transformOrigin: "250px 250px" }}>
          <circle cx="250" cy="250" r="125" fill="none" stroke="#172B67" strokeOpacity="0.5" strokeWidth="1.5" />
          <circle cx="375" cy="250" r="7" fill="#315FE8" />
        </g>
        <path d="M290 250a40 40 0 0 0-12-28" fill="none" stroke="#FF8057" strokeWidth="3" strokeLinecap="round" />
        <polygon points="70,420 120,340 170,420" fill="#B8E8D1" opacity="0.9" />
        <rect x="372" y="60" width="64" height="64" rx="14" fill="#FF8057" opacity="0.95" transform="rotate(14 404 92)" />
      </svg>

      {/* the signature M */}
      <motion.div
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
        initial={reduce ? false : { scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.9, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
      >
        <MMark size={230} className="drop-shadow-[0_24px_30px_rgba(23,43,103,0.25)]" />
      </motion.div>

      {/* floating formula cards */}
      {FORMULAS.map((f) => (
        <motion.div
          key={f.t}
          className={`absolute rounded-2xl px-4 py-3 font-display text-sm font-bold shadow-[0_18px_40px_-18px_rgba(23,43,103,0.55)] sm:text-base ${f.cls}`}
          initial={reduce ? false : { opacity: 0, scale: 0.7 }}
          animate={reduce ? { opacity: 1 } : { opacity: 1, scale: 1, y: [0, -10, 0] }}
          transition={{
            opacity: { duration: 0.6, delay: 0.8 + f.d / 3 },
            scale: { duration: 0.6, delay: 0.8 + f.d / 3 },
            y: { duration: 5, repeat: Infinity, ease: "easeInOut", delay: f.d },
          }}
        >
          {f.t}
        </motion.div>
      ))}
    </div>
  );
}

export function Hero() {
  const go = useAnchorNav();
  const { requestEnquiry } = useEnquiry();
  const reduce = useReducedMotion() || isCrawler();

  const fade = (delay: number) => ({
    initial: reduce ? false : { opacity: 0, y: 28 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.8, delay, ease: [0.22, 1, 0.36, 1] as const },
  });

  return (
    <section id="top" className="grain relative overflow-hidden pb-20 pt-28 sm:pt-32 lg:pb-28">
      <div className="pointer-events-none absolute -right-40 -top-40 size-[34rem] rounded-full bg-gradient-to-br from-cobalt/25 to-tangerine/25 blur-3xl" aria-hidden="true" />

      <div className="wrap relative grid items-center gap-12 lg:grid-cols-[1.05fr_1fr] lg:gap-8">
        <div>
          <motion.p {...fade(0.1)} className="eyebrow mb-5 text-cobalt">
            Coaching · Concepts · Confidence
          </motion.p>
          <motion.h1
            {...fade(0.2)}
            className="text-[2.75rem] font-bold leading-[0.98] text-royal sm:text-7xl xl:text-[5.5rem]"
          >
            Think Beyond <span className="font-serif font-normal italic text-cobalt">Numbers.</span>
            <br />
            Achieve Beyond <span className="relative inline-block text-tangerine">Limits.
              <svg className="absolute -bottom-2 left-0 w-full" viewBox="0 0 200 12" fill="none" aria-hidden="true">
                <motion.path
                  d="M3 8c40-7 90-7 194-2"
                  stroke="#315FE8"
                  strokeWidth="4"
                  strokeLinecap="round"
                  initial={reduce ? false : { pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 0.9, delay: 1 }}
                />
              </svg>
            </span>
          </motion.h1>
          <motion.p {...fade(0.4)} className="mt-7 max-w-xl text-lg leading-relaxed text-midnight/75 sm:text-xl">
            Building stronger concepts, sharper minds and brighter academic futures.
          </motion.p>

          <motion.div {...fade(0.55)} className="mt-9 flex flex-col gap-3 sm:flex-row">
            <a href="/#about" className="btn btn-cobalt" onClick={(e) => { e.preventDefault(); go("about"); }}>
              Explore MATHLETICS <ArrowRight />
            </a>
            <a
              href="/#admission"
              className="btn btn-tangerine"
              onClick={(e) => {
                e.preventDefault();
                requestEnquiry();
                go("admission");
              }}
            >
              Apply for Admission
            </a>
          </motion.div>

          <motion.ul {...fade(0.7)} className="mt-10 grid max-w-xl grid-cols-1 gap-3 text-sm font-semibold text-royal sm:grid-cols-3">
            {["Concept-based learning", "Personal attention", "Regular assessment"].map((t) => (
              <li key={t} className="flex items-center gap-2">
                <span className="size-2.5 shrink-0 rotate-45 rounded-[3px] bg-tangerine" aria-hidden="true" />
                {t}
              </li>
            ))}
          </motion.ul>
        </div>

        <HeroVisual />
      </div>

      {/* scroll indicator */}
      <button
        type="button"
        onClick={() => go("about")}
        className="absolute bottom-5 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-royal/70 sm:flex"
        aria-label="Scroll to About section"
      >
        <span className="eyebrow !text-[0.65rem]">Scroll</span>
        <span className="relative h-10 w-6 rounded-full border-2 border-royal/40">
          <motion.span
            className="absolute left-1/2 top-2 size-1.5 -translate-x-1/2 rounded-full bg-tangerine"
            animate={reduce ? {} : { y: [0, 16, 0], opacity: [1, 0.3, 1] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          />
        </span>
      </button>
    </section>
  );
}
