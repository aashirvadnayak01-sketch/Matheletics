// Build-time prerender for the single-file site.
//   npm i -D playwright && npx playwright install chromium
//   node tools/prerender.mjs source.html index.html
// Renders source.html as a crawler would (everything visible, no intro), takes the finished page markup and writes it
// into <div id="app"> so the very first HTML response already contains every heading, paragraph, FAQ and contact detail.
// In a normal browser the site's own script still takes over and re-draws the page with all animations, unchanged.
import fs from "node:fs"; import path from "node:path"; import { pathToFileURL } from "node:url";
import { chromium } from "playwright";
const [src = "source.html", out = "index.html"] = process.argv.slice(2);
const UA = "Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 Chrome/130.0.0.0 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)";
const browser = await chromium.launch();
const ctx = await browser.newContext({ userAgent: UA, viewport: { width: 412, height: 900 } });
await ctx.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
const page = await ctx.newPage(); const errors = []; page.on("pageerror", e => errors.push(e.message));
await page.goto(pathToFileURL(path.resolve(src)).href); await page.waitForFunction(() => window.__mReady === true, null, { timeout: 15000 });
let inner = await page.evaluate(() => document.getElementById("app").innerHTML); await browser.close();
if (errors.length) throw new Error("page errors: " + errors.join("; "));
// leave every element in its normal "not yet revealed" state so real visitors see exactly the original animations
inner = inner.replace(/class="([^"]*)"/g, (m, c) => `class="${c.split(/\s+/).filter(t => t && t !== "in").join(" ")}"`).replace(/ class=""/g, "");
let html = fs.readFileSync(src, "utf8");
if (!html.includes('<div id="app"></div>')) throw new Error('expected an empty <div id="app"></div> in the source');
fs.writeFileSync(out, html.replace('<div id="app"></div>', () => `<div id="app">${inner}</div>`));
console.log(`prerendered ${(inner.length / 1024).toFixed(0)} KB of page content into ${out}`);
