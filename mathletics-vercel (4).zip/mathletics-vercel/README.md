# MATHLETICS — Vercel deployment (prerendered single page)

Files to deploy (all at the TOP LEVEL of the project): `index.html`, `robots.txt`, `sitemap.xml`, `vercel.json`.
`index.html` already contains the full page text, so crawlers get headings, courses, location and phones in the first response.

## Rebuild after you edit the site
1. Edit `source.html` (the interactive page).
2. `npm i -D playwright && npx playwright install chromium`
3. `node tools/prerender.mjs source.html index.html`
(`tools/` and `source.html` do not need to be uploaded.)

## Test locally — raw HTML must contain the content
    python3 -m http.server 8080
    curl -s localhost:8080/ | grep -o "<h2" | wc -l          # expect 10 or more (about 30)
    curl -s localhost:8080/ | grep -c "Pradyumna Kishore Rath" # expect 3 or more
    curl -s localhost:8080/ | grep -o "<title>[^<]*"
After deploying use the same commands on https://mathletics-nine.vercel.app/ (or "View page source").

## Search Console checklist
1. Property for https://mathletics-nine.vercel.app/ verified (the tag is already in index.html).
2. Sitemaps → submit `sitemap.xml`.
3. URL Inspection → Test Live URL → View Tested Page: check HTML tab (headings present), Screenshot tab (whole page), More info (no blocked resources).
4. Request Indexing for the home page.
5. Re-check Pages / Indexing report after a few days. Rankings cannot be promised.
