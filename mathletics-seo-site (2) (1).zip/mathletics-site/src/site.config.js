/**
 * ──────────────────────────────────────────────────────────────────────────
 *  MATHLETICS — BUSINESS & SEO CONFIGURATION  (the one file to edit first)
 * ──────────────────────────────────────────────────────────────────────────
 *  Nothing here is invented. Every value is blank until you fill it in, and
 *  the SEO layer only emits what is filled in:
 *
 *   • city            → used in titles, descriptions and headings
 *                       ("Mathletics Coaching | Mathematics Tuition in <city>").
 *                       Blank = the " in <city>" part is simply left out.
 *   • contactVerified → set to true ONLY after you have checked that the
 *                       address / phone / e-mail below are correct and match
 *                       your Google Business Profile. Until then NO address,
 *                       telephone or LocalBusiness data is published in JSON-LD
 *                       or on the page.
 *   • teacher.verified→ same rule for the Person markup and the teacher page.
 *
 *  Deploy-time values can also come from environment variables, so they never
 *  need to be committed:   SITE_URL   SUPABASE_URL   SUPABASE_ANON_KEY
 *  (never put the service-role key or the Resend key anywhere in this project).
 */
export const SITE = {
  name: "MATHLETICS",
  legalName: "",                 // registered name if different from "MATHLETICS" (optional)
  tagline: "Where mathematical intelligence meets academic excellence.",
  shortDescription:
    "A coaching institution focused on conceptual understanding, problem-solving and steady academic progress.",

  /** Canonical site address, no trailing slash, e.g. "https://www.mathletics.in".
   *  Env var SITE_URL overrides. While blank the build is a STAGING build:
   *  every page is noindex and robots.txt blocks crawling, so a test deployment
   *  can never be indexed by accident. */
  url: "https://mathletics-nine.vercel.app",

  lang: "en-IN",
  ogLocale: "en_IN",

  /** The real coaching location. */
  city: "Sambalpur",
  region: "Odisha",
  country: "IN",                 // ISO 3166-1 alpha-2

  /** Fill these in, then set contactVerified: true. */
  contactVerified: true,   // phone numbers supplied by the tutor; address & e-mail still blank → nothing invented
  address: { street: "", locality: "", region: "", postalCode: "" },
  phone: "+91 79910 52911",      // primary number
  phones: ["+91 79910 52911", "+91 70088 95759"],   // every number to publish (first = primary)
  email: "",
  whatsapp: "",                  // digits only incl. country code, e.g. "919876543210"
  hours: "",                     // human-readable, e.g. "Mon–Sat, 4 pm – 8 pm"
  /** Optional machine-readable hours: [{ days:["Monday","Tuesday"], opens:"16:00", closes:"20:00" }] */
  openingHours: [],
  geo: { lat: "", lng: "" },     // optional, only if you know the exact coordinates
  foundingDate: "",              // optional "YYYY" or "YYYY-MM-DD", only if verified

  /** Full URLs of REAL profiles only (they go into sameAs). Blank = not shown. */
  social: { instagram: "", facebook: "", youtube: "" },

  /** Genuine professional profile of the teacher. verified:false hides it everywhere. */
  teacher: { verified: true, name: "Pradyumna Kishore Rath", jobTitle: "Tutor", bio: "Pradyumna Kishore Rath teaches Mathematics (Classes 7 to 12) and Physics (Classes 7 to 10) for both CBSE and ICSE students. He holds a B.Tech in Electrical Engineering.", image: "", sameAs: [] },

  /** Google Search Console, "HTML tag" method: paste ONLY the content value of the tag.
   *  (The DNS / domain-property method needs no code.) */
  searchConsole: { googleSiteVerification: "nS2DNKi0gl2v8eXNNzqpr0RrIc96uQb0zyIef6zkISk" },

  /** Privacy-friendly analytics. "plausible" is cookieless; "none" disables tracking entirely. */
  analytics: { provider: "none", plausibleDomain: "", plausibleSrc: "https://plausible.io/js/script.js" },

  /** Back end for the admission form and /admin. The anon key is public by design. */
  supabase: { url: "", anonKey: "" },

  /** Secure e-mail endpoint (serverless function in /functions, /netlify, /api, or `node serve.mjs`). The form posts here. Set "" to disable. */
  enquiryApi: "/api/enquiry",

  /** SIMPLEST WAY to make the admission form work (no database): get a free access key at https://web3forms.com
   *  (enter the e-mail that should receive enquiries, confirm it, copy the key) and paste it here or set WEB3FORMS_ACCESS_KEY.
   *  Used only when Supabase is not configured. The key is public by design. */
  formEndpoint: { web3formsAccessKey: "" },

  /** Where enquiries are e-mailed when no custom endpoint is deployed (FormSubmit.co, no key; confirm the address once via the activation e-mail). */
  notifyEmail: "pradyumnakishorrath@gmail.com"
};
