/**
 * ──────────────────────────────────────────────────────────────────────────
 *  MATHLETICS — EDITABLE CONTENT
 *  Items with `placeholder: true` show a visible "Sample" tag AND keep their
 *  page out of Google (noindex, not in the sitemap) until you replace them with
 *  verified information and delete the flag. Never publish invented results,
 *  qualifications, testimonials or statistics.
 * ──────────────────────────────────────────────────────────────────────────
 */
export const CONTENT = {
  programmes: [
    { id: "prog-math", slug: "mathematics-class-7-12", name: "Mathematics", classLabel: "Classes 7 to 12", subjects: ["Mathematics"],
      description: "Concept-based mathematics coaching for students in Classes 7 to 12, with regular practice, doubt-clearing and assessment.",
      details: "Mathematics is taught for Classes 7 to 12. Lessons start from the underlying idea, then build skill through varied practice, doubt-clearing support and regular assessment. Both CBSE and ICSE students are taught, in group batches (weekdays or weekends) or one-on-one. A demo class is available. Timings and fees can be confirmed by the coaching team on enquiry." },
    { id: "prog-phy", slug: "physics-class-7-10", name: "Physics", classLabel: "Classes 7 to 10", subjects: ["Physics"],
      description: "Physics coaching for students in Classes 7 to 10, focused on understanding concepts and applying them to problems.",
      details: "Physics is taught for Classes 7 to 10. The emphasis is on understanding the concept first and then applying it to numerical and reasoning questions. Both CBSE and ICSE students are taught, in group batches (weekdays or weekends) or one-on-one. A demo class is available. Timings and fees can be confirmed by the coaching team on enquiry." }
  ],

  /** Board-specific pages are generated ONLY for entries with offered:true (e.g. { slug:"cbse", name:"CBSE", offered:true, description:"…", classes:"Class 9–10" }). */
  boards: [
    { slug: "cbse", name: "CBSE", offered: true, classes: "Mathematics: Classes 7 to 12 · Physics: Classes 7 to 10",
      description: "CBSE Mathematics (Classes 7 to 12) and Physics (Classes 7 to 10) coaching, in group batches or one-on-one." },
    { slug: "icse", name: "ICSE", offered: true, classes: "Mathematics: Classes 7 to 12 · Physics: Classes 7 to 10",
      description: "ICSE Mathematics (Classes 7 to 12) and Physics (Classes 7 to 10) coaching, in group batches or one-on-one." }
  ],

  about: [
    { n: "01", title: "Conceptual Clarity", icon: "clarity", tone: "t-cobalt", text: "Understanding why a method works before practising how to apply it, so ideas stay with students beyond the exam." },
    { n: "02", title: "Personal Attention", icon: "attention", tone: "t-tang", text: "Learning that notices each student's pace, questions and gaps rather than treating a class as one single learner." },
    { n: "03", title: "Consistent Progress", icon: "progress", tone: "t-mint", text: "Small, steady improvements built through regular practice and review, turning effort into lasting confidence." }
  ],
  why: [
    { title: "Structured Learning", text: "A clear, step-by-step path through each topic so students always know where they are and what comes next." },
    { title: "Individual Guidance", text: "Attention to each student's strengths and gaps, with guidance shaped around how they learn." },
    { title: "Concept-Based Teaching", text: "Teaching that starts from ideas and reasoning, so formulas make sense instead of being memorised." },
    { title: "Doubt-Clearing Support", text: "Space to ask questions and get them answered, so small confusions never grow into big gaps." },
    { title: "Regular Academic Assessment", text: "Frequent check-ins that show what is working and what needs more practice." },
    { title: "Student-Focused Environment", text: "A setting built around students' growth, where asking questions and making mistakes is part of learning." }
  ],
  journey: [
    { n: 1, title: "Understand", text: "Build the idea from the ground up until the concept feels clear and natural." },
    { n: 2, title: "Practise", text: "Apply the concept across varied problems so understanding becomes skill." },
    { n: 3, title: "Improve", text: "Review mistakes, fix gaps and sharpen accuracy with focused feedback." },
    { n: 4, title: "Master", text: "Handle unfamiliar problems with confidence, speed and clear reasoning." }
  ],
  results: [
    { id: "r1", kind: "Achievement", headline: "Student achievement", detail: "Add a verified student achievement here, with the student's / parent's permission.", placeholder: true },
    { id: "r2", kind: "Improvement", headline: "Academic improvement", detail: "Add a verified example of academic improvement here.", placeholder: true },
    { id: "r3", kind: "Result", headline: "Examination result", detail: "Add verified examination results here once available.", placeholder: true },
    { id: "r4", kind: "Milestone", headline: "Institution milestone", detail: "Add a verified milestone for the institution here.", placeholder: true }
  ],
  testimonials: [
    { id: "t1", quote: "Placeholder testimonial. A real parent's words will appear here once they have been collected and approved.", author: "Parent name", role: "Parent · placeholder", placeholder: true },
    { id: "t2", quote: "Placeholder testimonial. A real student's words will appear here once they have been collected and approved.", author: "Student name", role: "Student · placeholder", placeholder: true },
    { id: "t3", quote: "Placeholder testimonial. Replace this with a genuine, consented testimonial before publishing.", author: "Parent name", role: "Parent · placeholder", placeholder: true }
  ],
  faqs: [
    { q: "Which classes are available?", a: "Mathematics is taught for Classes 7 to 12 and Physics for Classes 7 to 10. If you are unsure which programme suits your child, submit an enquiry and mention it in the message." },
    { q: "Which subjects and boards are taught?", a: "MATHLETICS teaches Mathematics and Physics only, for both CBSE and ICSE students. No other subjects are offered." },
    { q: "What are the batch options?", a: "Group tuition batches are available on weekdays and on weekends. One-on-one private tuition is also available. Contact the coaching team or submit an enquiry to find the option that suits your child." },
    { q: "Does MATHLETICS offer maths tuition and classes in Sambalpur?", a: "Yes. MATHLETICS is a mathematics coaching centre in Sambalpur, Odisha. It offers maths classes for Classes 7 to 12 (CBSE and ICSE) in group batches and as one-on-one tuition." },
    { q: "Who is the mathematics teacher at MATHLETICS?", a: "Mathematics is taught by Pradyumna Kishore Rath, who also teaches Physics for Classes 7 to 10. He holds a B.Tech in Electrical Engineering." },
    { q: "Can my child attend a demo class?", a: "Yes, a demo class is available. Mention it in your admission enquiry or call the coaching team to arrange it." },
    { q: "Where is Mathletics Sambalpur located?", a: "MATHLETICS is in Sambalpur, Odisha. Group classes are held in a spacious hall fitted with benches and air conditioning, so students can study comfortably." },
    { q: "How can I enquire about admission?", a: "Use the admission form on this page. It takes a few minutes and is split into short steps: student details, academic details and contact details. You can also call the coaching team on the numbers shown in the footer." },
    { q: "How does the admission process work?", a: "You submit the admission form, the coaching team reviews every enquiry, and the coaching head makes the final decision. Submitting the form is a request for admission — it does not guarantee a place." },
    { q: "Can parents contact the coaching team?", a: "Yes. The phone numbers are shown in the footer and on the admission page. You can also submit an enquiry and the team will review it using the contact details you provide." }
  ],
  admission: {
    classes: ["Class 7", "Class 8", "Class 9", "Class 10", "Class 11", "Class 12"],
    subjects: ["Mathematics", "Physics"],
    learningModes: ["Group batch — weekdays", "Group batch — weekends", "One-on-one (private)", "Demo class first", "Not sure yet"]
  },

  /**
   * Learning Hub articles. Write ORIGINAL, helpful articles (not copied, not AI-padded).
   * An article appears on the site only when published:true. `body` is a list of blocks:
   *   "plain paragraph"  ·  { h2: "Heading" }  ·  { h3: "Sub-heading" }  ·  { ul: ["item", "item"] }
   * author: leave blank to credit the institution; set a real name only for a real author.
   */
  articles: [
    {
      slug: "example-article-template",
      title: "Example: how to write a Learning Hub article",
      description: "Draft template that shows the article structure. Delete or replace it.",
      published: false,                       // ← flip to true when the article is real and reviewed
      datePublished: "",                      // "YYYY-MM-DD"
      dateModified: "",
      author: "",
      body: [
        "This draft only exists so you can preview the article layout (npm run build -- --drafts). It is never published while published is false.",
        { h2: "Start with a question families really ask" },
        "Write in plain language, explain one idea well, and use worked examples that you have checked.",
        { h2: "Keep it honest" },
        { ul: ["No invented statistics or results.", "No copied text.", "Credit real authors only."] }
      ]
    }
  ],

  /** Legal text (draft — have it reviewed). */
  legal: {
    privacy: [
      "This policy explains what information is collected when you submit an admission enquiry on this website, and how it is used.",
      { h2: "What we collect" },
      { ul: ["Student full name, parent/guardian name, current class and subjects of interest.", "Mobile number and email address.", "Preferred learning mode and any message you choose to write (optional).", "The date and time of submission. For abuse prevention we also store a one-way hash of your network address — never the address itself."] },
      { h2: "Why we collect it" },
      "Only to review your admission enquiry, to contact you about it, and to prevent spam and misuse of the form. We do not sell your information.",
      { h2: "Analytics" },
      "If analytics is switched on, we use a cookieless, privacy-friendly service that records page views and a few anonymous events (such as a form being submitted). Names, phone numbers and e-mail addresses are never sent to analytics.",
      { h2: "Who can see it" },
      "Authorised members of the MATHLETICS coaching team can view enquiries through a protected administration area. Email notifications are sent through a transactional email provider and enquiry data is stored with our database provider.",
      { h2: "Your choices" },
      "You may ask the coaching team to correct or delete the details you submitted. Contact details are published on this website once available."
    ],
    terms: [
      "By using this website you agree to the following.",
      { h2: "Admission enquiries" },
      "Submitting the admission form is a request for consideration only. It does not guarantee a place. The coaching head reviews every enquiry and makes the final decision.",
      { h2: "Accuracy of information" },
      "Please provide accurate details so that the coaching team can reach you.",
      { h2: "Acceptable use" },
      "Do not submit false, abusive or automated enquiries. Submissions that appear to be spam may be discarded.",
      { h2: "Website content" },
      "Programme details, results and testimonials are published by the institution and may change without notice."
    ]
  }
};
