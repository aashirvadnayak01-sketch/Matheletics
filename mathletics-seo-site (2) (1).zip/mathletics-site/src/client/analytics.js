// Privacy-conscious analytics. Cookieless (Plausible-style); disabled unless configured.
// NEVER pass names, phone numbers, e-mail addresses, enquiry IDs or free text to track().
import { RUNTIME } from "./runtime.js";

const A = RUNTIME.analytics || {};
const dnt = () => navigator.doNotTrack === "1" || window.doNotTrack === "1";
let enabled = false;

export function initAnalytics() {
  if (A.provider !== "plausible" || !A.plausibleDomain || dnt()) return;
  enabled = true;
  window.plausible = window.plausible || function () { (window.plausible.q = window.plausible.q || []).push(arguments); };
  const s = document.createElement("script");
  s.defer = true; s.dataset.domain = A.plausibleDomain; s.src = A.plausibleSrc || "https://plausible.io/js/script.js";
  document.head.appendChild(s);
}
export function track(name, props) {
  if (!enabled || typeof window.plausible !== "function") return;
  try { props ? window.plausible(name, { props }) : window.plausible(name); } catch {}
}

/** One delegated listener covers every tracked control; no per-element code. */
export function bindClickTracking() {
  document.addEventListener("click", e => {
    const a = e.target.closest("a,button"); if (!a) return;
    const href = a.getAttribute("href") || "";
    if (href.startsWith("tel:")) return track("phone_click");
    if (/^https:\/\/(wa\.me|api\.whatsapp\.com)\//.test(href)) return track("whatsapp_click");
    if (href.startsWith("mailto:")) return track("email_click");
    const t = a.dataset.track;
    if (t === "programme_enquiry") return track("programme_enquiry", a.dataset.enq ? { programme: a.dataset.enq } : undefined);
    if (t) track(t);
  }, { passive: true });
}
