// Progressive enhancement for the prerendered pages. All content is already in the HTML;
// this adds menu, reveal animations, carousel, FAQ, intro, lazy form/admin and click tracking.
import { $, $$, mMark, reduceMotion, store, slideHTML, dotsHTML } from "./ui.js";
import { initAnalytics, bindClickTracking, track } from "./analytics.js";

const RM = reduceMotion();
const isBot = /bot|crawl|spider|slurp|lighthouse|pagespeed|headless/i.test(navigator.userAgent);

/* legacy hash URLs from the single-file edition */
(function () {
  const m = { "#/privacy": "/privacy/", "#/terms": "/terms/", "#/admin": "/admin/" }[location.hash];
  if (m) location.replace(m);
})();

/* ── lazy modules ── */
let formMod;
const loadForm = () => formMod || (formMod = import("./form.js").then(m => (m.mountForm(), m)));

function scrollToId(id) {
  const el = document.getElementById(id); if (!el) return false;
  el.scrollIntoView({ behavior: RM ? "auto" : "smooth", block: "start" }); return true;
}

/* ── menu ── */
function bindMenu() {
  const burger = $("#burger"), menu = $("#mmenu"); if (!burger || !menu) return;
  const ICO_OPEN = `<svg width="26" height="26" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h10" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>`;
  const ICO_X = `<svg width="26" height="26" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>`;
  const setMenu = open => {
    menu.classList.toggle("open", open); burger.setAttribute("aria-expanded", open);
    burger.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    document.body.style.overflow = open ? "hidden" : ""; burger.innerHTML = open ? ICO_X : ICO_OPEN; onScroll();
  };
  burger.onclick = () => setMenu(!menu.classList.contains("open"));
  document.addEventListener("keydown", e => { if (e.key === "Escape" && menu.classList.contains("open")) setMenu(false); });
  $$("a", menu).forEach(a => a.addEventListener("click", () => setMenu(false)));
  return setMenu;
}

/* same-page anchors scroll smoothly (works for "#id" and "/#id" while on the home page) */
function bindAnchors(setMenu) {
  document.addEventListener("click", e => {
    const a = e.target.closest("a[href]"); if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || a.target) return;
    const u = new URL(a.href, location.href);
    if (u.origin !== location.origin || u.pathname !== location.pathname || !u.hash || u.hash.length < 2) return;
    const id = decodeURIComponent(u.hash.slice(1)); if (!document.getElementById(id)) return;
    e.preventDefault(); const wasOpen = $("#mmenu")?.classList.contains("open"); setMenu && setMenu(false);
    history.pushState(null, "", u.hash); setTimeout(() => scrollToId(id), wasOpen ? 60 : 0);
    if (id === "admission") loadForm();
  });
  if (location.hash.length > 1) setTimeout(() => { scrollToId(decodeURIComponent(location.hash.slice(1))); }, 100);
}

/* ── reveal / counters / scroll-spy ── */
function setupObservers() {
  const rv = $$(".rv");
  /* Crawlers (Googlebot renders once, tall, and never scrolls) and very tall viewports: everything is shown at once, nothing waits for a scroll trigger. */
  if (isBot || document.documentElement.classList.contains("bot") || window.innerHeight > 2400) { rv.forEach(el => el.classList.add("in")); $$(".node").forEach(n => n.classList.add("in")); return; }
  if (!RM) $$("[data-count]").forEach(el => { el.textContent = "00"; });   // humans see the count-up; crawlers and no-JS keep the real number
  if (!("IntersectionObserver" in window)) { rv.forEach(el => el.classList.add("in")); $$(".node").forEach(n => n.classList.add("in")); return; }
  const revealObs = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add("in"); revealObs.unobserve(e.target); } }), { rootMargin: "0px 0px -80px 0px" });
  rv.forEach(el => revealObs.observe(el));

  const countObs = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return; countObs.unobserve(e.target);
    e.target.closest(".node")?.classList.add("in");
    const to = +e.target.dataset.count, el = e.target;
    if (RM) { el.textContent = String(to).padStart(2, "0"); return; }
    const t0 = performance.now();
    (function tick(t) { const p = Math.min(1, (t - t0) / 1100); el.textContent = String(Math.round(to * (1 - Math.pow(1 - p, 2)))).padStart(2, "0"); if (p < 1) requestAnimationFrame(tick); })(t0);
  }), { rootMargin: "0px 0px -60px 0px" });
  $$("[data-count]").forEach(el => countObs.observe(el));

  const spy = $$("[data-spy]");
  if (spy.length) {
    const navObs = new IntersectionObserver(es => es.forEach(e => {
      if (!e.isIntersecting) return;
      spy.forEach(a => { const on = a.dataset.spy === e.target.id; a.classList.toggle("on", on); on ? a.setAttribute("aria-current", "true") : a.removeAttribute("aria-current"); });
    }), { rootMargin: "-40% 0px -55% 0px" });
    new Set(spy.map(a => a.dataset.spy)).forEach(id => { const el = document.getElementById(id); el && navObs.observe(el); });
  }
}
let ticking = false;
function onScroll() {
  const nav = $("#nav"); if (nav) nav.classList.toggle("solid", scrollY > 24 || !!$("#mmenu")?.classList.contains("open"));
  const list = $("#jlist"), fill = $("#railfill");
  if (list && fill) { const r = list.getBoundingClientRect(); const p = Math.max(0, Math.min(1, (innerHeight * 0.65 - r.top) / r.height)); fill.style.height = (RM ? 100 : p * 100) + "%"; }
}
addEventListener("scroll", () => { if (ticking) return; ticking = true; requestAnimationFrame(() => { ticking = false; onScroll(); }); }, { passive: true });

/* ── programme cards, FAQ, carousel ── */
function bindInteractions() {
  $$("[data-more]").forEach(b => b.onclick = () => { const p = $("#details-" + b.dataset.more), open = !p.classList.contains("open"); p.classList.toggle("open", open); b.setAttribute("aria-expanded", open); b.textContent = open ? "Show Less" : "Learn More"; });
  $$("[data-enq]").forEach(b => b.addEventListener("click", async e => {
    if (!$("#formbox")) return;                       // other pages: normal link to /admission/?programme=…
    e.preventDefault(); const f = await loadForm(); f.setProgramme(b.dataset.enq); scrollToId("admission");
  }));
  $$("[data-enquire]").forEach(a => a.addEventListener("click", () => loadForm()));
  $$(".acc button.q").forEach(b => b.onclick = () => {
    const open = b.getAttribute("aria-expanded") !== "true";
    $$(".acc button.q").forEach(o => { o.setAttribute("aria-expanded", "false"); $("#" + o.getAttribute("aria-controls")).classList.remove("open"); });
    if (open) { b.setAttribute("aria-expanded", "true"); $("#" + b.getAttribute("aria-controls")).classList.add("open"); }
  });
  const tdata = $("#tdata");
  if (tdata) {
    const L = JSON.parse(tdata.textContent), T = { i: 0, dir: 1 };
    const paint = () => {
      const box = $("#slidebox"); box.innerHTML = slideHTML(L, T.i, T.dir); $("#dots").innerHTML = dotsHTML(L, T.i);
      const fig = $(".slide", box); let sx = null;
      fig.addEventListener("pointerdown", e => { sx = e.clientX; });
      fig.addEventListener("pointerup", e => { if (sx === null) return; const d = e.clientX - sx; sx = null; if (d < -60) go(1); else if (d > 60) go(-1); });
      fig.addEventListener("pointercancel", () => { sx = null; });
    };
    const go = d => { T.dir = d; T.i = (T.i + d + L.length) % L.length; paint(); };
    $$("[data-car]").forEach(b => b.onclick = () => go(+b.dataset.car));
    $("#dots").addEventListener("click", e => { const b = e.target.closest("[data-dot]"); if (!b) return; const n = +b.dataset.dot; T.dir = n > T.i ? 1 : -1; T.i = n; paint(); });
  }
}

/* ── intro: home only, once per session, skipped for bots/reduced motion ── */
function maybeIntro() {
  if (!document.body.hasAttribute("data-home") || isBot || RM || store.get("mathletics-intro-seen", true) === "1") return;
  const syms = ["π", "∑", "√", "∞", "÷", "×", "Δ", "θ", "=", "+", "%", "∫"];
  const d = document.createElement("div");
  d.id = "intro"; d.setAttribute("role", "dialog"); d.setAttribute("aria-label", "MATHLETICS introduction");
  d.innerHTML = `<div class="dot-grid-light abs-fill" style="opacity:.6"></div>
    ${syms.map((s, i) => `<span class="sym" aria-hidden="true" style="left:${(i * 37) % 92 + 2}%;top:${(i * 53) % 86 + 4}%;animation-delay:${.1 + i * .07}s,${1.3 + i * .07}s">${s}</span>`).join("")}
    <div class="center">${mMark(88, "light", true)}<div class="word" aria-label="MATHLETICS">${"MATHLETICS".split("").map((l, i) => `<span class="${i >= 4 ? "o" : ""}" aria-hidden="true" style="animation-delay:${.9 + i * .05}s">${l}</span>`).join("")}</div>
    <p class="tag">Where mathematical intelligence meets academic excellence.</p></div><button type="button" class="skip">Skip intro</button>`;
  document.body.appendChild(d);
  const prev = document.body.style.overflow; document.body.style.overflow = "hidden";
  let closed = false;
  const close = () => {
    if (closed) return; closed = true; store.set("mathletics-intro-seen", "1", true);
    document.body.style.overflow = prev; document.removeEventListener("keydown", onKey); d.classList.add("out"); setTimeout(() => d.remove(), 850);
  };
  const onKey = e => { if (e.key === "Escape" || e.key === "Enter" || e.key === " ") close(); };
  $(".skip", d).onclick = close; document.addEventListener("keydown", onKey); setTimeout(close, 2900);
}

/* ── boot ── */
const setMenu = bindMenu();
bindAnchors(setMenu); setupObservers(); bindInteractions(); onScroll(); window.__mReady = true;
initAnalytics(); bindClickTracking();
if (matchMedia("(hover:hover) and (pointer:fine)").matches && !document.body.hasAttribute("data-admin")) import("./cursor.js");
maybeIntro();

const box = $("#formbox");
if (box) {
  if ("IntersectionObserver" in window) {
    const io = new IntersectionObserver(es => { if (es.some(e => e.isIntersecting)) { io.disconnect(); loadForm(); } }, { rootMargin: "700px 0px" });
    io.observe(box);
  } else loadForm();
  if (location.hash === "#admission" || new URLSearchParams(location.search).has("programme")) loadForm();
}
if (document.body.hasAttribute("data-admin")) import("./admin.js").then(m => m.mountAdmin());
