// Multi-step admission form (Student → Academic → Contact → Submit). Lazy-loaded.
import { $, $$, esc, uuid, arrow, check } from "./ui.js";
import { RUNTIME } from "./runtime.js";
import { track } from "./analytics.js";

const SB_OK = !!(RUNTIME.supabaseUrl && RUNTIME.supabaseAnonKey);
const FORM_KEY = RUNTIME.formAccessKey || "";
const API = RUNTIME.enquiryApi || "";
const CONFIGURED = !!API || SB_OK || !!FORM_KEY;
const PHONES = RUNTIME.phones || [];
const STEPS = ["Student", "Academic", "Contact", "Submit"];
const LIMITS = { name: 80, message: 1000, email: 254 };
const NAME_RE = /^[\p{L}\p{M}][\p{L}\p{M}\s.'’-]{1,79}$/u;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const MOBILE_RE = /^[6-9]\d{9}$/;
export function normalizeMobile(raw) {
  const d = String(raw).replace(/[\s\-().]/g, "");
  if (/^\+91\d{10}$/.test(d)) return d.slice(3);
  if (/^0091\d{10}$/.test(d)) return d.slice(4);
  if (/^91\d{10}$/.test(d)) return d.slice(2);
  if (/^0\d{10}$/.test(d)) return d.slice(1);
  return d;
}
const FIELD_STEP = { studentName: 0, parentName: 0, currentClass: 0, subjects: 1, learningMode: 1, message: 1, mobile: 2, email: 2, consent: 3, website: 3 };
const emptyForm = () => ({ studentName: "", parentName: "", currentClass: "", subjects: [], learningMode: "", message: "", mobile: "", email: "", consent: false, website: "" });
const F = { step: 0, dir: 1, v: emptyForm(), err: {}, status: "idle", serverError: "", code: "", programme: "", lock: false, key: uuid(), t0: Date.now() };
const O = RUNTIME.admission;

export function validateStep(step, v) {
  const e = {};
  if (step === 0) {
    if (!v.studentName.trim()) e.studentName = "Please enter the student's full name.";
    else if (!NAME_RE.test(v.studentName.trim())) e.studentName = "Use letters only (2–80 characters) for the name.";
    if (!v.parentName.trim()) e.parentName = "Please enter the parent or guardian's name.";
    else if (!NAME_RE.test(v.parentName.trim())) e.parentName = "Use letters only (2–80 characters) for the name.";
    if (!v.currentClass) e.currentClass = "Please select the student's current class.";
  }
  if (step === 1) {
    if (v.subjects.length === 0) e.subjects = "Select at least one subject of interest.";
    if (v.message.length > LIMITS.message) e.message = `Please keep your message under ${LIMITS.message} characters.`;
  }
  if (step === 2) {
    if (!v.mobile.trim()) e.mobile = "Please enter a mobile number.";
    else if (!MOBILE_RE.test(normalizeMobile(v.mobile))) e.mobile = "Enter a valid 10-digit Indian mobile number (starts with 6–9).";
    if (!v.email.trim()) e.email = "Please enter an email address.";
    else if (!EMAIL_RE.test(v.email.trim()) || v.email.length > LIMITS.email) e.email = "Enter a valid email address, e.g. name@example.com.";
  }
  if (step === 3 && !v.consent) e.consent = "Please tick the consent box to continue.";
  return e;
}
const validateAll = v => Object.assign({}, validateStep(0, v), validateStep(1, v), validateStep(2, v), validateStep(3, v));

function fld(id, label, { req, opt, hint, err, body }) {
  return `<div class="fld ${err ? "err" : ""}" data-fld="${id}">
    <label for="${id}">${label}${req ? `<span class="req" aria-hidden="true">*</span><span class="sr">(required)</span>` : ""}${opt ? `<span class="opt">(optional)</span>` : ""}</label>
    ${body}${hint && !err ? `<p class="hint" id="${id}-hint">${hint}</p>` : ""}<p class="em" id="${id}-error" role="alert">${esc(err || "")}</p></div>`;
}
const attrs = (id, err) => `id="${id}" ${err ? `aria-invalid="true" aria-describedby="${id}-error"` : ""}`;

function formStepHTML() {
  const v = F.v, e = F.err;
  if (F.step === 0) return `<h3>Student details</h3>
    ${fld("studentName", "Student full name", { req: 1, err: e.studentName, body: `<input ${attrs("studentName", e.studentName)} class="inp" type="text" name="studentName" autocomplete="off" maxlength="${LIMITS.name}" placeholder="e.g. Aarav Sharma" value="${esc(v.studentName)}" aria-required="true">` })}
    ${fld("parentName", "Parent / guardian name", { req: 1, err: e.parentName, body: `<input ${attrs("parentName", e.parentName)} class="inp" type="text" name="parentName" autocomplete="name" maxlength="${LIMITS.name}" placeholder="e.g. Priya Sharma" value="${esc(v.parentName)}" aria-required="true">` })}
    ${fld("currentClass", "Current class", { req: 1, err: e.currentClass, body: `<select ${attrs("currentClass", e.currentClass)} class="inp" name="currentClass" aria-required="true"><option value="">Select class…</option>${O.classes.map(c => `<option ${v.currentClass === c ? "selected" : ""}>${esc(c)}</option>`).join("")}</select>` })}`;
  if (F.step === 1) return `<h3>Academic details</h3>
    <fieldset class="fld ${e.subjects ? "err" : ""}" data-fld="subjects" style="border:0;padding:0;margin:0;min-width:0"><legend class="lg" style="padding:0;display:flex;gap:.5rem;font-family:var(--display);font-size:.875rem;font-weight:700;color:var(--royal);margin-bottom:.5rem">Subject(s) interested in <span class="req" aria-hidden="true">*</span><span class="sr">(required)</span></legend>
      <div class="chips" id="subjects" role="group" ${e.subjects ? `aria-invalid="true" tabindex="-1"` : ""}>${O.subjects.map(s => { const on = v.subjects.includes(s); return `<button type="button" class="chip" role="checkbox" aria-checked="${on}" data-subj="${esc(s)}">${on ? `<span style="display:inline-block;vertical-align:middle;margin-right:.375rem">${check(14)}</span>` : ""}${esc(s)}</button>`; }).join("")}</div>
      <p class="em" id="subjects-error" role="alert">${esc(e.subjects || "")}</p></fieldset>
    ${fld("learningMode", "Preferred learning mode", { opt: 1, body: `<select id="learningMode" class="inp" name="learningMode"><option value="">No preference</option>${O.learningModes.map(m => `<option ${v.learningMode === m ? "selected" : ""}>${esc(m)}</option>`).join("")}</select>` })}
    ${fld("message", "Message / additional information", { opt: 1, err: e.message, hint: `<span id="msgcount">${v.message.length}/${LIMITS.message}</span>`, body: `<textarea ${attrs("message", e.message)} class="inp" name="message" rows="4" maxlength="${LIMITS.message}" placeholder="Anything the coaching team should know — goals, concerns, preferred timings…">${esc(v.message)}</textarea>` })}`;
  if (F.step === 2) return `<h3>Contact details</h3>
    ${fld("mobile", "Mobile number", { req: 1, err: e.mobile, hint: "10-digit Indian mobile number. +91 is optional.", body: `<input ${attrs("mobile", e.mobile)} class="inp" type="tel" name="mobile" inputmode="tel" autocomplete="tel" placeholder="e.g. 98765 43210" value="${esc(v.mobile)}" aria-required="true">` })}
    ${fld("email", "Email address", { req: 1, err: e.email, body: `<input ${attrs("email", e.email)} class="inp" type="email" name="email" inputmode="email" autocomplete="email" maxlength="${LIMITS.email}" placeholder="name@example.com" value="${esc(v.email)}" aria-required="true">` })}`;
  const rows = [["Student", v.studentName], ["Parent / guardian", v.parentName], ["Class", v.currentClass], ["Subjects", v.subjects.join(", ")], ["Learning mode", v.learningMode || "No preference"], ["Mobile", normalizeMobile(v.mobile)], ["Email", v.email]];
  return `<h3>Review &amp; submit</h3>
    <dl class="review">${rows.map(([k, x]) => `<div><dt>${k}</dt><dd>${esc(x)}</dd></div>`).join("")}</dl>
    <div><label class="consent" for="consent"><input id="consent" type="checkbox" ${v.consent ? "checked" : ""} aria-required="true" ${e.consent ? `aria-invalid="true"` : ""}><span>I consent to MATHLETICS storing and using these details to review this admission enquiry and to contact me about it. <span class="req" aria-hidden="true">*</span></span></label>
      <p class="hint" id="privacy-note">We collect only what is needed to handle your enquiry. Read our <a href="/privacy/" target="_blank" rel="noopener" class="c-cobalt" style="font-weight:700;text-decoration:underline">Privacy Policy</a>.</p>
      <p class="em" id="consent-error" role="alert">${esc(e.consent || "")}</p></div>
    ${F.status === "error" && F.serverError ? `<p class="notice bad" role="alert">${esc(F.serverError)} ${F.callHelp ? `<span class="callhelp">${PHONES.map(p => `<a href="tel:${esc(p.replace(/[^\d+]/g, ""))}">Call ${esc(p)}</a>`).join(" · ")}</span>` : ""}</p>` : ""}`;
}

export function renderForm() {
  const box = $("#formbox"); if (!box) return;
  box.removeAttribute("data-prerender");
  if (F.status === "success") {
    box.innerHTML = `<div class="success" role="status"><div class="tick">${check(38)}</div><h3>Enquiry submitted successfully.</h3>
      <p class="m">Your admission enquiry has been submitted successfully. Our team will contact you shortly.</p>
      <div class="id"><p class="eyebrow">Your enquiry ID</p><b>${esc(F.code)}</b><small>Please keep this ID for reference.</small></div>
      <button type="button" class="btn btn-ghost c-royal" id="again" style="margin-top:2rem">Submit another enquiry</button></div>`;
    $("#again").onclick = resetForm; return;
  }
  const sub = F.status === "submitting", last = F.step === STEPS.length - 1;
  box.innerHTML = `<form id="aform" novalidate aria-label="Admission enquiry form">
    <ol class="steps" aria-label="Form progress">${STEPS.map((l, i) => `<li class="${i < F.step ? "done" : i === F.step ? "cur" : ""}" ${i === F.step ? `aria-current="step"` : ""}><span class="st"><span class="c">${i < F.step ? check(16) : i + 1}</span><span class="l">${l}</span></span>${i < STEPS.length - 1 ? `<span class="bar"><i></i></span>` : ""}</li>`).join("")}</ol>
    ${F.programme ? `<p class="pchip"><span>Enquiring about: ${esc(F.programme)}</span><button type="button" id="clrprog">Clear</button></p>` : ""}
    <div class="hp" aria-hidden="true"><label>Website<input type="text" id="website" tabindex="-1" autocomplete="off" value="${esc(F.v.website)}"></label></div>
    <div class="fstep ${F.dir < 0 ? "back" : ""}" id="fstep">${formStepHTML()}</div>
    ${Object.keys(F.err).length && F.status!=="submitting" ? `<p class="fsum" role="alert">Please complete the highlighted ${Object.keys(F.err).length>1?"fields":"field"} to continue.</p>` : ""}
    <div class="fnav">${F.step > 0 ? `<button type="button" class="btn btn-ghost c-royal" id="fback" ${sub ? "disabled" : ""} style="padding-inline:1.5rem">Back</button>` : "<span></span>"}
      ${last ? `<button type="submit" class="btn btn-tang" id="fsubmit" ${sub ? "disabled aria-busy=true" : ""}>${sub ? `<span class="spinner"></span> Submitting…` : `Submit admission request →`}</button>` : `<button type="submit" class="btn btn-cobalt">Continue ${arrow(16)}</button>`}</div></form>`;
  const form = $("#aform");
  form.addEventListener("submit", ev => { ev.preventDefault(); goNext(); });
  if (!box._d) { box._d = 1; box.addEventListener("click", ev => { const b = ev.target.closest && ev.target.closest("#aform .fnav button[type=submit]"); if (b) { ev.preventDefault(); goNext(); } }); }
  $("#fback") && ($("#fback").onclick = () => { F.dir = -1; F.step = Math.max(0, F.step - 1); renderForm(); });
  $("#clrprog") && ($("#clrprog").onclick = () => { F.programme = ""; renderForm(); });
  $("#website").addEventListener("input", e => { F.v.website = e.target.value; });
  $$("[data-subj]", form).forEach(b => b.onclick = () => { const s = b.dataset.subj, a = F.v.subjects; F.v.subjects = a.includes(s) ? a.filter(x => x !== s) : [...a, s]; delete F.err.subjects; renderFormKeep(); });
  const map = { studentName: "input", parentName: "input", currentClass: "change", learningMode: "change", message: "input", mobile: "input", email: "input" };
  Object.entries(map).forEach(([k, evn]) => { const el = $("#" + k, form); if (!el) return; el.addEventListener(evn, () => { F.v[k] = el.value; clearErr(k); if (k === "message") $("#msgcount") && ($("#msgcount").textContent = `${el.value.length}/${LIMITS.message}`); }); });
  const c = $("#consent", form); c && c.addEventListener("change", () => { F.v.consent = c.checked; clearErr("consent"); });
}
function renderFormKeep() { const y = scrollY; F.dir = 1; renderForm(); scrollTo(0, y); }
function clearErr(k) {
  if (!F.err[k]) return; delete F.err[k];
  const wrap = $(`[data-fld="${k}"]`); wrap && wrap.classList.remove("err");
  const em = $(`#${k}-error`); em && (em.textContent = "");
  const el = $("#" + k); el && el.removeAttribute("aria-invalid");
}
function focusFirstError() { requestAnimationFrame(() => { const el = $('#aform [aria-invalid="true"]') || $('#aform [data-subj]'); const w = $('#aform .fld.err'); w && w.scrollIntoView({ block: 'center', behavior: 'smooth' }); el && el.focus({ preventScroll: true }); }); }
function goNext() {
  try { syncFromDOM(); F.step === STEPS.length - 1 ? submitForm() : nextStep(); }
  catch (err) {
    console.error("[admission form]", err);
    const f = $("#aform"); if (!f) return;
    let n = $("#fcrash"); if (!n) { n = document.createElement("p"); n.id = "fcrash"; n.className = "notice bad"; n.setAttribute("role", "alert"); f.querySelector(".fnav").before(n); }
    const ph = typeof PHONES === "function" ? PHONES() : PHONES; n.textContent = "Sorry, something went wrong on this page. Please refresh and try again" + (ph && ph.length ? ", or call " + ph.join(" / ") : "") + ".";
  }
}
function syncFromDOM() { const f = $("#aform"); if (!f) return; ["studentName","parentName","currentClass","learningMode","message","mobile","email"].forEach(k => { const el = $("#" + k, f); if (el) F.v[k] = el.value; }); const c = $("#consent", f); if (c) F.v.consent = c.checked; }
function nextStep() {
  const e = validateStep(F.step, F.v); F.err = e;
  if (Object.keys(e).length) { renderForm(); focusFirstError(); return; }
  F.dir = 1; F.step = Math.min(F.step + 1, STEPS.length - 1); renderForm();
}
function resetForm() { F.v = emptyForm(); F.err = {}; F.step = 0; F.dir = 1; F.status = "idle"; F.code = ""; F.programme = ""; F.lock = false; F.serverError = ""; F.key = uuid(); F.t0 = Date.now(); renderForm(); }


/* Direct e-mail mode (no database): used when no Supabase backend is configured but a Web3Forms access key is set.
   Sends the enquiry to the coaching team's inbox. The key is public by design (it can only send to its owner's verified e-mail). */
async function submitDirect(key) {
  if (F.v.website) { F.code = "MATH-" + Date.now().toString(36).toUpperCase(); F.status = "success"; renderForm(); return; }   // honeypot: bots see "success", nothing is sent
  const code = "MATH-" + new Date().toISOString().slice(2, 10).replace(/-/g, "") + "-" + Math.random().toString(36).slice(2, 6).toUpperCase();
  const v = F.v;
  const lines = [`Reference: ${code}`, `Student: ${v.studentName.trim()}`, `Parent/guardian: ${v.parentName.trim()}`, `Class: ${v.currentClass}`, `Subjects: ${v.subjects.join(", ")}`,
    `Learning mode: ${v.learningMode || "No preference"}`, `Mobile: ${normalizeMobile(v.mobile)}`, `Email: ${v.email.trim()}`, F.programme ? `Enquiring about: ${F.programme}` : "", v.message.trim() ? `Message: ${v.message.trim()}` : "", "Consent given to be contacted: yes"].filter(Boolean);
  const ctrl = new AbortController(); const to = setTimeout(() => ctrl.abort(), 25000); let res, body = {};
  try {
    res = await fetch("https://api.web3forms.com/submit", { method: "POST", signal: ctrl.signal, headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ access_key: key, subject: `NEW ADMISSION ENQUIRY — MATHLETICS (${code})`, from_name: "MATHLETICS website", name: v.studentName.trim(), email: v.email.trim(), phone: normalizeMobile(v.mobile), message: lines.join("\n") }) });
    try { body = await res.json(); } catch {}
  } catch { F.callHelp = true; throw new Error(REACH_ERR()); }
  finally { clearTimeout(to); }
  if (!res.ok || !body.success) { F.callHelp = true; throw new Error("We could not send your enquiry right now. Please try again in a moment, or call us."); }
  F.code = code; F.status = "success"; renderForm();
}

const IN_FRAME = (() => { try { return window.self !== window.top; } catch { return true; } })();
const REACH_ERR = () => IN_FRAME
  ? "This page is running inside a preview window that blocks connections to outside services, so your enquiry was NOT sent. Open the live website (not the preview) to submit, or call us."
  : "We could not reach the enquiry service. Please check your connection and try again, or call us.";
const NOTIFY_EMAIL = RUNTIME.notifyEmail || "pradyumnakishorrath@gmail.com";

/* Default e-mail delivery: FormSubmit.co (a form-to-email service, no API key). The owner confirms the address ONCE by clicking the activation link FormSubmit e-mails on the first submission. */
async function submitFormSubmit() {
  if (F.v.website) { F.code = "MATH-" + Date.now().toString(36).toUpperCase(); F.status = "success"; renderForm(); return; }   // honeypot: bots see "success", nothing is sent
  const code = "MATH-" + new Date().toISOString().slice(2, 10).replace(/-/g, "") + "-" + Math.random().toString(36).slice(2, 6).toUpperCase();
  const v = F.v, to = NOTIFY_EMAIL;
  const ctrl = new AbortController(); const tm = setTimeout(() => ctrl.abort(), 25000); let res, body = {};
  try {
    res = await fetch("https://formsubmit.co/ajax/" + encodeURIComponent(to), { method: "POST", signal: ctrl.signal, headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ _subject: `NEW ADMISSION ENQUIRY — MATHLETICS (${code}) — ${v.studentName.trim()}`, _template: "table", _captcha: "false", _replyto: v.email.trim(),
        "Reference": code, "Student name": v.studentName.trim(), "Parent / guardian name": v.parentName.trim(), "Current class": v.currentClass, "Subjects": v.subjects.join(", "),
        "Learning mode": v.learningMode || "No preference", "Selected programme": F.programme || "Not specified", "Mobile": normalizeMobile(v.mobile), "email": v.email.trim(),
        "Message": v.message.trim() || "-", "Consent to be contacted": "Yes", "Submitted": new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }) + " IST" }) });
    try { body = await res.json(); } catch {}
  } catch { F.callHelp = true; throw new Error(REACH_ERR()); }
  finally { clearTimeout(tm); }
  if (!res.ok || !(body.success === true || body.success === "true")) { F.callHelp = true; throw new Error("We could not send your enquiry right now. Please try again in a moment, or call us."); }
  F.code = code; F.status = "success"; renderForm();
}

async function submitForm() {
  if (F.lock || F.status === "submitting") return;       // duplicate-click protection
  const all = validateAll(F.v);
  if (Object.keys(all).length) {
    F.err = all; const first = Math.min(...Object.keys(all).map(k => FIELD_STEP[k]));
    F.dir = first < F.step ? -1 : 1; F.step = first; renderForm(); focusFirstError(); return;
  }
  F.lock = true; F.status = "submitting"; F.serverError = ""; renderForm();
  try {
    if (!API && !SB_OK && FORM_KEY) { await submitDirect(FORM_KEY); if (F.status === "success") track("admission_form_submit", F.programme ? { programme: F.programme } : undefined); return; }
    if (!CONFIGURED) { await submitFormSubmit(); if (F.status === "success") { track("admission_form_submit", F.programme ? { programme: F.programme } : undefined); } return; }
    const message = [F.programme ? `[Enquiring about: ${F.programme}]` : "", F.v.message.trim()].filter(Boolean).join("\n");
    const ctrl = new AbortController(); const to = setTimeout(() => ctrl.abort(), 25000);
    let res;
    try {
      res = await fetch(API || `${RUNTIME.supabaseUrl}/functions/v1/submit-enquiry`, {
        method: "POST", signal: ctrl.signal,
        headers: API ? { "Content-Type": "application/json" } : { "Content-Type": "application/json", apikey: RUNTIME.supabaseAnonKey, Authorization: `Bearer ${RUNTIME.supabaseAnonKey}` },
        body: JSON.stringify({
          studentName: F.v.studentName.trim(), parentName: F.v.parentName.trim(), currentClass: F.v.currentClass, subjects: F.v.subjects,
          learningMode: F.v.learningMode, message, mobile: normalizeMobile(F.v.mobile), email: F.v.email.trim(), consent: F.v.consent,
          website: F.v.website, idempotencyKey: F.key, elapsedMs: Date.now() - F.t0
        })
      });
    } catch { if (API) { await submitFormSubmit(); if (F.status === "success") { track("admission_form_submit", F.programme ? { programme: F.programme } : undefined); } return; } F.callHelp = true; throw new Error(REACH_ERR()); }
    finally { clearTimeout(to); }
    let body = {}; try { body = await res.json(); } catch {}
    if (API && [404, 405, 501, 503].includes(res.status)) { await submitFormSubmit(); if (F.status === "success") { track("admission_form_submit", F.programme ? { programme: F.programme } : undefined); } return; }   // endpoint not deployed on this host -> use the e-mail service
    if (!res.ok) {
      if (body.fieldErrors && Object.keys(body.fieldErrors).length) {
        F.err = body.fieldErrors; F.dir = -1; F.step = Math.min(...Object.keys(body.fieldErrors).map(k => FIELD_STEP[k] ?? 0));
      }
      if (!body.fieldErrors) F.callHelp = true;
      throw new Error(body.error || "We could not submit your enquiry. Please check the details and try again.");
    }
    if (!body.ok || !body.enquiryCode) throw new Error("Unexpected response from the server. Please try again.");
    F.code = body.enquiryCode; F.status = "success"; renderForm();   // lock stays engaged for this form instance
    // Conversion event: NO personal data (no names, phone, e-mail, enquiry ID or message) is sent.
    track("admission_form_submit", F.programme ? { programme: F.programme } : undefined);
  } catch (err) {
    F.lock = false; F.status = "error"; if (err.message !== "NOT_CONFIGURED" && !F.callHelp) F.callHelp = false;
    F.serverError = err.message || "Something went wrong. Please try again.";
    renderForm(); if (Object.keys(F.err).length) focusFirstError();
  }
}

const MODE_FOR = { "One-on-one (private) tuition": "One-on-one (private)", "Demo class request": "Demo class first" };
function applyEnquiry(name) { F.programme = name || ""; if (MODE_FOR[name] && !F.v.learningMode) F.v.learningMode = MODE_FOR[name]; }
export function setProgramme(name) { applyEnquiry(name); if (F.status !== "success") renderForm(); }
export function mountForm() {
  const p = new URLSearchParams(location.search).get("programme");
  if (p && !F.programme) applyEnquiry(p.slice(0, 120));
  renderForm();
}
