// Protected admin dashboard (lazy-loaded on /admin/ only). Uses the anon key + the admin's own session; RLS enforces access.
import { $, $$, esc, fmtDate, store, lockup } from "./ui.js";
import { RUNTIME } from "./runtime.js";
const CONFIGURED = !!(RUNTIME.supabaseUrl && RUNTIME.supabaseAnonKey);
const SKEY = "mathletics-admin-session";
const A = { session: null, gate: "loading", rows: [], total: 0, counts: null, status: "ALL", search: "", page: 0, loading: false, error: "", sel: null, loginErr: "", busy: false };
const PAGE = 25;

function loadSession() { try { return JSON.parse(store.get(SKEY) || "null"); } catch { return null; } }
function saveSession(s) { A.session = s; s ? store.set(SKEY, JSON.stringify(s)) : store.del(SKEY); }
function toSession(j) { return { access_token: j.access_token, refresh_token: j.refresh_token, expires_at: Date.now() + (j.expires_in || 3600) * 1000, user: j.user }; }

async function refreshSession() {
  if (!A.session?.refresh_token) return false;
  try {
    const r = await fetch(`${RUNTIME.supabaseUrl}/auth/v1/token?grant_type=refresh_token`, { method: "POST", headers: { "Content-Type": "application/json", apikey: RUNTIME.supabaseAnonKey }, body: JSON.stringify({ refresh_token: A.session.refresh_token }) });
    if (!r.ok) return false;
    saveSession(toSession(await r.json())); return true;
  } catch { return false; }
}
async function api(path, { method = "GET", body, headers = {}, raw = false } = {}, retry = true) {
  if (A.session && A.session.expires_at - Date.now() < 30000 && retry) await refreshSession();
  const res = await fetch(`${RUNTIME.supabaseUrl}${path}`, {
    method, body: body ? JSON.stringify(body) : undefined,
    headers: { apikey: RUNTIME.supabaseAnonKey, Authorization: `Bearer ${A.session?.access_token || RUNTIME.supabaseAnonKey}`, ...(body ? { "Content-Type": "application/json" } : {}), ...headers }
  });
  if (res.status === 401 && retry && (await refreshSession())) return api(path, { method, body, headers, raw }, false);
  return res;
}

async function adminInit() {
  if (!CONFIGURED) { A.gate = "signed-out"; return renderAdmin(); }
  A.session = loadSession();
  if (!A.session) { A.gate = "signed-out"; return renderAdmin(); }
  A.gate = "loading"; renderAdmin();
  try {
    const r = await api(`/rest/v1/admins?select=user_id&user_id=eq.${encodeURIComponent(A.session.user.id)}`);
    if (r.status === 401) { saveSession(null); A.gate = "signed-out"; return renderAdmin(); }
    const rows = r.ok ? await r.json() : [];
    A.gate = rows.length ? "admin" : "not-admin";
  } catch { A.gate = "signed-out"; A.loginErr = "Could not reach the server."; }
  renderAdmin();
  if (A.gate === "admin") { loadCounts(); loadRows(); }
}

function gateShell(inner) {
  return `<main class="gate"><div class="box"><div style="margin-bottom:2rem">${lockup()}</div>${inner}<p style="margin-top:2rem;font-size:.875rem"><a href="/" class="c-cobalt" style="font-weight:700;text-decoration:underline">← Back to website</a></p></div></main>`;
}
function renderAdmin() {
  const app = $("#app");
  if (A.gate === "loading") { app.innerHTML = `<div class="gate" role="status" style="color:var(--royal)">Loading…</div>`; return; }
  if (A.gate === "not-admin") {
    app.innerHTML = gateShell(`<h1>Not authorised</h1><p style="margin-top:.75rem;color:rgba(16,26,53,.7)">You are signed in as <b>${esc(A.session?.user?.email)}</b>, but this account has not been set up as an administrator.</p><button class="btn btn-cobalt" id="logout" style="margin-top:1.5rem">Sign out</button>`);
    $("#logout").onclick = adminLogout; return;
  }
  if (A.gate !== "admin") {
    app.innerHTML = gateShell(`<h1>Administrator sign-in</h1><p style="margin-top:.5rem;color:rgba(16,26,53,.65)">For the MATHLETICS coaching head and authorised staff only.</p>
      ${!CONFIGURED ? `<p class="notice" role="alert" style="margin-top:1.25rem">Setup needed: SUPABASE_URL and SUPABASE_ANON_KEY are not configured for this build, so sign-in is unavailable.</p>` : ""}
      <form id="login" novalidate><div class="fld"><label for="ae">Email</label><input id="ae" type="email" class="inp" autocomplete="username" required value="${esc(A.loginEmail || "")}"></div>
      <div class="fld"><label for="ap">Password</label><input id="ap" type="password" class="inp" autocomplete="current-password" required></div>
      <p class="em" role="alert" id="lerr">${esc(A.loginErr)}</p><button class="btn btn-cobalt" id="lbtn" style="width:100%" ${!CONFIGURED ? "disabled" : ""}>Sign in</button></form>`);
    $("#login").onsubmit = adminLogin; return;
  }
  paintDashboard();
}
async function adminLogin(e) {
  e.preventDefault(); if (A.busy || !CONFIGURED) return;
  const email = $("#ae").value.trim(), password = $("#ap").value; A.loginEmail = email;
  if (!email || !password) { A.loginErr = "Please enter your email and password."; $("#lerr").textContent = A.loginErr; return; }
  A.busy = true; $("#lbtn").textContent = "Signing in…"; $("#lbtn").disabled = true;
  try {
    const r = await fetch(`${RUNTIME.supabaseUrl}/auth/v1/token?grant_type=password`, { method: "POST", headers: { "Content-Type": "application/json", apikey: RUNTIME.supabaseAnonKey }, body: JSON.stringify({ email, password }) });
    if (!r.ok) { A.loginErr = "Sign-in failed. Check your email and password."; A.busy = false; return renderAdmin(); }
    saveSession(toSession(await r.json())); A.loginErr = ""; A.busy = false; await adminInit();
  } catch { A.loginErr = "Could not reach the server. Please try again."; A.busy = false; renderAdmin(); }
}
async function adminLogout() {
  try { if (A.session) await fetch(`${RUNTIME.supabaseUrl}/auth/v1/logout`, { method: "POST", headers: { apikey: RUNTIME.supabaseAnonKey, Authorization: `Bearer ${A.session.access_token}` } }); } catch {}
  saveSession(null); Object.assign(A, { gate: "signed-out", rows: [], counts: null, sel: null, total: 0 }); $("#drawer").innerHTML = ""; document.body.style.overflow = ""; renderAdmin();
}

async function countFor(status) {
  const q = `/rest/v1/enquiries?select=id&limit=1${status ? `&status=eq.${status}` : ""}`;
  const r = await api(q, { headers: { Prefer: "count=exact", Range: "0-0" } });
  if (!r.ok && r.status !== 206) return null;
  const m = /\/(\d+)$/.exec(r.headers.get("content-range") || ""); return m ? +m[1] : 0;
}
async function loadCounts() {
  try {
    const [total, PENDING, APPROVED, REJECTED] = await Promise.all([countFor(), countFor("PENDING"), countFor("APPROVED"), countFor("REJECTED")]);
    if (total === null) return;
    A.counts = { total, PENDING, APPROVED, REJECTED }; paintStats();
  } catch {}
}
let searchTimer;
async function loadRows() {
  A.loading = true; A.error = ""; paintList();
  try {
    let q = `/rest/v1/enquiries?select=*&order=created_at.desc`;
    if (A.status !== "ALL") q += `&status=eq.${A.status}`;
    const term = A.search.replace(/[,()%*\\:]/g, " ").trim();
    if (term) q += `&or=${encodeURIComponent(`(student_name.ilike.*${term}*,parent_name.ilike.*${term}*,mobile.ilike.*${term}*,email.ilike.*${term}*,enquiry_code.ilike.*${term}*)`)}`;
    const from = A.page * PAGE;
    const r = await api(q, { headers: { Prefer: "count=exact", Range: `${from}-${from + PAGE - 1}`, "Range-Unit": "items" } });
    if (!r.ok && r.status !== 206) throw new Error(`HTTP ${r.status}`);
    A.rows = await r.json(); const m = /\/(\d+)$/.exec(r.headers.get("content-range") || ""); A.total = m ? +m[1] : A.rows.length;
  } catch (e) { A.error = "Could not load enquiries. " + e.message; }
  A.loading = false; paintList();
}
const badge = s => `<span class="status s-${esc(s)}">${esc(s)}</span>`;

function paintDashboard() {
  $("#app").innerHTML = `<div class="adm-page"><header class="ahead"><div class="wrap"><div style="display:flex;align-items:center;gap:1rem">${lockup("color", 32)}<span class="badge-admin">Admin</span></div>
    <div style="display:flex;align-items:center;gap:.75rem"><span style="display:none;max-width:14rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.875rem;color:rgba(16,26,53,.6)" class="amail">${esc(A.session.user.email)}</span>
    <a href="/" class="c-cobalt" style="font-size:.875rem;font-weight:700;text-decoration:underline">View site</a><button class="btn btn-ghost btn-xs c-royal" id="logout">Log out</button></div></div></header>
    <main class="wrap" style="padding-block:2rem"><h1 style="font-size:clamp(1.875rem,4vw,2.25rem);font-weight:700;color:var(--royal)">Admission enquiries</h1>
    <div class="stats" id="stats"></div>
    <div class="toolbar"><div class="grow"><label for="search" class="sr">Search enquiries</label><input id="search" type="search" class="pillinp" placeholder="Search name, mobile, email or enquiry ID…" value="${esc(A.search)}"></div>
      <div><label for="sfilter" class="sr">Filter by status</label><select id="sfilter" class="pillinp"><option value="ALL">All statuses</option><option value="PENDING">Pending</option><option value="APPROVED">Approved</option><option value="REJECTED">Rejected</option></select></div>
      <button class="btn btn-ghost c-royal" id="refresh" style="min-height:3rem">Refresh</button></div>
    <div id="alist"></div></main></div>`;
  const mq = matchMedia("(min-width:768px)"); $(".amail").style.display = mq.matches ? "inline" : "none";
  $("#sfilter").value = A.status;
  $("#logout").onclick = adminLogout;
  $("#search").oninput = e => { A.search = e.target.value; clearTimeout(searchTimer); searchTimer = setTimeout(() => { A.page = 0; loadRows(); }, 300); };
  $("#sfilter").onchange = e => { A.status = e.target.value; A.page = 0; paintStats(); loadRows(); };
  $("#refresh").onclick = () => { loadCounts(); loadRows(); };
  paintStats(); paintList();
}
function paintStats() {
  const el = $("#stats"); if (!el) return; const c = A.counts;
  const S = [["Total enquiries", c?.total, "background:var(--ivory);color:var(--royal);box-shadow:0 0 0 1px rgba(23,43,103,.1)", "ALL"], ["Pending", c?.PENDING, "background:var(--tangerine);color:var(--midnight)", "PENDING"], ["Approved", c?.APPROVED, "background:var(--mint);color:var(--royal)", "APPROVED"], ["Rejected", c?.REJECTED, "background:var(--royal);color:var(--ivory)", "REJECTED"]];
  el.innerHTML = S.map(([l, v, st, f]) => `<button type="button" class="stat ${A.status === f ? "sel" : ""}" style="${st}" data-f="${f}" aria-pressed="${A.status === f}"><p class="eyebrow">${l}</p><b>${v ?? "–"}</b></button>`).join("");
  $$("[data-f]", el).forEach(b => b.onclick = () => { A.status = b.dataset.f; A.page = 0; $("#sfilter").value = A.status; paintStats(); loadRows(); });
}
function paintList() {
  const el = $("#alist"); if (!el) return;
  const pages = Math.max(1, Math.ceil(A.total / PAGE)), filt = A.status !== "ALL" || A.search.trim();
  const warn = r => r.notify_status === "FAILED" ? `⚠ email failed` : r.notify_status === "NOT_CONFIGURED" ? `⚠ email not set up` : "";
  el.innerHTML = `${A.error ? `<p class="notice bad" role="alert" style="margin-top:1.5rem">${esc(A.error)}</p>` : ""}
  <div class="tbl"><h2>${filt ? "Results" : "Recent applications"} <span>(${A.total})</span></h2>
  ${A.loading ? `<p class="none" role="status">Loading enquiries…</p>` : A.rows.length === 0 ? `<p class="none">${!filt ? "No enquiries yet. New submissions will appear here." : "No enquiries match your filters."}</p>` : `
    <table><thead><tr><th>Enquiry</th><th>Student</th><th>Class</th><th>Submitted</th><th>Email</th><th>Status</th></tr></thead><tbody>
    ${A.rows.map(r => `<tr data-id="${esc(r.id)}"><td><button class="code" data-id="${esc(r.id)}">${esc(r.enquiry_code)}</button></td><td><b>${esc(r.student_name)}</b><br><span style="color:rgba(16,26,53,.55)">${esc(r.parent_name)}</span></td><td>${esc(r.current_class)}</td><td class="nowrap">${fmtDate(r.created_at)}</td>
      <td>${warn(r) ? `<span class="warn" title="${esc(r.notify_error || "")}">${warn(r)}</span>` : r.notify_status === "SENT" ? `<span style="font-size:.75rem;color:rgba(16,26,53,.45)">notified</span>` : ""}</td><td>${badge(r.status)}</td></tr>`).join("")}</tbody></table>
    <ul class="mlist">${A.rows.map(r => `<li><button data-id="${esc(r.id)}"><span><span class="code" style="display:block;font-size:.875rem;color:var(--cobalt)">${esc(r.enquiry_code)}</span><b style="display:block;color:var(--royal)">${esc(r.student_name)}</b><span style="display:block;font-size:.875rem;color:rgba(16,26,53,.55)">${esc(r.current_class)} · ${fmtDate(r.created_at)}</span>${warn(r) ? `<span class="warn" style="display:block;margin-top:.25rem">⚠ email not delivered</span>` : ""}</span>${badge(r.status)}</button></li>`).join("")}</ul>
    ${pages > 1 ? `<div class="pager"><button class="btn btn-ghost btn-xs c-royal" id="prev" ${A.page === 0 ? "disabled" : ""}>Previous</button><span style="font-weight:600;color:rgba(16,26,53,.6)">Page ${A.page + 1} of ${pages}</span><button class="btn btn-ghost btn-xs c-royal" id="next" ${A.page + 1 >= pages ? "disabled" : ""}>Next</button></div>` : ""}`}</div>`;
  $$("[data-id]", el).forEach(n => n.addEventListener("click", ev => { ev.stopPropagation(); const r = A.rows.find(x => x.id === n.dataset.id); r && openDrawer(r); }));
  $("#prev") && ($("#prev").onclick = () => { A.page--; loadRows(); }); $("#next") && ($("#next").onclick = () => { A.page++; loadRows(); });
}

/* drawer */
let D = { notes: "", sendEmail: false, busy: null, msg: null };
function openDrawer(r) { A.sel = r; D = { notes: r.admin_notes || "", sendEmail: false, busy: null, msg: null }; document.body.style.overflow = "hidden"; paintDrawer(); document.addEventListener("keydown", escClose); }
function closeDrawer() { A.sel = null; $("#drawer").innerHTML = ""; document.body.style.overflow = ""; document.removeEventListener("keydown", escClose); }
function escClose(e) { if (e.key === "Escape") closeDrawer(); }
function updateRow(u) { A.sel = u; A.rows = A.rows.map(r => r.id === u.id ? u : r); paintList(); loadCounts(); }
function paintDrawer() {
  const e = A.sel; if (!e) return;
  const notesDirty = D.notes !== (e.admin_notes || "");
  const emailProblem = e.notify_status !== "SENT";
  const notifyTxt = e.notify_status === "SENT" ? `sent ${e.notify_sent_at ? fmtDate(e.notify_sent_at) : ""}` : e.notify_status === "NOT_CONFIGURED" ? "not configured" : e.notify_status === "FAILED" ? "FAILED" : "pending";
  const row = (k, v) => `<div><dt>${k}</dt><dd>${v}</dd></div>`;
  $("#drawer").innerHTML = `<div class="drawer" role="dialog" aria-modal="true" aria-label="Enquiry ${esc(e.enquiry_code)}"><div class="scrim" id="scrim"></div><aside>
    <div class="dh"><div><p style="font-family:var(--display);font-size:1.125rem;font-weight:700;color:var(--royal)">${esc(e.enquiry_code)}</p><p style="font-size:.75rem;color:rgba(16,26,53,.55)">Submitted ${fmtDate(e.created_at)}</p></div>
      <div style="display:flex;align-items:center;gap:.75rem">${badge(e.status)}<button class="x" id="dclose" aria-label="Close">×</button></div></div>
    <div class="db"><dl class="dl">${row("Student", esc(e.student_name))}${row("Parent / guardian", esc(e.parent_name))}${row("Mobile", `<a href="tel:+91${esc(e.mobile)}">+91 ${esc(e.mobile)}</a>`)}${row("Email", `<a href="mailto:${esc(e.email)}">${esc(e.email)}</a>`)}${row("Class", esc(e.current_class))}${row("Subjects", esc((e.subjects || []).join(", ")))}${row("Learning mode", esc(e.learning_mode || "No preference"))}${row("Submitted", fmtDate(e.created_at))}${e.decided_at ? row("Decision date", fmtDate(e.decided_at)) : ""}</dl>
      <div><h3 style="margin-bottom:.5rem;font-size:.875rem;color:var(--royal)">Message from family</h3><p style="white-space:pre-wrap;border-radius:1rem;background:rgba(233,229,255,.4);padding:1rem;font-size:.875rem;line-height:1.6">${esc(e.message || "No message provided.")}</p></div>
      <div class="box2 ${emailProblem ? "bad" : "ok"}"><p style="font-weight:700;color:var(--royal)">Coaching-head notification email: ${esc(notifyTxt)}</p>${e.notify_error ? `<p style="margin-top:.25rem;font-size:.75rem;word-break:break-word;color:var(--danger-d)">${esc(e.notify_error)}</p>` : ""}
        ${e.notify_status !== "SENT" ? `<button class="btn btn-cobalt btn-xs" id="retry" style="margin-top:.75rem" ${D.busy ? "disabled" : ""}>${D.busy === "retry" ? "Sending…" : "Retry notification"}</button>` : ""}
        ${e.decision_email_status !== "NOT_SENT" ? `<p style="margin-top:.75rem;font-size:.75rem;font-weight:600;color:rgba(16,26,53,.7)">Decision email to family: ${e.decision_email_status === "SENT" ? "sent" : e.decision_email_status === "FAILED" ? "failed — " + esc(e.decision_email_error || "") : "not configured"}</p>` : ""}</div>
      <div><label for="notes" style="display:block;margin-bottom:.5rem;font-family:var(--display);font-size:.875rem;font-weight:700;color:var(--royal)">Internal notes <span style="font-weight:400;color:rgba(16,26,53,.5)">(never shown to the family)</span></label>
        <textarea id="notes" rows="4" maxlength="4000" class="inp">${esc(D.notes)}</textarea><button class="btn btn-ghost btn-xs c-royal" id="savenotes" style="margin-top:.75rem" ${D.busy || !notesDirty ? "disabled" : ""}>${D.busy === "notes" ? "Saving…" : "Save notes"}</button></div>
      <div class="decision"><h3 style="font-size:.875rem;color:var(--royal)">Decision</h3><p style="margin-top:.25rem;font-size:.75rem;color:rgba(16,26,53,.6)">Submitting the form never admits anyone. Only you decide.</p>
        <label style="margin-top:1rem;display:flex;cursor:pointer;align-items:flex-start;gap:.75rem;font-size:.875rem"><input type="checkbox" id="sendmail" ${D.sendEmail ? "checked" : ""} style="width:1.25rem;height:1.25rem;accent-color:var(--cobalt)"><span>Also email the parent/student about an approval or rejection</span></label>
        <div class="g3"><button class="btn btn-cobalt" data-set="APPROVED" ${D.busy || e.status === "APPROVED" ? "disabled" : ""}>${D.busy === "APPROVED" ? "…" : "Approve"}</button><button class="btn btn-ghost" style="color:var(--danger-d)" data-set="REJECTED" ${D.busy || e.status === "REJECTED" ? "disabled" : ""}>${D.busy === "REJECTED" ? "…" : "Reject"}</button><button class="btn btn-tang" data-set="PENDING" ${D.busy || e.status === "PENDING" ? "disabled" : ""}>${D.busy === "PENDING" ? "…" : "Mark pending"}</button></div></div>
      ${D.msg ? `<p class="msg ${D.msg.type}" role="${D.msg.type === "err" ? "alert" : "status"}">${esc(D.msg.text)}</p>` : ""}</div></aside></div>`;
  $("#scrim").onclick = closeDrawer; $("#dclose").onclick = closeDrawer;
  $("#notes").oninput = ev => { D.notes = ev.target.value; const b = $("#savenotes"); b && (b.disabled = !!D.busy || D.notes === (e.admin_notes || "")); };
  $("#sendmail").onchange = ev => { D.sendEmail = ev.target.checked; };
  $("#savenotes").onclick = saveNotes; $("#retry") && ($("#retry").onclick = retryNotify);
  $$("[data-set]").forEach(b => b.onclick = () => setStatus(b.dataset.set));
}
async function patchEnquiry(id, patch) {
  const r = await api(`/rest/v1/enquiries?id=eq.${encodeURIComponent(id)}`, { method: "PATCH", body: patch, headers: { Prefer: "return=representation" } });
  if (!r.ok) { let t = ""; try { t = (await r.json()).message || ""; } catch {} throw new Error(t || `HTTP ${r.status}`); }
  const rows = await r.json(); if (!rows.length) throw new Error("No row was updated (are you an administrator?)"); return rows[0];
}
async function refetchOne(id) { const r = await api(`/rest/v1/enquiries?select=*&id=eq.${encodeURIComponent(id)}`); if (!r.ok) return null; const a = await r.json(); return a[0] || null; }
async function adminEmail(action, id) {
  try {
    const r = await api(`/functions/v1/admin-email`, { method: "POST", body: { action, enquiryId: id } });
    if (r.ok) return null; let b = {}; try { b = await r.json(); } catch {}
    return b.error || "Email request failed.";
  } catch { return "Could not reach the email service."; }
}
async function saveNotes() {
  D.busy = "notes"; D.msg = null; paintDrawer();
  try { const u = await patchEnquiry(A.sel.id, { admin_notes: D.notes.trim() || null }); D.msg = { type: "ok", text: "Notes saved." }; D.busy = null; updateRow(u); D.notes = u.admin_notes || ""; }
  catch (e) { D.busy = null; D.msg = { type: "err", text: "Could not save notes. " + e.message }; }
  paintDrawer();
}
async function setStatus(next) {
  const cur = A.sel; if (next === cur.status) return;
  if (next !== "PENDING" && !confirm(`Are you sure you want to ${next === "APPROVED" ? "approve" : "reject"} this enquiry${D.sendEmail ? " and email the family" : ""}?`)) return;
  D.busy = next; D.msg = null; paintDrawer();
  try {
    let u = await patchEnquiry(cur.id, { status: next, admin_notes: D.notes.trim() || null }); updateRow(u);
    if (next !== "PENDING" && D.sendEmail) {
      const err = await adminEmail("decision", cur.id); const fresh = await refetchOne(cur.id); if (fresh) updateRow(fresh);
      D.msg = err ? { type: "err", text: `Status saved as ${next}, but the email to the family was not sent: ${err}` } : { type: "ok", text: `Status set to ${next} and the family was emailed.` };
    } else D.msg = { type: "ok", text: `Status set to ${next}.` };
  } catch (e) { D.msg = { type: "err", text: "Could not update the status. " + e.message }; }
  D.busy = null; paintDrawer();
}
async function retryNotify() {
  D.busy = "retry"; D.msg = null; paintDrawer();
  const err = await adminEmail("retry_notification", A.sel.id); const fresh = await refetchOne(A.sel.id); if (fresh) updateRow(fresh);
  D.busy = null; D.msg = err ? { type: "err", text: err } : { type: "ok", text: "Notification email sent." }; paintDrawer();
}
export function mountAdmin() { document.body.style.overflow = ""; adminInit(); }
