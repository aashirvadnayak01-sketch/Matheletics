// Development stub. `npm run build` OVERWRITES this file inside dist/ with real values
// taken from site.config.js / environment variables (SUPABASE_URL, SUPABASE_ANON_KEY).
// Only browser-safe values belong here — the anon key is public by design.
export const RUNTIME = {
  supabaseUrl: "",
  supabaseAnonKey: "",
  analytics: { provider: "none", plausibleDomain: "", plausibleSrc: "" },
  phone: "",
  whatsapp: ""
};
