// Isomorphic helpers: imported by the Node prerenderer AND shipped to the browser.
// No DOM access at import time (so it is safe to run in Node).

export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
export const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
export const reduceMotion = () => typeof matchMedia !== "undefined" && matchMedia("(prefers-reduced-motion: reduce)").matches;
export const uuid = () => (globalThis.crypto && crypto.randomUUID ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => { const r = Math.random() * 16 | 0; return (c === "x" ? r : (r & 3 | 8)).toString(16); }));
export const fmtDate = iso => new Intl.DateTimeFormat("en-IN", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Kolkata" }).format(new Date(iso));
export const store = {
  get(k, session) { try { return (session ? sessionStorage : localStorage).getItem(k); } catch { return null; } },
  set(k, v, session) { try { (session ? sessionStorage : localStorage).setItem(k, v); } catch {} },
  del(k) { try { localStorage.removeItem(k); } catch {} }
};

export function mMark(size = 40, tone = "color", animated = false) {
  const pillar = tone === "color" ? "#315FE8" : "#FFFDF6";
  const dot = tone === "color" ? "#172B67" : "#FFFDF6";
  return `<svg class="mm${animated ? " anim" : ""}" width="${size}" height="${size}" viewBox="0 0 64 64" role="img" aria-label="MATHLETICS M mark">
    <path class="p1" d="M6 18a8 8 0 0 1 8-8h4v44H6z" fill="${pillar}"/>
    <path class="p2" d="M46 10h4a8 8 0 0 1 8 8v36H46z" fill="${pillar}"/>
    <polygon class="ch" points="18,10 32,32 46,10 46,26 32,48 18,26" fill="#FF8057"/>
    <circle class="dt" cx="32" cy="57" r="4" fill="${dot}"/></svg>`;
}
export const wordmark = () => `<span class="wm"><span class="a">MATH</span><span class="b">LETICS</span></span>`;
export const lockup = (tone = "color", size = 36) => `<span class="lockup ${tone === "light" ? "light" : ""}">${mMark(size, tone)}${wordmark()}</span>`;

export const ICONS = {
  clarity: `<svg width="56" height="56" viewBox="0 0 56 56" fill="none" aria-hidden="true"><circle cx="28" cy="28" r="22" stroke="currentColor" stroke-width="3"/><polygon points="28,13 42,38 14,38" fill="currentColor" opacity=".18"/><polygon points="28,13 42,38 14,38" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><circle cx="28" cy="29" r="4" fill="#FF8057"/></svg>`,
  attention: `<svg width="56" height="56" viewBox="0 0 56 56" fill="none" aria-hidden="true"><circle cx="28" cy="28" r="23" stroke="currentColor" stroke-width="3"/><circle cx="28" cy="28" r="14" stroke="currentColor" stroke-width="3"/><circle cx="28" cy="28" r="5" fill="currentColor"/><path d="M28 2v10M28 44v10M2 28h10M44 28h10" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>`,
  progress: `<svg width="56" height="56" viewBox="0 0 56 56" fill="none" aria-hidden="true"><rect x="6" y="36" width="10" height="14" rx="2" fill="currentColor" opacity=".3"/><rect x="23" y="25" width="10" height="25" rx="2" fill="currentColor" opacity=".55"/><rect x="40" y="12" width="10" height="38" rx="2" fill="currentColor"/><path d="M8 24 24 14l10 6 14-14" stroke="#FF8057" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>`
};
export const arrow = (s = 18) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
export const chev = dir => `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" style="transform:rotate(${dir === "left" ? 90 : -90}deg)" aria-hidden="true"><path d="m6 9 6 6 6-6" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
export const check = (s = 18) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

export function geo(v) {
  v = v % 6;
  const bg = ["#E9E5FF", "#B8E8D1", "#FFE3D9", "#DCE5FF", "#E9E5FF", "#B8E8D1"][v];
  const parts = [
    `<circle cx="70" cy="80" r="40" stroke="#315FE8" stroke-width="3"/><polygon points="70,48 102,100 38,100" fill="#FF8057" opacity=".9"/><path d="M120 40h50M120 60h36M120 80h44" stroke="#172B67" stroke-width="4" stroke-linecap="round"/>`,
    `<circle cx="100" cy="80" r="48" stroke="#172B67" stroke-width="3" stroke-dasharray="6 8"/><circle cx="100" cy="80" r="26" fill="#315FE8"/><circle cx="100" cy="80" r="9" fill="#FF8057"/><circle cx="148" cy="80" r="6" fill="#172B67"/>`,
    `<path d="M30 120 80 50l40 40 50-60" stroke="#315FE8" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="80" cy="50" r="8" fill="#FF8057"/><circle cx="120" cy="90" r="8" fill="#172B67"/><circle cx="170" cy="30" r="8" fill="#FF8057"/>`,
    `<rect x="40" y="40" width="60" height="60" rx="10" fill="#315FE8"/><circle cx="130" cy="95" r="34" fill="#FF8057"/><path d="M40 120h120" stroke="#172B67" stroke-width="4" stroke-linecap="round"/>`,
    `<path d="M40 120a60 60 0 0 1 120 0" stroke="#315FE8" stroke-width="5" stroke-linecap="round"/><path d="M70 120a30 30 0 0 1 60 0" stroke="#FF8057" stroke-width="5" stroke-linecap="round"/><path d="M30 124h140" stroke="#172B67" stroke-width="4" stroke-linecap="round"/><circle cx="100" cy="124" r="6" fill="#172B67"/>`,
    `<polygon points="100,28 160,124 40,124" stroke="#172B67" stroke-width="4" stroke-linejoin="round"/><polygon points="100,62 130,112 70,112" fill="#315FE8"/><circle cx="100" cy="28" r="7" fill="#FF8057"/>`
  ];
  return `<svg viewBox="0 0 200 160" width="200" height="160" fill="none" aria-hidden="true"><rect x="2" y="2" width="196" height="156" rx="22" fill="${bg}"/>${parts[v]}</svg>`;
}

/* testimonial carousel markup — rendered on the server for slide 1, repainted in the browser */
export function slideHTML(L, i, dir = 1) {
  const t = L[i];
  return `<figure class="slide ${dir < 0 ? "rev" : ""}" aria-roledescription="slide" aria-label="${i + 1} of ${L.length}">
    <span class="q" aria-hidden="true">“</span>${t.placeholder ? `<span class="ph">Placeholder — not a real testimonial</span>` : ""}
    <blockquote>${esc(t.quote)}</blockquote>
    <figcaption><span class="av" aria-hidden="true">${esc(t.author.charAt(0))}</span><span><span class="nm">${esc(t.author)}</span><span class="rl">${esc(t.role)}</span></span></figcaption></figure>`;
}
export const dotsHTML = (L, cur) => L.map((x, i) => `<button type="button" role="tab" aria-selected="${i === cur}" aria-label="Show testimonial ${i + 1}" data-dot="${i}"><i></i></button>`).join("");
