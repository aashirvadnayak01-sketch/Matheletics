// Custom cursor: tangerine dot + trailing royal ring; ring grows over links/buttons; native text cursor in fields.
// Fine pointers only (never touch), respects reduced motion (no trailing). Loaded lazily by app.js.
(function () {
  if (!window.matchMedia || !matchMedia("(hover:hover) and (pointer:fine)").matches) return;
  var root = document.documentElement, rm = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var dot, ring, x = -100, y = -100, rx = -100, ry = -100, on = false, raf = 0;
  var LINK = "a[href],button,select,summary,[role=button],[role=tab],[role=checkbox],label[for],.chip,[data-more],[data-enq]";
  var TEXT = "input:not([type=checkbox]):not([type=radio]):not([type=submit]):not([type=button]),textarea,[contenteditable]";
  function init() {
    dot = document.createElement("div"); dot.className = "cur-dot"; ring = document.createElement("div"); ring.className = "cur-ring";
    dot.setAttribute("aria-hidden", "true"); ring.setAttribute("aria-hidden", "true"); document.body.append(ring, dot);
    on = true; root.classList.add("cur-on"); loop();
  }
  function loop() {
    rx += (x - rx) * (rm ? 1 : 0.2); ry += (y - ry) * (rm ? 1 : 0.2);
    dot.style.transform = "translate3d(" + x + "px," + y + "px,0)"; ring.style.transform = "translate3d(" + rx + "px," + ry + "px,0)";
    raf = requestAnimationFrame(loop);
  }
  addEventListener("mousemove", function (e) {
    x = e.clientX; y = e.clientY;
    if (!on) { rx = x; ry = y; init(); }
    root.classList.remove("cur-out");
    var t = e.target && e.target.closest ? e.target : null;
    root.classList.toggle("cur-text", !!(t && t.closest(TEXT)));
    root.classList.toggle("cur-link", !!(t && !t.closest(TEXT) && t.closest(LINK)));
  }, { passive: true });
  addEventListener("mousedown", function () { root.classList.add("cur-down"); });
  addEventListener("mouseup", function () { root.classList.remove("cur-down"); });
  document.addEventListener("mouseleave", function () { root.classList.add("cur-out"); });
  document.addEventListener("mouseenter", function () { root.classList.remove("cur-out"); });
})();
