// Netlify Function → POST /api/enquiry (see netlify.toml redirect). Set environment variables in Site settings.
import { handleEnquiry } from "../../server/enquiry-core.js";
export default async (request) => handleEnquiry(request, process.env);
export const config = { path: "/api/enquiry" };
