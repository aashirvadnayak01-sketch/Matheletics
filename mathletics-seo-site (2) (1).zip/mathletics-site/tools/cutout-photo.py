#!/usr/bin/env python3
"""Background removal ONLY (OpenCV GrabCut). Person pixels are copied unchanged from the original;
only the alpha channel is computed. Usage: python3 tools/cutout-photo.py tools/teacher-original.jpg src/static/assets/teacher.webp"""
import sys, cv2, numpy as np
from PIL import Image
src, out = sys.argv[1], sys.argv[2]
im = cv2.imread(src); h, w = im.shape[:2]
mask = np.full((h, w), cv2.GC_PR_BGD, np.uint8)
mask[60:h, 20:w-10] = cv2.GC_PR_FGD
mask[0:60, :] = cv2.GC_BGD; mask[:, 0:10] = cv2.GC_BGD; mask[:, w-6:] = cv2.GC_BGD
mask[0:250, 0:108] = cv2.GC_BGD; mask[0:240, 250:w] = cv2.GC_BGD
mask[100:145, 135:215] = cv2.GC_FGD; mask[165:240, 140:215] = cv2.GC_FGD; mask[300:450, 90:320] = cv2.GC_FGD
bg = np.zeros((1, 65)); fg = np.zeros((1, 65))
cv2.grabCut(im, mask, None, bg, fg, 10, cv2.GC_INIT_WITH_MASK)
m = ((mask == 1) | (mask == 3)).astype(np.uint8) * 255
m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8)); m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
n, lab, st, _ = cv2.connectedComponentsWithStats(m); k = 1 + np.argmax(st[1:, 4]); m = ((lab == k) * 255).astype(np.uint8)
m = cv2.erode(m, np.ones((3, 3), np.uint8), iterations=1)          # drop the 1px greenish fringe
alpha = cv2.GaussianBlur(m, (0, 0), 1.1)                             # soft edge
rgba = np.dstack([cv2.cvtColor(im, cv2.COLOR_BGR2RGB), alpha])
Image.fromarray(rgba, "RGBA").save(out, "WEBP", quality=92, method=6)
print("wrote", out, rgba.shape)
