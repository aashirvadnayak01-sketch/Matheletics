#!/usr/bin/env node
// Generates favicon / app icons / social-share image from the brand M mark. Needs Playwright (dev-time only).
//   node tools/make-assets.mjs
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
const require = createRequire(import.meta.url);
const { chromium } = require("playwright");
const OUT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../src/static");
fs.mkdirSync(path.join(OUT, "assets"), { recursive: true });

const M = (fill = "#315FE8", dot = "#172B67") => `<path d="M6 18a8 8 0 0 1 8-8h4v44H6z" fill="${fill}"/><path d="M46 10h4a8 8 0 0 1 8 8v36H46z" fill="${fill}"/><polygon points="18,10 32,32 46,10 46,26 32,48 18,26" fill="#FF8057"/><circle cx="32" cy="57" r="4" fill="${dot}"/>`;
const favicon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#FFFDF6"/>${M()}</svg>`;
fs.writeFileSync(path.join(OUT, "favicon.svg"), favicon);

const browser = await chromium.launch();
async function png(html, w, h, file, scale = 1) {
  const pg = await browser.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: scale });
  await pg.setContent(`<style>html,body{margin:0;background:transparent}</style>${html}`);
  const buf = await pg.screenshot({ omitBackground: false, clip: { x: 0, y: 0, width: w, height: h } });
  fs.writeFileSync(file, buf); await pg.close(); return buf;
}
const icon = s => `<svg xmlns="http://www.w3.org/2000/svg" width="${s}" height="${s}" viewBox="0 0 64 64"><rect width="64" height="64" fill="#FFFDF6"/><g transform="translate(8 8) scale(.75)">${M()}</g></svg>`;
await png(icon(512), 512, 512, path.join(OUT, "assets/icon-512.png"));
await png(icon(192), 192, 192, path.join(OUT, "assets/icon-192.png"));
await png(icon(180), 180, 180, path.join(OUT, "assets/apple-touch-icon.png"));
const fav48 = await png(favicon.replace("<svg ", '<svg width="48" height="48" '), 48, 48, path.join(OUT, "assets/favicon-48.png"));
// ICO container holding the 48×48 PNG
const hdr = Buffer.alloc(22); hdr.writeUInt16LE(0, 0); hdr.writeUInt16LE(1, 2); hdr.writeUInt16LE(1, 4);
hdr[6] = 48; hdr[7] = 48; hdr.writeUInt16LE(1, 10); hdr.writeUInt16LE(32, 12); hdr.writeUInt32LE(fav48.length, 14); hdr.writeUInt32LE(22, 18);
fs.writeFileSync(path.join(OUT, "favicon.ico"), Buffer.concat([hdr, fav48]));
fs.rmSync(path.join(OUT, "assets/favicon-48.png"));

// 1200×630 share image: brand mark, name, tagline (no invented claims)
await png(`<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@700&display=swap" rel="stylesheet">
<div style="width:1200px;height:630px;background:#FFFDF6;position:relative;overflow:hidden;font-family:'Space Grotesk',system-ui,sans-serif">
<div style="position:absolute;right:-120px;top:-120px;width:520px;height:520px;border-radius:50%;background:#E9E5FF"></div>
<div style="position:absolute;left:-80px;bottom:-140px;width:380px;height:380px;border-radius:50%;background:#B8E8D1;opacity:.7"></div>
<svg style="position:absolute;right:110px;top:150px" width="330" height="330" viewBox="0 0 64 64">${M()}</svg>
<div style="position:absolute;left:80px;top:190px;color:#172B67;font-size:92px;font-weight:700;letter-spacing:.12em;line-height:1">MATH<span style="color:#315FE8">LETICS</span></div>
<div style="position:absolute;left:80px;top:320px;width:640px;color:#101A35;font-size:36px;line-height:1.3;opacity:.8">Where mathematical intelligence meets academic excellence.</div>
<div style="position:absolute;left:80px;top:470px;width:160px;height:10px;border-radius:9px;background:#FF8057"></div></div>`, 1200, 630, path.join(OUT, "assets/og-image.png"));
await browser.close();

fs.writeFileSync(path.join(OUT, "site.webmanifest"), JSON.stringify({
  name: "Mathletics Coaching", short_name: "MATHLETICS", start_url: "/", display: "browser", background_color: "#FFFDF6", theme_color: "#315FE8",
  icons: [{ src: "/assets/icon-192.png", sizes: "192x192", type: "image/png" }, { src: "/assets/icon-512.png", sizes: "512x512", type: "image/png" }]
}, null, 2));
console.log("assets written to src/static");
