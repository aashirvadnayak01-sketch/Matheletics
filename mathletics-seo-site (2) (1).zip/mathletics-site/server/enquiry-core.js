// MATHLETICS admission-enquiry endpoint — hosting-neutral core (Web-standard Request → Response).
// Adapters: functions/api/enquiry.js (Cloudflare Pages), netlify/functions/enquiry.mjs (Netlify), api/enquiry.js (Vercel), serve.mjs (any Node host).
//
// Secrets live ONLY in environment variables (never in the browser bundle):
//   RESEND_API_KEY      (required)  API key from https://resend.com/api-keys
//   ENQUIRY_TO_EMAIL    (optional)  recipient, default pradyumnakishorrath@gmail.com
//   ENQUIRY_FROM        (optional)  default "MATHLETICS Website <onboarding@resend.dev>"  (works while the Resend account is registered
//                                    with the recipient address; to send from your own domain, verify it in Resend and change this)
//   SITE_URL            (optional)  allowed Origin, e.g. https://www.example.in
//   ALLOWED_ORIGINS     (optional)  extra comma-separated allowed origins
//   RESEND_API_URL      (testing only) override of https://api.resend.com/emails

const TO_DEFAULT = "pradyumnakishorrath@gmail.com";
const MAX_BODY = 8000;
const NAME_RE = /^[\p{L}\p{M}][\p{L}\p{M}\s.'’-]{1,79}$/u;
const EMAIL_RE = /^[^\s@<>",;]+@[^\s@<>",;]+\.[^\s@<>",;]{2,}$/;
const MOBILE_RE = /^[6-9]\d{9}$/;
const CLASSES = ["Class 7", "Class 8", "Class 9", "Class 10", "Class 11", "Class 12"];
const SUBJECTS = ["Mathematics", "Physics"];
const MODES = ["", "Group batch — weekdays", "Group batch — weekends", "One-on-one (private)", "Demo class first", "Not sure yet"];

const hits = new Map();   // best-effort per-instance rate limit (serverless instances are ephemeral; add a platform rate-limit rule for hard limits)
function rateLimited(ip) {
  const now = Date.now(), WIN = 10 * 60_000, MAX = 5, a = (hits.get(ip) || []).filter(t => now - t < WIN);
  a.push(now); hits.set(ip, a);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.some(t => now - t < WIN)) hits.delete(k);
  return a.length > MAX;
}
export const _resetRateLimit = () => hits.clear();

const clean = (s, max) => String(s ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").replace(/\r\n?/g, "\n").trim().slice(0, max);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const baseJson = (obj, status = 200, extra = {}) => new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", ...extra } });

export function normalizeMobile(raw) {
  const d = String(raw).replace(/[\s\-().]/g, "");
  if (/^\+91\d{10}$/.test(d)) return d.slice(3);
  if (/^0091\d{10}$/.test(d)) return d.slice(4);
  if (/^91\d{10}$/.test(d)) return d.slice(2);
  if (/^0\d{10}$/.test(d)) return d.slice(1);
  return d;
}

export function validate(b) {
  const e = {}, v = {};
  v.studentName = clean(b.studentName, 80); v.parentName = clean(b.parentName, 80);
  v.currentClass = clean(b.currentClass, 20); v.learningMode = clean(b.learningMode, 40);
  v.subjects = Array.isArray(b.subjects) ? [...new Set(b.subjects.map(x => clean(x, 30)))] : [];
  v.message = clean(b.message, 1000); v.mobile = normalizeMobile(clean(b.mobile, 20)); v.email = clean(b.email, 254).toLowerCase();
  if (!NAME_RE.test(v.studentName)) e.studentName = "Please enter the student's full name (letters only).";
  if (!NAME_RE.test(v.parentName)) e.parentName = "Please enter the parent or guardian's name (letters only).";
  if (!CLASSES.includes(v.currentClass)) e.currentClass = "Please select the student's current class.";
  if (!v.subjects.length || !v.subjects.every(s => SUBJECTS.includes(s))) e.subjects = "Select at least one valid subject.";
  if (!MODES.includes(v.learningMode)) e.learningMode = "Invalid learning mode.";
  if (!MOBILE_RE.test(v.mobile)) e.mobile = "Enter a valid 10-digit Indian mobile number.";
  if (!EMAIL_RE.test(v.email)) e.email = "Enter a valid email address.";
  if (b.consent !== true) e.consent = "Consent is required.";
  return { v, e };
}

export function makeReference() {
  const d = new Date(Date.now() + 5.5 * 3600_000).toISOString().slice(2, 10).replace(/-/g, "");
  const r = Array.from(crypto.getRandomValues(new Uint8Array(4)), x => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[x % 32]).join("");
  return `MATH-${d}-${r}`;
}

export function buildEmail(v, ref, extra) {
  const rows = [["Reference", ref], ["Student name", v.studentName], ["Parent / guardian", v.parentName], ["Current class", v.currentClass], ["Subject(s)", v.subjects.join(", ")],
    ["Learning mode", v.learningMode || "No preference"], ["Mobile", v.mobile], ["Email", v.email], ["Enquiring about", extra.enquiringAbout || "—"], ["Message", v.message || "—"], ["Submitted (IST)", extra.when]];
  const text = rows.map(([k, x]) => `${k}: ${x}`).join("\n") + "\n\nReply to this e-mail to answer the family directly (Reply-To is set to their address).";
  const html = `<!doctype html><html><body style="margin:0;background:#F3F1FF;font-family:Segoe UI,Arial,sans-serif;color:#101A35">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="padding:24px 12px"><tr><td align="center">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#FFFDF6;border-radius:16px;overflow:hidden;border:1px solid #dcd6ff">
<tr><td style="background:#172B67;padding:22px 28px"><div style="color:#FF8057;font-size:12px;letter-spacing:.18em;font-weight:700">NEW ADMISSION ENQUIRY</div><div style="color:#FFFDF6;font-size:24px;font-weight:700;margin-top:4px">MATH<span style="color:#7fa0ff">LETICS</span></div></td></tr>
<tr><td style="padding:24px 28px 8px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0">
${rows.map(([k, x], i) => `<tr><td style="padding:10px 0;border-bottom:1px solid #ece8ff;width:38%;vertical-align:top;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#5a6488;font-weight:700">${esc(k)}</td><td style="padding:10px 0;border-bottom:1px solid #ece8ff;vertical-align:top;font-size:15px;line-height:1.5;${i === 0 ? "font-weight:700;color:#315FE8" : ""}">${k === "Email" ? `<a href="mailto:${esc(x)}" style="color:#315FE8">${esc(x)}</a>` : k === "Mobile" ? `<a href="tel:+91${esc(x)}" style="color:#315FE8">+91 ${esc(x)}</a>` : esc(x).replace(/\n/g, "<br>")}</td></tr>`).join("")}
</table></td></tr>
<tr><td style="padding:16px 28px 26px"><div style="background:#FFE3D9;border-radius:10px;padding:12px 14px;font-size:13px;color:#172B67">Press <b>Reply</b> to answer the family directly — their e-mail address is set as Reply-To. This is an enquiry, not a confirmed admission.</div></td></tr>
</table></td></tr></table></body></html>`;
  return { text, html };
}

function originAllowed(request, env) {
  const origin = request.headers.get("origin") || "";
  if (!origin) return false;
  const allowed = new Set([env.SITE_URL, ...(env.ALLOWED_ORIGINS || "").split(",")].map(s => (s || "").trim().replace(/\/+$/, "")).filter(Boolean));
  const host = request.headers.get("host") || new URL(request.url).host;
  if (!allowed.size) { try { return new URL(origin).host === host; } catch { return false; } }   // no config → same-origin only
  if (allowed.has(origin.replace(/\/+$/, ""))) return true;
  try { const o = new URL(origin); if (o.host === host) return true; } catch {}
  return false;
}

/** @param {Request} request @param {Record<string,string|undefined>} env */
export async function handleEnquiry(request, env = {}) {
  const origin = request.headers.get("origin") || "";
  if (request.method === "OPTIONS") {   // CORS preflight (only needed when the page is hosted on a different origin than this endpoint)
    return originAllowed(request, env) ? new Response(null, { status: 204, headers: { "Access-Control-Allow-Origin": origin, "Access-Control-Allow-Methods": "POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Max-Age": "86400", Vary: "Origin" } }) : new Response(null, { status: 403 });
  }
  if (request.method !== "POST") return baseJson({ ok: false, error: "Method not allowed." }, 405, { Allow: "POST" });
  if (!originAllowed(request, env)) return baseJson({ ok: false, error: "Request not allowed." }, 403);
  const cors = { "Access-Control-Allow-Origin": origin, Vary: "Origin" };
  const json = (o, st = 200, x = {}) => baseJson(o, st, { ...cors, ...x });
  if (!(request.headers.get("content-type") || "").includes("application/json")) return json({ ok: false, error: "Unsupported request." }, 415);
  const raw = await request.text();
  if (raw.length > MAX_BODY) return json({ ok: false, error: "Request too large." }, 413);
  let b; try { b = JSON.parse(raw); } catch { return json({ ok: false, error: "Invalid request." }, 400); }
  if (!b || typeof b !== "object" || Array.isArray(b)) return json({ ok: false, error: "Invalid request." }, 400);

  const ip = (request.headers.get("cf-connecting-ip") || request.headers.get("x-nf-client-connection-ip") || (request.headers.get("x-forwarded-for") || "").split(",")[0] || "unknown").trim();
  if (rateLimited(ip)) return json({ ok: false, error: "Too many enquiries from this connection. Please try again in a few minutes or call us." }, 429, { "Retry-After": "600" });

  // Spam traps: hidden field filled, or form submitted impossibly fast → pretend success, send nothing.
  if (clean(b.website, 200) || (Number.isFinite(+b.elapsedMs) && +b.elapsedMs < 2500)) return json({ ok: true, enquiryCode: makeReference() });

  const { v, e } = validate(b);
  if (Object.keys(e).length) return json({ ok: false, error: "Please correct the highlighted details.", fieldErrors: e }, 422);

  const key = env.RESEND_API_KEY;
  if (!key) { console.error("enquiry: RESEND_API_KEY is not set"); return json({ ok: false, error: "Online enquiries are temporarily unavailable. Please call us." }, 503); }

  const ref = makeReference();
  const enquiringAbout = (clean(b.message, 1000).match(/^\[Enquiring about: ([^\]]{1,120})\]/) || [])[1] || "";
  const when = new Intl.DateTimeFormat("en-IN", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Kolkata" }).format(new Date());
  const { text, html } = buildEmail(v, ref, { enquiringAbout, when });
  const idem = clean(b.idempotencyKey, 64).replace(/[^\w-]/g, "") || undefined;
  const ctrl = new AbortController(), t = setTimeout(() => ctrl.abort(), 12_000);
  try {
    const res = await fetch(env.RESEND_API_URL || "https://api.resend.com/emails", {
      method: "POST", signal: ctrl.signal,
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json", ...(idem ? { "Idempotency-Key": `mathletics-${idem}` } : {}) },   // Resend de-duplicates retries with the same key
      body: JSON.stringify({
        from: env.ENQUIRY_FROM || "MATHLETICS Website <onboarding@resend.dev>", to: [env.ENQUIRY_TO_EMAIL || TO_DEFAULT],
        reply_to: v.email, subject: `NEW ADMISSION ENQUIRY — MATHLETICS (${ref}) — ${v.studentName}`, html, text
      })
    });
    if (!res.ok) { console.error("enquiry: provider error", res.status, (await res.text().catch(() => "")).slice(0, 300)); return json({ ok: false, error: "We could not deliver your enquiry right now. Please try again shortly or call us." }, 502); }
    return json({ ok: true, enquiryCode: ref });
  } catch (err) {
    console.error("enquiry: delivery failed", err && err.name);
    return json({ ok: false, error: "We could not deliver your enquiry right now. Please try again shortly or call us." }, 502);
  } finally { clearTimeout(t); }
}
