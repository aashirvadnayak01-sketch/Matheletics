# MATHLETICS — SEO implementation report

Date: 2026-11-05 · Scope: the existing MATHLETICS website (design unchanged) rebuilt as a **prerendered, multi-page static site** with technical SEO, local-SEO readiness, structured data, performance work and privacy-first conversion tracking.

**What this report claims — and does not.** Everything below marked *verified* was run in this workspace (offline build, own audit script, Playwright in Chromium). Nothing here shows that Google has crawled, indexed or ranked the site, that structured data passed Google's Rich Results Test, or what real-user Core Web Vitals are. Those need your live domain and Google tools (section 9). No rankings are promised.

---
## 1. Audit of the existing build (before)

| # | Finding | Severity | Fixed? |
|---|---------|----------|--------|
| 1 | Single-page app with **hash routes** (`#/privacy`, `#/admin`) — Google ignores URL fragments, so legal pages and any future page could never be indexed separately | Critical | Yes — real URLs (`/about/`, `/programmes/…`) |
| 2 | All content rendered by JavaScript after load (empty `<div id="app">`) — relies on Google's render queue | High | Yes — every page is prerendered HTML |
| 3 | One title and one meta description for the whole site; no per-page metadata | High | Yes — unique per page (checked) |
| 4 | No canonical URLs, no sitemap.xml, no robots.txt (single-file edition); React project's robots.txt had `Disallow: /admin` | High | Yes — see §5. `/admin` is `noindex` instead of robots-blocked |
| 5 | No structured data | Medium | Yes — JSON-LD `@graph`, gated on verified data |
| 6 | Footer column headings were `<h3>` with no `<h2>` above them (broken hierarchy) | Medium | Yes — `<h2>` |
| 7 | OG/Twitter tags minimal, no share image, no real favicon files/apple-touch-icon/manifest | Medium | Yes |
| 8 | No skip link, no `<main>` landmark | Medium | Yes |
| 9 | Blocking 3-family Google Fonts stylesheet; unversioned JS | Medium | Yes — non-blocking font load, content-hashed immutable assets |
| 10 | Intro animation overlay shown to every visitor incl. crawlers/Lighthouse | Medium | Yes — skipped for bots/reduced-motion; still once per session, skippable |
| 11 | "Why Choose" text clipped on the right (reveal-animation CSS specificity bug) | Bug (user-reported) | Yes — fixed; verified no clipping at 360–1366 px |
| 12 | Placeholder results/testimonials/programmes visible | Content | Kept & labelled; their pages are `noindex` + excluded from sitemap |
| 13 | No `alt` problems (site uses inline decorative SVG, no `<img>`); no broken internal links found | — | Audit script enforces both |

## 2. Architecture decision: prerender, no framework migration
The existing React project is untested (npm was unreachable when it was written) and the working version is vanilla JS. Rather than bolt SSR onto either, I assessed options:

* **SSR (Next/Remix)** — heavy, needs a Node host, adds risk for a 10-page brochure site. Rejected.
* **Client-side SPA + dynamic rendering** — discouraged by Google. Rejected.
* **Build-time prerender of real pages (chosen)** — crawlers receive complete HTML; JS only enhances (menu, animations, form, carousel). Zero runtime dependencies, any static host/CDN.

The React project (`mathletics-project.zip`) was **not modified**. This folder is the SEO-ready edition; same visuals (same CSS, same M mark, same sections).

## 3. Pages & URL structure
| URL | Purpose | Indexed today? |
|---|---|---|
| `/` | Home (all original sections) | Yes (once `SITE_URL` set) |
| `/about/` | About the institution | Yes |
| `/mathematics-coaching/` | Mathematics coaching (approach, journey, support) | Yes |
| `/programmes/` + `/programmes/<slug>/` | Programme listing + one page per programme (class-specific by design) | **No** — samples are `placeholder:true`; switches to indexed when you replace them |
| `/boards/<slug>/` | Board-specific pages — generated **only** for boards with `offered:true` (none configured) | n/a |
| `/teacher/` | Teacher introduction — generated **only** when `teacher.verified` + name set | not generated |
| `/admission/` | Contact & admission (form, FAQ, verified contact block) | Yes |
| `/learning-hub/` + `/learning-hub/<slug>/` | Article hub; articles appear only when `published:true` | **No** until first article is live |
| `/privacy/`, `/terms/` | Legal (draft text — needs review) | Yes |
| `/admin/` | Protected dashboard | `noindex`, `X-Robots-Tag`, `no-store`, not in sitemap |
| `/404.html` | Real 404 status | `noindex` |

Trailing-slash URLs everywhere; internal links, canonicals and sitemap all use the same form. Old `#/privacy` etc. links redirect client-side.

## 4. On-page SEO
* Home title: `Mathletics Coaching | Mathematics Tuition in {CITY}`; description exactly as specified. `{CITY}` comes from `site.config.js`; **while city is blank the ` in {CITY}` part is omitted** instead of printing a placeholder or guessing a city.
* Other pages: `<Page> | Mathletics Coaching`, unique descriptions ≤ 160 chars. Audit fails the build on duplicates/missing.
* One `<h1>` per page, no skipped heading levels (enforced). Hero H1 kept brand-led ("Think Beyond Numbers…"); the lead sentence beneath it now reads "Mathematics coaching{ in city} focused on…" so the topic/location sit directly under the H1 without altering the design. No keyword stuffing; copy added is plain and makes no factual claims.
* Teacher photo: `src/static/assets/teacher.webp` (background cut out by `tools/cutout-photo.py`; person pixels untouched). Replace the file (jpg/png/webp named `teacher.*`) to change it; it is also used for Person markup.
* Programme names are real links (`<h3><a>`), "Enquire Now" is a crawlable link to `/admission/?programme=…` that JS upgrades on the home page.

## 5. Technical infrastructure
* **Canonical** on every indexable page (self-referencing, absolute). None in staging mode.
* **robots.txt** — production: `Allow: /` + `Sitemap:`. No unnecessary `Disallow`. Staging: `Disallow: /`.
* **sitemap.xml** — only indexable, 200-status, canonical URLs; `lastmod` only where a real article date exists (no fake dates).
* **Staging safety**: if `SITE_URL` is unset, every page is `noindex`, robots blocks all, no sitemap/canonicals. A test deployment cannot be indexed by accident.
* **HTTPS / redirects / status codes**: `_headers`, `_redirects` (Netlify/Cloudflare Pages) and `vercel.json` are generated: HSTS, http→https and alternate-host→canonical-host 301s, immutable caching for hashed assets, `X-Robots-Tag` on admin, nosniff/Referrer-Policy/Permissions-Policy. Real 404 status for unknown URLs. *HTTPS enforcement ultimately happens at your host/CDN; confirm with the commands in §9.*
* **Open Graph / Twitter**: title, description, url, 1200×630 image (generated from the brand mark, no invented claims), alt text, locale `en_IN`.
* **Favicons**: SVG + ICO + apple-touch-icon + 192/512 PNG + web manifest.
* **Semantic/accessible**: skip link, `<header>/<nav>/<main>/<footer>`, labelled navs, `aria-current`, breadcrumb nav, reduced-motion respected, no-JS content visible (verified).
* **CSP** not shipped (inline JSON-LD / font-loader would need hashes); add at your host if wanted.

## 6. Structured data (JSON-LD `@graph`)
| Type | When emitted |
|---|---|
| `EducationalOrganization` | Always (name, url, logo, image, description) |
| + `LocalBusiness` (multi-type) | **Only** when `contactVerified` **and** a street address + locality are set (physical location) |
| `telephone`, `email`, `address`, `geo`, `openingHoursSpecification`, `areaServed`, `sameAs` | Only when filled in (and, for contact data, only when `contactVerified:true`) |
| `WebSite` | Home |
| `Person` | Only when `teacher.verified:true` and a name is set (home + `/teacher/`) |
| `BreadcrumbList` | Every non-home page |
| `Course` | Only for programmes **not** marked placeholder |
| `Article` | Only for `published:true` articles |

Deliberately **not** added: `Review`/`AggregateRating` (no real reviews exist), `FAQPage` (Google limits FAQ rich results to government/health sites, so it would be markup with no benefit), `Offer`/prices (none given).
*Verified:* an offline validator (`check.mjs`) parses every block, rejects empty properties, dangling `@id`s, forbidden review types, wrong origins, invalid breadcrumbs. This is **not** Google's validator — run the Rich Results Test and Schema Markup Validator on the live URL.

## 7. Performance (lab only)
Measured with Playwright/Chromium against the built site: emulated Pixel 5, 4× CPU throttle, Slow-4G (1.6 Mbit/s, 150 ms RTT); fonts stubbed (no internet in the sandbox, so web-font swap effects are **not** included).

| Page (mobile, throttled) | LCP | CLS | TBT≈ | INP≈ |
|---|---|---|---|---|
| `/` | 740 ms | 0.000 | 185 ms | 32 ms |
| `/about/` | 624 ms | 0.000 | 87 ms | 56 ms |
| `/programmes/programme-one/` | 568 ms | 0.000 | 26 ms | 56 ms |

All inside the targets (LCP < 2.5 s, INP < 200 ms, CLS < 0.1) **in the lab**. Field data (CrUX / Search Console "Core Web Vitals") only exists after real traffic. INP here is from my own scripted clicks, not real users.
What was done: prerendered HTML (home 8 KB gzip), one hashed CSS file (8 KB gzip), JS split into ES modules — `app` 3.7 KB + `ui` 2.4 KB gzip load on every page; the **form (5.6 KB) loads only when it nears the viewport**, **admin (7 KB) only on `/admin/`**; modulepreload; non-blocking font stylesheet with `display=swap`; immutable cache headers; intro skipped for bots; transform/opacity-only animations; `min-height` on the form container and explicit SVG sizes to avoid layout shift.
Not done (needs network/tools unavailable here): self-hosting the fonts (best LCP/privacy win — see TODO), JS minification (hosts gzip/brotli; add esbuild later if desired), raster image optimisation (the site has none — all visuals are inline SVG).

## 8. Conversion tracking (privacy-first)
Cookieless, Plausible-compatible, **off by default** (`analytics.provider:"none"`), honours Do-Not-Track, loaded only when configured. Events: `admission_form_submit` (optional `programme` name only), `programme_enquiry`, `phone_click`, `whatsapp_click`, `email_click`, `apply_click`. Never sent: names, phone, e-mail, message, enquiry ID. Privacy Policy text already describes this. *Verified:* click→event wiring with a stubbed analytics function; the real Plausible dashboard needs your account.

## 9. Final audit — what was verified
* Production build runs clean in staging mode, in production mode (test URL), and in a fully-configured mode (city, verified contact, teacher, socials, analytics, drafts) — **all with 0 failures** in `check.mjs` (≈1,500 assertions: titles/descriptions unique & present, canonicals, robots meta, single H1/heading order, OG/Twitter, internal links & anchors, local asset references, JSON-LD rules, sitemap = exactly the indexable set and contains no `noindex` page, robots.txt, no secrets in JS).
* Playwright (Chromium) — **125 checks (staging) + 141 (full)** pass: every route returns the right status; trailing-slash 301; unknown URL → 404; no console/page errors and no horizontal overflow at 375/768/1280; Why-section text fully visible; FAQ, carousel, Learn More, programme→form prefill, 4-step form validation (Indian mobile, consent, double-click protection) and mocked successful submit with correct payload; mobile menu; admin gate + `noindex`; intro shows once, is skippable and is skipped for a Googlebot UA; no-JS content visible; analytics events.
* **Not verified (cannot be from here):** real Supabase/Resend delivery (the form was tested against a mocked endpoint), Google crawling/indexing, Rich Results Test, Search Console data, real-user CWV, HTTPS/redirect behaviour on your host, web-font impact on CLS.

## 10. Remaining manual configuration
See `README.md` → "Go-live checklist" (city, domain, verified contact, teacher, content replacement, Supabase keys, Search Console, sitemap submission, URL Inspection, Rich Results Test, host redirects, optional analytics).
