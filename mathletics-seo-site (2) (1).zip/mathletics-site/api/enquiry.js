// Vercel Function → POST /api/enquiry. Set environment variables in Project settings.
import { handleEnquiry } from "../server/enquiry-core.js";
export const POST = (request) => handleEnquiry(request, process.env);
export const OPTIONS = (request) => handleEnquiry(request, process.env);
export const GET = (request) => handleEnquiry(request, process.env);
