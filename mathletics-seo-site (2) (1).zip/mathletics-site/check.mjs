#!/usr/bin/env node
// SEO / integrity audit of a built site.   node check.mjs [dir=dist]
// Offline and dependency-free. It validates what can be validated locally; it is NOT a substitute for
// Google's Rich Results Test / URL Inspection (see docs/SEO-REPORT.md).
import fs from "node:fs";
import path from "node:path";
const DIR = path.resolve(process.argv[2] || "dist");
const info = JSON.parse(fs.readFileSync(path.join(DIR, "build-info.json"), "utf8"));
const fails = [], warns = []; let passes = 0;
const ok = (c, msg, warn = false) => { if (c) passes++; else (warn ? warns : fails).push(msg); };
const read = f => fs.readFileSync(path.join(DIR, f), "utf8");
const fileOf = p => p.endsWith(".html") ? p.slice(1) : path.posix.join(p, "index.html").slice(1);
const pageSet = new Set(info.pages.map(p => p.path));
const decode = s => s.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
const strip = s => decode(s.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim());

const titles = new Map(), descs = new Map();
const idsByPage = {};
for (const p of info.pages) idsByPage[p.path] = new Set([...read(fileOf(p.path)).matchAll(/\sid="([^"]+)"/g)].map(m => m[1]));

for (const p of info.pages) {
  const html = read(fileOf(p.path)), L = `[${p.path}]`;
  const head = html.slice(0, html.indexOf("</head>"));
  const meta = (n, attr = "name") => { const m = head.match(new RegExp(`<meta ${attr}="${n}" content="([^"]*)"`)); return m ? decode(m[1]) : null; };
  const title = (head.match(/<title>([^<]*)<\/title>/) || [])[1];
  ok(title && title.trim(), `${L} missing <title>`);
  if (title) {
    ok(title.length <= 70, `${L} title is ${title.length} chars (>70 may be truncated)`, true);
    ok(!titles.has(title), `${L} duplicate title (same as ${titles.get(title)})`); titles.set(title, p.path);
  }
  const d = meta("description");
  ok(d && d.length >= 50, `${L} missing/short meta description`);
  if (d) { ok(d.length <= 165, `${L} description is ${d.length} chars (>165 may be truncated)`, true); ok(!descs.has(d), `${L} duplicate description (same as ${descs.get(d)})`); descs.set(d, p.path); }
  ok(/<html lang="[a-z-]+"/i.test(html), `${L} missing html lang`);
  ok(/<meta name="viewport"/.test(head), `${L} missing viewport`);

  // robots + canonical
  const robots = meta("robots") || "";
  const wantIndex = !!p.index && !info.staging;
  ok(wantIndex ? /^index/.test(robots) : /noindex/.test(robots), `${L} robots meta "${robots}" does not match expected ${wantIndex ? "index" : "noindex"}`);
  const canon = (head.match(/<link rel="canonical" href="([^"]+)"/) || [])[1];
  if (info.staging) ok(!canon, `${L} staging build must not emit a canonical`);
  else {
    ok(canon === info.url + p.path || p.path === "/404.html" && !canon, `${L} canonical "${canon}" ≠ expected "${info.url}${p.path}"`);
    ok((head.match(/rel="canonical"/g) || []).length <= 1, `${L} multiple canonicals`);
  }
  if (p.path !== "/404.html" && !p.admin) {
    for (const k of ["og:title", "og:description", "og:image", "og:type", "og:site_name"]) ok(meta(k, "property"), `${L} missing ${k}`);
    for (const k of ["twitter:card", "twitter:title", "twitter:image"]) ok(meta(k), `${L} missing ${k}`);
    if (!info.staging) ok(meta("og:url", "property") === info.url + p.path, `${L} og:url mismatch`);
  }
  ok(/rel="icon"/.test(head) && /rel="apple-touch-icon"/.test(head), `${L} missing icon links`);

  // headings
  const body = html.slice(html.indexOf("<body"));
  const hs = [...body.matchAll(/<h([1-6])[\s>]/g)].map(m => +m[1]);
  if (!p.admin) {
    ok(hs.filter(h => h === 1).length === 1, `${L} has ${hs.filter(h => h === 1).length} <h1> (expected exactly 1)`);
    let prev = 0, skipped = false; for (const h of hs) { if (prev && h > prev + 1) skipped = true; prev = h; }
    ok(!skipped, `${L} heading levels skip (${hs.join(",")})`);
  }
  ok(/<main[\s>]/.test(body) || p.admin, `${L} missing <main>`);
  ok(/class="skip"/.test(body), `${L} missing skip link`);
  ok(!/<img(?![^>]*\balt=)[^>]*>/.test(body), `${L} <img> without alt`);
  ok(!/<a\b(?![^>]*\bhref=)[^>]*>/.test(body.replace(/<noscript>[\s\S]*?<\/noscript>/g, "")), `${L} <a> without href`);
  ok(!/<button(?![^>]*\btype=)/.test(body), `${L} <button> without type`, true);
  ok(!/\b(placeholder|lorem ipsum)\b.*(\+91|@)/i.test(body), `${L} possible fake contact data`, true);

  // links
  for (const m of body.matchAll(/<a\b[^>]*\bhref="([^"]+)"/g)) {
    const href = decode(m[1]);
    if (/^(mailto:|tel:|https?:|javascript:)/.test(href)) { ok(!/^javascript:/.test(href), `${L} javascript: link`); continue; }
    const [pth, hash] = href.split("#"); const clean = (pth || "").split("?")[0];
    const target = clean === "" ? p.path : clean;
    const exists = pageSet.has(target) || fs.existsSync(path.join(DIR, target.slice(1)));
    ok(exists, `${L} broken internal link ${href}`);
    if (hash && pageSet.has(target)) ok(idsByPage[target].has(hash), `${L} anchor #${hash} not found on ${target}`);
  }
  // local assets referenced
  for (const m of head.matchAll(/(?:href|src)="(\/[^"#?]+)"/g)) ok(fs.existsSync(path.join(DIR, m[1].slice(1))) || pageSet.has(m[1]), `${L} missing asset ${m[1]}`);

  // JSON-LD
  const blocks = [...head.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)];
  if (p.path === "/404.html" || p.admin) { ok(blocks.length === 0, `${L} should not carry structured data`); continue; }
  ok(blocks.length === 1, `${L} expected one JSON-LD block, found ${blocks.length}`);
  for (const b of blocks) {
    let j; try { j = JSON.parse(b[1]); } catch (e) { fails.push(`${L} JSON-LD does not parse: ${e.message}`); continue; }
    const g = j["@graph"] || [j]; const ids = new Set(g.map(n => n["@id"]).filter(Boolean));
    const T = n => [].concat(n["@type"]);
    ok(j["@context"] === "https://schema.org", `${L} JSON-LD @context`);
    const walk = (n, f) => { if (Array.isArray(n)) n.forEach(x => walk(x, f)); else if (n && typeof n === "object") { f(n); Object.values(n).forEach(x => walk(x, f)); } };
    walk(g, n => {
      for (const [k, v] of Object.entries(n)) { if (v === "" || v === null || (Array.isArray(v) && !v.length)) fails.push(`${L} JSON-LD empty property ${k} on ${T(n)}`); }
      if (n["@id"] && Object.keys(n).length === 1) ok(ids.has(n["@id"]) , `${L} JSON-LD dangling @id reference ${n["@id"]}`);
      for (const t of T(n)) { ok(!/^(Review|AggregateRating|Rating)$/.test(t || ""), `${L} forbidden fake-review type ${t}`); }
      ok(!("aggregateRating" in n) && !("review" in n), `${L} aggregateRating/review must not be present`);
    });
    const org = g.find(n => T(n).includes("EducationalOrganization"));
    ok(org, `${L} missing EducationalOrganization`);
    if (org) {
      for (const k of ["name", "url", "@id", "logo", "description"]) ok(org[k], `${L} Organization missing ${k}`);
      if (!info.staging) ok(String(org.url).startsWith(info.url), `${L} Organization url not on site origin`);
      if (T(org).includes("LocalBusiness")) ok(org.address && org.address.streetAddress && org.telephone !== "", `${L} LocalBusiness requires a real address`);
    }
    const bc = g.find(n => T(n).includes("BreadcrumbList"));
    if (p.path !== "/") ok(bc && bc.itemListElement.every((x, i) => x.position === i + 1 && x.name && x.item), `${L} BreadcrumbList invalid`);
    if (p.path === "/") ok(g.some(n => T(n).includes("WebSite")), `${L} home should carry WebSite`);
  }
}

// sitemap / robots
const rob = read("robots.txt");
if (info.staging) { ok(/Disallow: \//.test(rob), "robots.txt must block crawling in staging"); ok(!fs.existsSync(path.join(DIR, "sitemap.xml")), "staging build should not ship a sitemap"); }
else {
  ok(/Sitemap: .+\/sitemap\.xml/.test(rob), "robots.txt must reference the sitemap"); ok(!/Disallow:\s*\/\s*$/m.test(rob), "robots.txt blocks the whole site");
  ok(!/Disallow:\s*\/admin/.test(rob), "robots.txt should not Disallow /admin (use noindex so it can be seen)", true);
  const xml = read("sitemap.xml"), locs = [...xml.matchAll(/<loc>([^<]+)<\/loc>/g)].map(m => m[1]);
  const want = info.pages.filter(p => p.index).map(p => info.url + p.path);
  ok(JSON.stringify([...locs].sort()) === JSON.stringify(want.sort()), `sitemap URLs differ from indexable pages (sitemap ${locs.length}, expected ${want.length})`);
  ok(new Set(locs).size === locs.length, "sitemap has duplicate URLs");
  for (const l of locs) { const pth = l.slice(info.url.length); ok(pageSet.has(pth), `sitemap URL not built: ${l}`); ok(!/noindex/.test(read(fileOf(pth))), `sitemap lists a noindex page: ${l}`); ok(l.startsWith("https://"), `sitemap URL not https: ${l}`); }
}
// secrets
for (const f of fs.readdirSync(path.join(DIR, "assets/js"))) { const s = read("assets/js/" + f); ok(!/service_role|sb_secret_|re_[A-Za-z0-9]{20,}/.test(s), `possible secret in ${f}`); }
ok(read("_headers").includes("nosniff"), "_headers missing security headers");

console.log(`\n${info.staging ? "STAGING" : "PRODUCTION"} audit of ${DIR}\n  ${info.pages.length} pages · ${passes} checks passed · ${warns.length} warnings · ${fails.length} failures`);
for (const w of warns) console.log("  WARN  " + w);
for (const f of fails) console.log("  FAIL  " + f);
process.exit(fails.length ? 1 : 0);
