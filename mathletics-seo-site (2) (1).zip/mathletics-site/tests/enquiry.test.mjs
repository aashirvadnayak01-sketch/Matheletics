// Run: node tests/enquiry.test.mjs   — exercises server/enquiry-core.js against a local MOCK of the Resend API.
// (It cannot prove delivery to a real inbox; see README → "Verify delivery".)
import http from "node:http";
import { handleEnquiry, _resetRateLimit } from "../server/enquiry-core.js";
const received = []; let mode = "ok";
const mock = http.createServer(async (req, res) => { const c = []; for await (const x of req) c.push(x); received.push({ headers: req.headers, body: JSON.parse(Buffer.concat(c) || "{}") });
  if (mode === "fail") { res.writeHead(500).end('{"message":"boom"}'); return; } res.writeHead(200, { "content-type": "application/json" }).end('{"id":"test-id"}'); }).listen(0);
await new Promise(r => mock.on("listening", r));
const env = { RESEND_API_KEY: "re_test_key", RESEND_API_URL: `http://localhost:${mock.address().port}/emails`, SITE_URL: "https://www.example.test" };
const good = () => ({ studentName: "Aarav Sharma", parentName: "Priya Sharma", currentClass: "Class 9", subjects: ["Mathematics", "Physics"], learningMode: "One-on-one (private)", message: "[Enquiring about: Demo class request]\nPlease call after 5 pm <b>thanks</b>", mobile: "+91 79910 52911", email: "Parent@Example.com", consent: true, website: "", idempotencyKey: "abc-123", elapsedMs: 9000 });
let n = 0;
const post = (body, { origin = "https://www.example.test", ip = `10.0.0.${++n}`, ct = "application/json", e = env, method = "POST" } = {}) =>
  handleEnquiry(new Request("https://www.example.test/api/enquiry", { method, headers: { "content-type": ct, origin, host: "www.example.test", "x-forwarded-for": ip }, body: method === "POST" ? (typeof body === "string" ? body : JSON.stringify(body)) : undefined }), e);
let pass = 0; const fails = []; const ok = (c, m) => (c ? pass++ : fails.push(m));
const j = r => r.json();

let r = await post(good()); let b = await j(r);
ok(r.status === 200 && b.ok && /^MATH-\d{6}-[A-Z2-9]{4}$/.test(b.enquiryCode), "valid enquiry accepted");
const m = received.at(-1);
ok(received.length === 1, "exactly one provider call");
ok(m.headers.authorization === "Bearer re_test_key", "provider auth header");
ok(m.body.to.length === 1 && m.body.to[0] === "pradyumnakishorrath@gmail.com", "recipient is the configured inbox");
ok(m.body.reply_to === "parent@example.com", "Reply-To = visitor email");
ok(m.body.subject.includes("NEW ADMISSION ENQUIRY") && m.body.subject.includes(b.enquiryCode), "subject has reference");
for (const f of ["Aarav Sharma", "Priya Sharma", "Class 9", "Mathematics, Physics", "One-on-one (private)", "7991052911", "parent@example.com", "Demo class request", "Please call after 5 pm"]) ok(m.body.html.includes(f) && m.body.text.includes(f.replace("<b>", "")) , `email contains "${f}"`);
ok(!m.body.html.includes("<b>thanks</b>") && m.body.html.includes("&lt;b&gt;thanks"), "message is HTML-escaped (no injection)");
ok(m.headers["idempotency-key"] === "mathletics-abc-123", "idempotency key forwarded (duplicate protection)");
ok(!JSON.stringify(b).includes("re_test_key"), "no secret in response");

_resetRateLimit(); received.length = 0;
for (const [label, patch, field] of [["bad name", { studentName: "A1!" }, "studentName"], ["bad parent", { parentName: "" }, "parentName"], ["bad class", { currentClass: "Class 5" }, "currentClass"], ["no subject", { subjects: [] }, "subjects"], ["other subject", { subjects: ["Chemistry"] }, "subjects"], ["bad mobile", { mobile: "12345" }, "mobile"], ["bad email", { email: "nope" }, "email"], ["header-injection email", { email: "a@b.com\nBcc: x@y.com" }, "email"], ["no consent", { consent: false }, "consent"]]) {
  r = await post({ ...good(), ...patch }); b = await j(r); ok(r.status === 422 && b.fieldErrors && b.fieldErrors[field], `validation rejects ${label}`);
}
ok(received.length === 0, "invalid submissions send nothing");
r = await post({ ...good(), website: "http://spam.example" }); b = await j(r); ok(r.status === 200 && b.ok && received.length === 0, "honeypot: fake success, nothing sent");
r = await post({ ...good(), elapsedMs: 300 }); ok((await j(r)).ok && received.length === 0, "too-fast submit treated as bot, nothing sent");
r = await post(good(), { origin: "https://evil.example" }); ok(r.status === 403 && received.length === 0, "foreign Origin blocked");
r = await post(good(), { origin: "" }); ok(r.status === 403, "missing Origin blocked");
r = await post("{bad json"); ok(r.status === 400, "malformed JSON → 400");
r = await post(good(), { ct: "text/plain" }); ok(r.status === 415, "wrong content-type → 415");
r = await post({ ...good(), message: "x".repeat(9000) }); ok(r.status === 413, "oversized body → 413");
r = await post(null, { method: "GET" }); ok(r.status === 405, "GET → 405");
r = await post({ ...good(), message: "y".repeat(2000) }); b = await j(r); ok(r.status === 200 && received.at(-1).body.text.split("Message: ")[1].split("\n")[0].length <= 1000, "message truncated to 1000 chars");
_resetRateLimit(); received.length = 0; let last;
for (let i = 0; i < 7; i++) last = await post(good(), { ip: "9.9.9.9" });
ok(last.status === 429 && received.length === 5, "rate limit: 5 per 10 min per IP then 429");
_resetRateLimit(); mode = "fail"; r = await post(good(), { ip: "2.2.2.2" }); b = await j(r);
ok(r.status === 502 && b.ok === false && /call us/i.test(b.error) && !JSON.stringify(b).includes("boom"), "provider failure → 502 with friendly error, no internals leaked");
mode = "ok"; r = await post(good(), { e: { ...env, RESEND_API_KEY: "" }, ip: "3.3.3.3" }); ok(r.status === 503, "missing API key → 503 (never fakes success)");
mock.close();
console.log(`enquiry core: ${pass} passed, ${fails.length} failed`); fails.forEach(f => console.log("  FAIL " + f)); process.exit(fails.length ? 1 : 0);
