// Cloudflare Pages Function → POST /api/enquiry   (set RESEND_API_KEY etc. as encrypted environment variables)
import { handleEnquiry } from "../../server/enquiry-core.js";
export const onRequest = ({ request, env }) => handleEnquiry(request, env);
