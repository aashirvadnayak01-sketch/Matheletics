#!/usr/bin/env node
// Tiny static server that behaves like a typical static host: directory index, 301 for missing trailing slash, real 404 page.
//   node serve.mjs [dir=dist] [port=4173]
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { handleEnquiry } from "./server/enquiry-core.js";
const dir = path.resolve(process.argv[2] || "dist"), port = +(process.argv[3] || 4173);
const T = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".json": "application/json", ".xml": "application/xml", ".txt": "text/plain; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon", ".webmanifest": "application/manifest+json" };
http.createServer(async (req, res) => {
  if (new URL(req.url, "http://x").pathname === "/api/enquiry") {      // same handler the serverless adapters use
    const chunks = []; for await (const c of req) chunks.push(c);
    const r = await handleEnquiry(new Request(`http://${req.headers.host}/api/enquiry`, { method: req.method, headers: req.headers, body: ["GET", "HEAD"].includes(req.method) ? undefined : Buffer.concat(chunks) }), process.env);
    res.writeHead(r.status, Object.fromEntries(r.headers)); res.end(Buffer.from(await r.arrayBuffer())); return;
  }
  let u = decodeURIComponent(new URL(req.url, "http://x").pathname), f = path.join(dir, u);
  if (!f.startsWith(dir)) { res.writeHead(403).end(); return; }
  if (fs.existsSync(f) && fs.statSync(f).isDirectory()) {
    if (!u.endsWith("/")) { res.writeHead(301, { Location: u + "/" + (new URL(req.url, "http://x").search) }).end(); return; }
    f = path.join(f, "index.html");
  }
  let code = 200;
  if (!fs.existsSync(f)) { f = path.join(dir, "404.html"); code = 404; }
  const ext = path.extname(f), body = fs.readFileSync(f);
  const h = { "Content-Type": T[ext] || "application/octet-stream", "Cache-Control": u.startsWith("/assets/") ? "public, max-age=31536000, immutable" : "no-cache" };
  if (/(html|css|javascript|json|xml|svg|text)/.test(h["Content-Type"]) && /gzip/.test(req.headers["accept-encoding"] || "")) { h["Content-Encoding"] = "gzip"; res.writeHead(code, h).end(zlib.gzipSync(body)); }
  else res.writeHead(code, h).end(body);
}).listen(port, () => console.log(`serving ${dir} on http://localhost:${port}`));
