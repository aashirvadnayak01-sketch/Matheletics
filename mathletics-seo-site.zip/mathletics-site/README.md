# MATHLETICS — SEO-ready static site

Same design as the original MATHLETICS site, rebuilt as real, prerendered pages. No runtime dependencies (Node ≥ 18 to build).

```bash
npm run build            # → dist/   (STAGING build: noindex everywhere until SITE_URL is set)
SITE_URL=https://www.your-domain.in npm run build      # production build
npm run check            # SEO / integrity audit of dist/ (fails on errors)
npm run serve            # preview dist/ at http://localhost:4173
npm run assets           # regenerate favicon / share image (needs Playwright; optional)
npm run build:drafts     # also preview unpublished articles (noindex)
```
Deploy `dist/` to any static host (Cloudflare Pages, Netlify, Vercel, S3+CDN). `_headers`, `_redirects`, `vercel.json` are generated for you.

## Where to edit
| File | What |
|---|---|
| `src/site.config.js` | **Start here.** City, domain, verified address/phone/e-mail/WhatsApp, hours, social profiles, teacher, Search Console tag, analytics, Supabase URL/anon key |
| `src/content.js` | Programmes (slug, class label, subjects, details), boards offered, about/why/journey, results, testimonials, FAQ, **Learning Hub articles**, legal text |
| `src/styles.css` | Design (unchanged from the original) |
| `src/client/*.js` | Browser code (form, admin, menu, carousel, analytics) |
| `src/lib/*.js` | Page templates, SEO head + JSON-LD |

Rules baked in (so nothing gets invented): empty fields are never printed; contact data/LocalBusiness/Person markup only appear after you set `contactVerified: true` / `teacher.verified: true`; pages built on `placeholder: true` content stay `noindex` and out of the sitemap until you replace the content and delete the flag.
Keys: only the **anon/publishable** Supabase key ever belongs here (the build refuses a service-role key). The service-role and Resend keys stay in Supabase Edge Function secrets — see the original project's `supabase/` folder and README for the database, functions and admin user.

## Go-live checklist (manual — none of this can be done for you)
1. **Domain & hosting**: pick the canonical host (e.g. `https://www.…`). Set `SITE_URL` in your host's build environment and build. Enable HTTPS; keep the generated redirects (http→https, other host→canonical).
2. **City**: set `city` (and `region`). Titles/descriptions/headings update automatically.
3. **Verified business details**: fill `address`, `phone`, `email`, `whatsapp`, `hours` exactly as on your Google Business Profile, then `contactVerified: true`. (Keep NAP identical everywhere.)
4. **Google Business Profile**: create/claim and verify it (Google's process; needed for Maps/local pack). Add your site URL there.
5. **Replace placeholders** in `src/content.js`: programmes (real class ranges/subjects), results and testimonials (only genuine, consented), then remove `placeholder: true`. Add boards only if genuinely offered. Add the teacher profile (`verified: true`) only with truthful details.
6. **Write original Learning Hub articles**, set `published: true` with real dates.
7. **Supabase**: set `supabase.url` + `anonKey` (or `SUPABASE_URL`/`SUPABASE_ANON_KEY` env vars); deploy the Edge Functions and create the admin user per the original project README. Submit one real test enquiry end-to-end (form → database → coaching-head e-mail) — **this has not been tested against a live backend**.
8. **Search Console** (https://search.google.com/search-console): add a *Domain property* and verify via DNS TXT at your registrar (no code needed) — or a URL-prefix property using the HTML tag (paste the content value into `searchConsole.googleSiteVerification`, rebuild).
9. **Sitemap**: Search Console → Sitemaps → submit `https://your-domain/sitemap.xml`. Confirm `https://your-domain/robots.txt` shows `Allow: /` (not `Disallow: /`).
10. **URL Inspection**: inspect `/`, then "Request indexing" for the home page and key pages. Indexing is Google's decision and can take days or weeks; check *Pages* (index coverage) afterwards.
11. **Validate**: run each key URL through Google's **Rich Results Test** and validator.schema.org; PageSpeed Insights for real field data once traffic exists; check *Experience → Core Web Vitals* in Search Console after ~28 days.
12. **Analytics (optional)**: create a Plausible (or compatible) site, set `analytics.provider:"plausible"` and `plausibleDomain`, rebuild; add goals named `admission_form_submit`, `programme_enquiry`, `demo_request`, `group_enquiry`, `private_enquiry`, `phone_click`, `whatsapp_click`, `email_click`.
13. **Self-host fonts** (optional performance win): download Manrope, Space Grotesk, Instrument Serif (woff2) into `src/static/fonts/`, add `@font-face` to `styles.css`, and drop the Google Fonts link in `src/lib/seo.js`.
14. **Legal**: have the Privacy Policy and Terms reviewed before launch.
15. **Verify after deploy**: `curl -sI http://your-domain/ | head -3` (expect 301 → https), `curl -sI https://alt-host/` (301 → canonical), `curl -sI https://your-domain/nope/` (404).

## Local search: "coaching in Sambalpur" / "near me"
* The site now names Sambalpur in titles, headings, structured data (`areaServed`) and the footer. It never claims "best" (an unverifiable claim).
* "Near me" results come mostly from **Google Business Profile** (category e.g. "Tutoring service"/"Coaching center", exact address, phone, hours, photos, genuine reviews) — create and verify it, use the same phone numbers as the site, and add the website URL.
* Add the street address + `openingHours` in `site.config.js` once verified → the site then emits `LocalBusiness` markup.
* Ask satisfied parents for genuine Google reviews (never fabricate or incentivise them); get listed (accurately) on local directories; publish original Learning Hub articles about Sambalpur students' maths/physics questions.
* Rankings are never guaranteed and take weeks to months; check Search Console → Performance for the queries you actually appear for.


## Zero-setup e-mail delivery (FormSubmit.co) — works on any static host or straight from mathletics.html
Enquiries are e-mailed to **pradyumnakishorrath@gmail.com** with no backend and no API key. Order of use: your own `/api/enquiry` (Resend) if deployed → Supabase → Web3Forms key → **FormSubmit.co** (default). If `/api/enquiry` is missing on the host (404/405/503) the form falls back to FormSubmit automatically.
**One-time activation:** the first real submission makes FormSubmit e-mail an activation link to that Gmail address. Click it once; after that every enquiry arrives in the inbox (check Spam the first time). Submit one test enquiry yourself right after deploying. Change the recipient in `src/site.config.js` (`notifyEmail`) or `CONFIG.NOTIFY_EMAIL` in mathletics.html.

## Admission enquiries → e-mail (Resend, serverless) — the production setup
Every submission is validated again on the server and e-mailed to **pradyumnakishorrath@gmail.com** (Reply-To = the family's address, clean labelled layout, reference number). Keys exist only as server environment variables — never in the browser code.

1. **Resend account:** sign up at https://resend.com **with pradyumnakishorrath@gmail.com** (Resend's shared sender `onboarding@resend.dev` can only deliver to the account owner's own address — which is exactly what we need). Create an API key (Sending access).
2. **Deploy** this folder on a host that runs functions (build command `node build.mjs`, output `dist`):
   * **Cloudflare Pages** (recommended): uses `functions/api/enquiry.js` automatically.
   * **Netlify**: uses `netlify.toml` + `netlify/functions/enquiry.mjs`.
   * **Vercel**: uses `api/enquiry.js` (set Output Directory to `dist`).
   * **Any Node server/VPS**: `RESEND_API_KEY=… SITE_URL=… node serve.mjs dist 8080`.
3. **Environment variables** on the host: `RESEND_API_KEY` (secret), `SITE_URL`, and optionally `ENQUIRY_TO_EMAIL` / `ENQUIRY_FROM` (see `.env.example`). Redeploy.
4. **Verify delivery (must be done once, by you):** open the live site, submit a real test enquiry with your own e-mail as the family's address, and confirm it lands in the inbox (check Spam the first time, and mark "Not spam"). Resend → Logs shows each send.
5. Later (recommended): verify your own domain in Resend and set `ENQUIRY_FROM` to e.g. `MATHLETICS <enquiries@your-domain.in>` for better deliverability.

Protections: server-side validation (names, class, Mathematics/Physics only, Indian mobile, e-mail, consent), hidden honeypot + minimum-fill-time trap (bots get a silent fake "success" and nothing is sent), same-origin/Origin allow-list, 8 KB body cap, per-IP limit (5 per 10 min per server instance), HTML-escaped e-mail body, header-injection-safe addresses, Resend idempotency key (a repeated request with the same key does not send a second e-mail), client-side double-click lock. For strict rate limiting add a platform rule (e.g. Cloudflare WAF rate limiting) — in-function limits are best-effort on serverless.
If delivery fails the visitor sees an error and tap-to-call links — success is never shown unless Resend accepted the e-mail.
Tests: `node tests/enquiry.test.mjs` (40 checks against a mocked Resend). The single-file `mathletics.html` can use the same endpoint: set `CONFIG.ENQUIRY_API` to its full URL and add that page's origin to `ALLOWED_ORIGINS`.

## Alternatives (only used if `enquiryApi` is set to "")
**A. Quick, no database (2 minutes):** go to https://web3forms.com → enter the e-mail address that should receive enquiries → confirm the e-mail they send → copy the *Access Key*. Put it in `src/site.config.js` → `formEndpoint.web3formsAccessKey` (or the env var `WEB3FORMS_ACCESS_KEY`) and rebuild. Every submission arrives in that inbox as "NEW ADMISSION ENQUIRY — MATHLETICS (reference)". In the single-file `mathletics.html` paste the key into `CONFIG.FORM_ACCESS_KEY`. (No admin dashboard in this mode.)
**B. Full system (database + admin dashboard + approvals):** Supabase + Resend as described in the original project's README; set `supabase.url` / `anonKey`. If both are set, Supabase is used.
Until one is set the form tells visitors plainly that nothing was sent and shows tap-to-call links to both phone numbers.
