import { motion, useScroll, useSpring, useReducedMotion } from "framer-motion";
import { useRef } from "react";
import { JOURNEY } from "../content/siteContent";
import { Reveal } from "./ui/Reveal";
import { CountUp } from "./ui/CountUp";

const COLORS = ["bg-cobalt text-ivory", "bg-tangerine text-midnight", "bg-mint text-royal", "bg-royal text-ivory"];

export function Journey() {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 75%", "end 60%"] });
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 24, mass: 0.4 });

  return (
    <section id="journey" className="relative overflow-hidden bg-royal py-20 text-ivory sm:py-28">
      <div className="dot-grid-light pointer-events-none absolute inset-0 opacity-50" aria-hidden="true" />
      <div className="pointer-events-none absolute -left-32 top-10 size-96 rounded-full bg-cobalt/40 blur-3xl" aria-hidden="true" />

      <div className="wrap relative">
        <Reveal>
          <p className="eyebrow mb-4 text-tangerine">The Learning Experience</p>
          <h2 className="max-w-4xl text-4xl font-bold leading-[1.05] sm:text-6xl">
            Every Great Result Begins With the{" "}
            <span className="font-serif font-normal italic text-tangerine">Right Foundation.</span>
          </h2>
        </Reveal>

        <div ref={ref} className="relative mt-16">
          {/* progress rail */}
          <div className="absolute bottom-0 left-[1.65rem] top-0 w-[3px] rounded-full bg-ivory/15 md:left-1/2 md:-translate-x-1/2" aria-hidden="true">
            <motion.div
              className="w-full origin-top rounded-full bg-gradient-to-b from-tangerine to-mint"
              style={{ height: "100%", scaleY: reduce ? 1 : progress }}
            />
          </div>

          <ol className="space-y-12 md:space-y-20">
            {JOURNEY.map((s, i) => {
              const right = i % 2 === 1;
              return (
                <li key={s.n} className="relative grid items-center md:grid-cols-2 md:gap-24">
                  {/* node on the rail */}
                  <motion.div
                    className={`absolute left-0 top-0 z-10 grid size-[3.3rem] place-items-center rounded-full font-display text-lg font-bold md:left-1/2 md:-translate-x-1/2 ${COLORS[i]}`}
                    initial={reduce ? false : { scale: 0 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true, margin: "-80px" }}
                    transition={{ type: "spring", stiffness: 300, damping: 16 }}
                  >
                    <CountUp to={s.n} />
                  </motion.div>

                  <Reveal
                    x={right ? 40 : -40}
                    y={0}
                    className={`pl-[4.75rem] md:pl-0 ${right ? "md:col-start-2" : "md:col-start-1 md:text-right"}`}
                  >
                    <p className="eyebrow mb-2 text-mint">Stage {String(s.n).padStart(2, "0")}</p>
                    <h3 className="text-4xl font-bold sm:text-5xl">{s.title}</h3>
                    <p className={`mt-3 max-w-md text-lg leading-relaxed text-ivory/75 ${right ? "" : "md:ml-auto"}`}>{s.text}</p>
                  </Reveal>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
    </section>
  );
}
