import { motion, useReducedMotion } from "framer-motion";
import type { ReactNode } from "react";

interface RevealProps {
  children: ReactNode;
  delay?: number;
  y?: number;
  x?: number;
  className?: string;
}

/** Scroll-triggered fade/slide-in. Respects prefers-reduced-motion. */
export function Reveal({ children, delay = 0, y = 28, x = 0, className }: RevealProps) {
  const reducePref = useReducedMotion();
  // Crawlers (Googlebot) render once and never scroll, so they must never see the hidden starting state.
  const crawler = typeof navigator !== "undefined" && /bot|crawl|spider|slurp|lighthouse|pagespeed|headless|google|bing|inspection/i.test(navigator.userAgent);
  const reduce = reducePref || crawler;
  return (
    <motion.div
      className={className}
      initial={reduce ? false : { opacity: 0, y, x }}
      whileInView={{ opacity: 1, y: 0, x: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}
