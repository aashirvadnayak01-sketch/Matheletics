import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useEffect, useState } from "react";
import { MMark } from "./Logo";

const KEY = "mathletics-intro-seen";
const SYMBOLS = ["π", "∑", "√", "∞", "÷", "×", "Δ", "θ", "=", "+", "%", "∫"];

function alreadySeen() {
  try {
    return sessionStorage.getItem(KEY) === "1";
  } catch {
    return false;
  }
}

/**
 * Short (≈2.6s), skippable cinematic intro. Shown once per browser session,
 * skipped entirely for visitors who prefer reduced motion.
 */
export function Intro() {
  const reduce = useReducedMotion();
  const [show, setShow] = useState(() => !alreadySeen());

  const close = () => {
    try {
      sessionStorage.setItem(KEY, "1");
    } catch {
      /* storage unavailable — fine */
    }
    setShow(false);
  };

  useEffect(() => {
    if (!show) return;
    if (reduce) {
      close();
      return;
    }
    const t = window.setTimeout(close, 2900);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" || e.key === "Enter" || e.key === " ") close();
    };
    window.addEventListener("keydown", onKey);
    // Lock scrolling while the intro is visible
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.clearTimeout(t);
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [show, reduce]);

  const letters = "MATHLETICS".split("");

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          key="intro"
          role="dialog"
          aria-label="MATHLETICS introduction"
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center overflow-hidden bg-gradient-to-br from-cobalt via-[#2a4fc4] to-royal text-ivory"
          initial={{ opacity: 1 }}
          exit={{ clipPath: "circle(0% at 50% 50%)", transition: { duration: 0.8, ease: [0.76, 0, 0.24, 1] } }}
          style={{ clipPath: "circle(150% at 50% 50%)" }}
        >
          <div className="dot-grid-light absolute inset-0 opacity-60" aria-hidden="true" />

          {SYMBOLS.map((s, i) => (
            <motion.span
              key={s + i}
              aria-hidden="true"
              className="absolute font-display text-3xl font-bold text-ivory/30 sm:text-5xl"
              style={{ left: `${(i * 37) % 92 + 2}%`, top: `${(i * 53) % 86 + 4}%` }}
              initial={{ opacity: 0, scale: 0.4, rotate: -30 }}
              animate={{ opacity: [0, 1, 0.6], scale: 1, rotate: 0, y: [0, -14, 0] }}
              transition={{ duration: 2.4, delay: 0.1 + i * 0.07, ease: "easeOut" }}
            >
              {s}
            </motion.span>
          ))}

          <div className="relative z-10 flex flex-col items-center px-6 text-center">
            <MMark size={88} tone="light" animated />
            <div className="mt-7 flex" aria-label="MATHLETICS">
              {letters.map((l, i) => (
                <motion.span
                  key={i}
                  aria-hidden="true"
                  className={`font-display text-3xl font-bold sm:text-6xl ${i >= 4 ? "text-tangerine" : ""}`}
                  style={{ marginRight: "0.18em" }}
                  initial={{ opacity: 0, y: 40, rotateX: -70 }}
                  animate={{ opacity: 1, y: 0, rotateX: 0 }}
                  transition={{ duration: 0.6, delay: 0.9 + i * 0.05, ease: [0.22, 1, 0.36, 1] }}
                >
                  {l}
                </motion.span>
              ))}
            </div>
            <motion.p
              className="mt-5 max-w-sm font-serif text-xl italic text-ivory/90 sm:text-2xl"
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 1.7 }}
            >
              Where mathematical intelligence meets academic excellence.
            </motion.p>
          </div>

          <motion.button
            type="button"
            onClick={close}
            className="absolute bottom-8 right-6 z-10 rounded-full border border-ivory/40 px-5 py-3 font-display text-xs font-semibold uppercase tracking-[0.2em] text-ivory transition hover:bg-ivory/10 sm:bottom-10 sm:right-10"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            Skip intro
          </motion.button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
